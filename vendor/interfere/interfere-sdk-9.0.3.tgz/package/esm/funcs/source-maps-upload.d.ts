import { InterfereCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/errors/http-client-errors.js";
import * as errors from "../models/errors/index.js";
import { InterfereHTTPError } from "../models/errors/interfere-http-error.js";
import { ResponseValidationError } from "../models/errors/response-validation-error.js";
import { SDKValidationError } from "../models/errors/sdk-validation-error.js";
import * as models from "../models/index.js";
import * as operations from "../models/operations/index.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
/**
 * @deprecated method: This will be removed in a future release, please migrate away from it as soon as possible.
 */
export declare function sourceMapsUpload(client: InterfereCore, request: operations.UploadSourceMapsRequest, options?: RequestOptions): APIPromise<Result<models.ReleasesUploadSourceMapsResponse, errors.ErrorsProblem | InterfereHTTPError | ResponseValidationError | ConnectionError | RequestAbortedError | RequestTimeoutError | InvalidRequestError | UnexpectedClientError | SDKValidationError>>;
//# sourceMappingURL=source-maps-upload.d.ts.map