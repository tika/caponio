import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type IngestResponse = {
    ok: boolean;
    received: number;
};
/** @internal */
export declare const IngestResponse$inboundSchema: z.ZodMiniType<IngestResponse, unknown>;
export declare function ingestResponseFromJSON(jsonString: string): SafeParseResult<IngestResponse, SDKValidationError>;
//# sourceMappingURL=ingest-response.d.ts.map