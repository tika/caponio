import * as z from "zod/v4-mini";
/**
 * Payload for a UI event envelope.
 */
export type UiEventPayload = {
    event: {
        [k: string]: any;
    };
};
/** @internal */
export type UiEventPayload$Outbound = {
    event: {
        [k: string]: any;
    };
};
/** @internal */
export declare const UiEventPayload$outboundSchema: z.ZodMiniType<UiEventPayload$Outbound, UiEventPayload>;
export declare function uiEventPayloadToJSON(uiEventPayload: UiEventPayload): string;
//# sourceMappingURL=ui-event-payload.d.ts.map