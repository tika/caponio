import * as z from "zod/v4-mini";
/**
 * Payload for a pageleave envelope.
 */
export type PageleavePayload = {
    url: string;
    durationMs?: number | undefined;
};
/** @internal */
export type PageleavePayload$Outbound = {
    url: string;
    durationMs?: number | undefined;
};
/** @internal */
export declare const PageleavePayload$outboundSchema: z.ZodMiniType<PageleavePayload$Outbound, PageleavePayload>;
export declare function pageleavePayloadToJSON(pageleavePayload: PageleavePayload): string;
//# sourceMappingURL=pageleave-payload.d.ts.map