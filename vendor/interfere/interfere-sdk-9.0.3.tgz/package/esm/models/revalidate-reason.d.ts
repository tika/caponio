import * as z from "zod/v4-mini";
import { ClosedEnum } from "../types/enums.js";
export declare const RevalidateReason: {
    readonly OnDemand: "on-demand";
    readonly Stale: "stale";
};
export type RevalidateReason = ClosedEnum<typeof RevalidateReason>;
/** @internal */
export declare const RevalidateReason$outboundSchema: z.ZodMiniEnum<typeof RevalidateReason>;
//# sourceMappingURL=revalidate-reason.d.ts.map