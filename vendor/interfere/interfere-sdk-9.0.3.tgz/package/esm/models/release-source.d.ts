import * as z from "zod/v4-mini";
import { GithubReleaseSource, GithubReleaseSource$Outbound } from "./github-release-source.js";
export type ReleaseSource = GithubReleaseSource;
/** @internal */
export type ReleaseSource$Outbound = GithubReleaseSource$Outbound;
/** @internal */
export declare const ReleaseSource$outboundSchema: z.ZodMiniType<ReleaseSource$Outbound, ReleaseSource>;
export declare function releaseSourceToJSON(releaseSource: ReleaseSource): string;
//# sourceMappingURL=release-source.d.ts.map