import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type SessionResponse = {
    ok: boolean;
};
/** @internal */
export declare const SessionResponse$inboundSchema: z.ZodMiniType<SessionResponse, unknown>;
export declare function sessionResponseFromJSON(jsonString: string): SafeParseResult<SessionResponse, SDKValidationError>;
//# sourceMappingURL=session-response.d.ts.map