import * as z from "zod/v4-mini";
export type DeviceInfo = {
    type?: string | undefined;
    model?: string | undefined;
    vendor?: string | undefined;
};
/** @internal */
export type DeviceInfo$Outbound = {
    type?: string | undefined;
    model?: string | undefined;
    vendor?: string | undefined;
};
/** @internal */
export declare const DeviceInfo$outboundSchema: z.ZodMiniType<DeviceInfo$Outbound, DeviceInfo>;
export declare function deviceInfoToJSON(deviceInfo: DeviceInfo): string;
//# sourceMappingURL=device-info.d.ts.map