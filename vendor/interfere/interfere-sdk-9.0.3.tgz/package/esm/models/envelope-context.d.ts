import * as z from "zod/v4-mini";
import { BrowserContext, BrowserContext$Outbound } from "./browser-context.js";
import { EdgeContext, EdgeContext$Outbound } from "./edge-context.js";
import { NextjsContext, NextjsContext$Outbound } from "./nextjs-context.js";
/**
 * Runtime-specific request context attached to every envelope.
 */
export type EnvelopeContext = BrowserContext | NextjsContext | EdgeContext;
/** @internal */
export type EnvelopeContext$Outbound = BrowserContext$Outbound | NextjsContext$Outbound | EdgeContext$Outbound;
/** @internal */
export declare const EnvelopeContext$outboundSchema: z.ZodMiniType<EnvelopeContext$Outbound, EnvelopeContext>;
export declare function envelopeContextToJSON(envelopeContext: EnvelopeContext): string;
//# sourceMappingURL=envelope-context.d.ts.map