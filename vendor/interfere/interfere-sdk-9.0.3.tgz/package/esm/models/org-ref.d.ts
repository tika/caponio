import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type OrgRef = {
    id: string;
    slug: string;
};
/** @internal */
export declare const OrgRef$inboundSchema: z.ZodMiniType<OrgRef, unknown>;
export declare function orgRefFromJSON(jsonString: string): SafeParseResult<OrgRef, SDKValidationError>;
//# sourceMappingURL=org-ref.d.ts.map