import * as z from "zod/v4-mini";
import { ClosedEnum } from "../types/enums.js";
export declare const RouteType: {
    readonly Render: "render";
    readonly Route: "route";
    readonly Action: "action";
    readonly Middleware: "middleware";
    readonly Proxy: "proxy";
};
export type RouteType = ClosedEnum<typeof RouteType>;
/** @internal */
export declare const RouteType$outboundSchema: z.ZodMiniEnum<typeof RouteType>;
//# sourceMappingURL=route-type.d.ts.map