import * as z from "zod/v4-mini";
import { SignSourceMapFile, SignSourceMapFile$Outbound } from "./sign-source-map-file.js";
/**
 * Per-file metadata the SDK uses to obtain presigned PUT URLs. The server validates per-file size and total file count, then issues short-lived URLs scoped to the release's R2 prefix. The SDK uploads to R2 directly and follows up with a `complete` call to materialize the manifest.
 */
export type ReleasesSignSourceMapsRequest = {
    files: Array<SignSourceMapFile>;
};
/** @internal */
export type ReleasesSignSourceMapsRequest$Outbound = {
    files: Array<SignSourceMapFile$Outbound>;
};
/** @internal */
export declare const ReleasesSignSourceMapsRequest$outboundSchema: z.ZodMiniType<ReleasesSignSourceMapsRequest$Outbound, ReleasesSignSourceMapsRequest>;
export declare function releasesSignSourceMapsRequestToJSON(releasesSignSourceMapsRequest: ReleasesSignSourceMapsRequest): string;
//# sourceMappingURL=releases-sign-source-maps-request.d.ts.map