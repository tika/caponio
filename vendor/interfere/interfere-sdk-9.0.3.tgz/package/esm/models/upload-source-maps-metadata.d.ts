import * as z from "zod/v4-mini";
import { ManifestBundler } from "./manifest-bundler.js";
import { UploadSourceMapEntry, UploadSourceMapEntry$Outbound } from "./upload-source-map-entry.js";
/**
 * Metadata attached alongside uploaded source map files.
 */
export type UploadSourceMapsMetadata = {
    entries: Array<UploadSourceMapEntry>;
    sourceFileCount?: number | undefined;
    bundler: ManifestBundler;
};
/** @internal */
export type UploadSourceMapsMetadata$Outbound = {
    entries: Array<UploadSourceMapEntry$Outbound>;
    sourceFileCount?: number | undefined;
    bundler: string;
};
/** @internal */
export declare const UploadSourceMapsMetadata$outboundSchema: z.ZodMiniType<UploadSourceMapsMetadata$Outbound, UploadSourceMapsMetadata>;
export declare function uploadSourceMapsMetadataToJSON(uploadSourceMapsMetadata: UploadSourceMapsMetadata): string;
//# sourceMappingURL=upload-source-maps-metadata.d.ts.map