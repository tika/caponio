import * as z from "zod/v4-mini";
import { ErrorEnvelope, ErrorEnvelope$Outbound } from "./error-envelope.js";
import { PageleaveEnvelope, PageleaveEnvelope$Outbound } from "./pageleave-envelope.js";
import { PageviewEnvelope, PageviewEnvelope$Outbound } from "./pageview-envelope.js";
import { RageClickEnvelope, RageClickEnvelope$Outbound } from "./rage-click-envelope.js";
import { ReplayChunkEnvelope, ReplayChunkEnvelope$Outbound } from "./replay-chunk-envelope.js";
import { UiEventEnvelope, UiEventEnvelope$Outbound } from "./ui-event-envelope.js";
/**
 * A single event envelope accepted by the collector.
 */
export type Envelope = ErrorEnvelope | PageviewEnvelope | PageleaveEnvelope | UiEventEnvelope | ReplayChunkEnvelope | RageClickEnvelope;
/** @internal */
export type Envelope$Outbound = ErrorEnvelope$Outbound | PageviewEnvelope$Outbound | PageleaveEnvelope$Outbound | UiEventEnvelope$Outbound | ReplayChunkEnvelope$Outbound | RageClickEnvelope$Outbound;
/** @internal */
export declare const Envelope$outboundSchema: z.ZodMiniType<Envelope$Outbound, Envelope>;
export declare function envelopeToJSON(envelope: Envelope): string;
//# sourceMappingURL=envelope.d.ts.map