import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type ValidationErrorDetails = {
    errors: Array<any>;
};
/** @internal */
export declare const ValidationErrorDetails$inboundSchema: z.ZodMiniType<ValidationErrorDetails, unknown>;
export declare function validationErrorDetailsFromJSON(jsonString: string): SafeParseResult<ValidationErrorDetails, SDKValidationError>;
//# sourceMappingURL=validation-error-details.d.ts.map