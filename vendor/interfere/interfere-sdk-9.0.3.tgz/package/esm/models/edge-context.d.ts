import * as z from "zod/v4-mini";
/**
 * Request context for the Edge runtime.
 */
export type EdgeContext = {
    runtime: "edge";
};
/** @internal */
export type EdgeContext$Outbound = {
    runtime: "edge";
};
/** @internal */
export declare const EdgeContext$outboundSchema: z.ZodMiniType<EdgeContext$Outbound, EdgeContext>;
export declare function edgeContextToJSON(edgeContext: EdgeContext): string;
//# sourceMappingURL=edge-context.d.ts.map