import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type ReplayUploadChunkResponse = {
    objectKey: string;
};
/** @internal */
export declare const ReplayUploadChunkResponse$inboundSchema: z.ZodMiniType<ReplayUploadChunkResponse, unknown>;
export declare function replayUploadChunkResponseFromJSON(jsonString: string): SafeParseResult<ReplayUploadChunkResponse, SDKValidationError>;
//# sourceMappingURL=replay-upload-chunk-response.d.ts.map