import * as z from "zod/v4-mini";
import { ClosedEnum } from "../types/enums.js";
import { ReleaseSource, ReleaseSource$Outbound } from "./release-source.js";
export declare const VercelReleaseDestinationProvider: {
    readonly Vercel: "vercel";
};
export type VercelReleaseDestinationProvider = ClosedEnum<typeof VercelReleaseDestinationProvider>;
/**
 * Release destination metadata for a Vercel deployment.
 */
export type VercelReleaseDestination = {
    provider: VercelReleaseDestinationProvider;
    destinationReleaseId: string | null;
    environment: string | null;
    deploymentId: string | null;
    deploymentUrl: string | null;
    environmentName: string | null;
    environmentTarget: string | null;
};
export type ReleaseDestination = VercelReleaseDestination;
/**
 * Request body for creating a release.
 */
export type ReleasesCreateRequest = {
    source: ReleaseSource;
    destination: VercelReleaseDestination | null;
    buildId: string;
    slug?: string | undefined;
    producerVersion?: string | undefined;
};
/** @internal */
export declare const VercelReleaseDestinationProvider$outboundSchema: z.ZodMiniEnum<typeof VercelReleaseDestinationProvider>;
/** @internal */
export type VercelReleaseDestination$Outbound = {
    provider: string;
    destinationReleaseId: string | null;
    environment: string | null;
    deploymentId: string | null;
    deploymentUrl: string | null;
    environmentName: string | null;
    environmentTarget: string | null;
};
/** @internal */
export declare const VercelReleaseDestination$outboundSchema: z.ZodMiniType<VercelReleaseDestination$Outbound, VercelReleaseDestination>;
export declare function vercelReleaseDestinationToJSON(vercelReleaseDestination: VercelReleaseDestination): string;
/** @internal */
export type ReleaseDestination$Outbound = VercelReleaseDestination$Outbound;
/** @internal */
export declare const ReleaseDestination$outboundSchema: z.ZodMiniType<ReleaseDestination$Outbound, ReleaseDestination>;
export declare function releaseDestinationToJSON(releaseDestination: ReleaseDestination): string;
/** @internal */
export type ReleasesCreateRequest$Outbound = {
    source: ReleaseSource$Outbound;
    destination: VercelReleaseDestination$Outbound | null;
    buildId: string;
    slug?: string | undefined;
    producerVersion?: string | undefined;
};
/** @internal */
export declare const ReleasesCreateRequest$outboundSchema: z.ZodMiniType<ReleasesCreateRequest$Outbound, ReleasesCreateRequest>;
export declare function releasesCreateRequestToJSON(releasesCreateRequest: ReleasesCreateRequest): string;
//# sourceMappingURL=releases-create-request.d.ts.map