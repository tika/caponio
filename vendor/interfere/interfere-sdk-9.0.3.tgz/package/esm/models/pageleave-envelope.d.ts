import * as z from "zod/v4-mini";
import { EnvelopeContext, EnvelopeContext$Outbound } from "./envelope-context.js";
import { Environment } from "./environment.js";
import { PageleavePayload, PageleavePayload$Outbound } from "./pageleave-payload.js";
import { RuntimeEnum } from "./runtime-enum.js";
import { SessionSource } from "./session-source.js";
export type PageleaveEnvelope = {
    type: "pageleave";
    buildId: string;
    clientTs: number;
    context?: EnvelopeContext | undefined;
    /**
     * Deployment environment the SDK is running in.
     */
    environment: Environment | null;
    producerVersion?: string | undefined;
    releaseId: string | null;
    /**
     * JavaScript runtime the SDK is running in.
     */
    runtime: RuntimeEnum | null;
    sdkStack?: Array<string> | undefined;
    sessionId: string | null;
    /**
     * How the server resolved the sessionId for this envelope.
     */
    sessionSource?: SessionSource | undefined;
    uuid: string;
    v: number;
    /**
     * Payload for a pageleave envelope.
     */
    payload: PageleavePayload;
};
/** @internal */
export type PageleaveEnvelope$Outbound = {
    type: "pageleave";
    buildId: string;
    clientTs: number;
    context?: EnvelopeContext$Outbound | undefined;
    environment: string | null;
    producerVersion?: string | undefined;
    releaseId: string | null;
    runtime: string | null;
    sdkStack?: Array<string> | undefined;
    sessionId: string | null;
    sessionSource?: string | undefined;
    uuid: string;
    v: number;
    payload: PageleavePayload$Outbound;
};
/** @internal */
export declare const PageleaveEnvelope$outboundSchema: z.ZodMiniType<PageleaveEnvelope$Outbound, PageleaveEnvelope>;
export declare function pageleaveEnvelopeToJSON(pageleaveEnvelope: PageleaveEnvelope): string;
//# sourceMappingURL=pageleave-envelope.d.ts.map