import * as z from "zod/v4-mini";
export type MultipartFile = {
    fileName: string;
    content: ReadableStream<Uint8Array> | Blob | ArrayBuffer | Uint8Array;
};
/** @internal */
export type MultipartFile$Outbound = {
    fileName: string;
    content: ReadableStream<Uint8Array> | Blob | ArrayBuffer | Uint8Array;
};
/** @internal */
export declare const MultipartFile$outboundSchema: z.ZodMiniType<MultipartFile$Outbound, MultipartFile>;
export declare function multipartFileToJSON(multipartFile: MultipartFile): string;
//# sourceMappingURL=multipart-file.d.ts.map