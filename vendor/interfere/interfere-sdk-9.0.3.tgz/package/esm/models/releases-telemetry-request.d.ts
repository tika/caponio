import * as z from "zod/v4-mini";
/**
 * Timings and counters reported after a source-map upload.
 */
export type ReleasesTelemetryRequest = {
    discover: number;
    createRelease: number;
    upload: number;
    cleanup: number;
    total: number;
    fileCount: number;
    totalBytes: number;
};
/** @internal */
export type ReleasesTelemetryRequest$Outbound = {
    discover: number;
    createRelease: number;
    upload: number;
    cleanup: number;
    total: number;
    fileCount: number;
    totalBytes: number;
};
/** @internal */
export declare const ReleasesTelemetryRequest$outboundSchema: z.ZodMiniType<ReleasesTelemetryRequest$Outbound, ReleasesTelemetryRequest>;
export declare function releasesTelemetryRequestToJSON(releasesTelemetryRequest: ReleasesTelemetryRequest): string;
//# sourceMappingURL=releases-telemetry-request.d.ts.map