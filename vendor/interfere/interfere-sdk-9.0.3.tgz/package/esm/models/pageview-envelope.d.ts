import * as z from "zod/v4-mini";
import { EnvelopeContext, EnvelopeContext$Outbound } from "./envelope-context.js";
import { Environment } from "./environment.js";
import { PageviewPayload, PageviewPayload$Outbound } from "./pageview-payload.js";
import { RuntimeEnum } from "./runtime-enum.js";
import { SessionSource } from "./session-source.js";
export type PageviewEnvelope = {
    type: "pageview";
    buildId: string;
    clientTs: number;
    context?: EnvelopeContext | undefined;
    /**
     * Deployment environment the SDK is running in.
     */
    environment: Environment | null;
    producerVersion?: string | undefined;
    releaseId: string | null;
    /**
     * JavaScript runtime the SDK is running in.
     */
    runtime: RuntimeEnum | null;
    sdkStack?: Array<string> | undefined;
    sessionId: string | null;
    /**
     * How the server resolved the sessionId for this envelope.
     */
    sessionSource?: SessionSource | undefined;
    uuid: string;
    v: number;
    /**
     * Payload for a pageview envelope.
     */
    payload: PageviewPayload;
};
/** @internal */
export type PageviewEnvelope$Outbound = {
    type: "pageview";
    buildId: string;
    clientTs: number;
    context?: EnvelopeContext$Outbound | undefined;
    environment: string | null;
    producerVersion?: string | undefined;
    releaseId: string | null;
    runtime: string | null;
    sdkStack?: Array<string> | undefined;
    sessionId: string | null;
    sessionSource?: string | undefined;
    uuid: string;
    v: number;
    payload: PageviewPayload$Outbound;
};
/** @internal */
export declare const PageviewEnvelope$outboundSchema: z.ZodMiniType<PageviewEnvelope$Outbound, PageviewEnvelope>;
export declare function pageviewEnvelopeToJSON(pageviewEnvelope: PageviewEnvelope): string;
//# sourceMappingURL=pageview-envelope.d.ts.map