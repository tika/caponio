import * as z from "zod/v4-mini";
export type DeviceBrowser = {
    name?: string | undefined;
    type?: string | undefined;
    major?: string | undefined;
    version?: string | undefined;
};
/** @internal */
export type DeviceBrowser$Outbound = {
    name?: string | undefined;
    type?: string | undefined;
    major?: string | undefined;
    version?: string | undefined;
};
/** @internal */
export declare const DeviceBrowser$outboundSchema: z.ZodMiniType<DeviceBrowser$Outbound, DeviceBrowser>;
export declare function deviceBrowserToJSON(deviceBrowser: DeviceBrowser): string;
//# sourceMappingURL=device-browser.d.ts.map