import * as z from "zod/v4-mini";
import { Exception, Exception$Outbound } from "./exception.js";
/**
 * Payload for an error envelope.
 */
export type ErrorPayload = {
    exceptions: Array<Exception>;
};
/** @internal */
export type ErrorPayload$Outbound = {
    exceptions: Array<Exception$Outbound>;
};
/** @internal */
export declare const ErrorPayload$outboundSchema: z.ZodMiniType<ErrorPayload$Outbound, ErrorPayload>;
export declare function errorPayloadToJSON(errorPayload: ErrorPayload): string;
//# sourceMappingURL=error-payload.d.ts.map