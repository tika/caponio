import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
/**
 * Acknowledgement that this release is cleared for ingest. Body is empty because the call itself is the signal.
 */
export type ReleasesPreflightResponse = {
    ok: boolean;
};
/** @internal */
export declare const ReleasesPreflightResponse$inboundSchema: z.ZodMiniType<ReleasesPreflightResponse, unknown>;
export declare function releasesPreflightResponseFromJSON(jsonString: string): SafeParseResult<ReleasesPreflightResponse, SDKValidationError>;
//# sourceMappingURL=releases-preflight-response.d.ts.map