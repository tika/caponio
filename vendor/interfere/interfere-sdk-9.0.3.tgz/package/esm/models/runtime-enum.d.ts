import * as z from "zod/v4-mini";
import { ClosedEnum } from "../types/enums.js";
/**
 * JavaScript runtime the SDK is running in.
 */
export declare const RuntimeEnum: {
    readonly Browser: "browser";
    readonly Node: "node";
    readonly Edge: "edge";
};
/**
 * JavaScript runtime the SDK is running in.
 */
export type RuntimeEnum = ClosedEnum<typeof RuntimeEnum>;
/** @internal */
export declare const RuntimeEnum$outboundSchema: z.ZodMiniEnum<typeof RuntimeEnum>;
//# sourceMappingURL=runtime-enum.d.ts.map