import * as z from "zod/v4-mini";
import { ClosedEnum } from "../types/enums.js";
export declare const RenderSource: {
    readonly ReactServerComponents: "react-server-components";
    readonly ReactServerComponentsPayload: "react-server-components-payload";
    readonly ServerRendering: "server-rendering";
};
export type RenderSource = ClosedEnum<typeof RenderSource>;
/** @internal */
export declare const RenderSource$outboundSchema: z.ZodMiniEnum<typeof RenderSource>;
//# sourceMappingURL=render-source.d.ts.map