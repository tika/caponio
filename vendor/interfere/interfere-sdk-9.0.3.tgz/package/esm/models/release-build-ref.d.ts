import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type ReleaseBuildRef = {
    hash: string;
};
/** @internal */
export declare const ReleaseBuildRef$inboundSchema: z.ZodMiniType<ReleaseBuildRef, unknown>;
export declare function releaseBuildRefFromJSON(jsonString: string): SafeParseResult<ReleaseBuildRef, SDKValidationError>;
//# sourceMappingURL=release-build-ref.d.ts.map