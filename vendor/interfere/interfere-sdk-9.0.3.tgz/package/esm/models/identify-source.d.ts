import * as z from "zod/v4-mini";
import { Auth0IdentifySource, Auth0IdentifySource$Outbound } from "./auth0-identify-source.js";
import { ClerkIdentifySource, ClerkIdentifySource$Outbound } from "./clerk-identify-source.js";
import { CustomIdentifySource, CustomIdentifySource$Outbound } from "./custom-identify-source.js";
/**
 * Auth provider that surfaced this identification.
 */
export type IdentifySource = ClerkIdentifySource | Auth0IdentifySource | CustomIdentifySource;
/** @internal */
export type IdentifySource$Outbound = ClerkIdentifySource$Outbound | Auth0IdentifySource$Outbound | CustomIdentifySource$Outbound;
/** @internal */
export declare const IdentifySource$outboundSchema: z.ZodMiniType<IdentifySource$Outbound, IdentifySource>;
export declare function identifySourceToJSON(identifySource: IdentifySource): string;
//# sourceMappingURL=identify-source.d.ts.map