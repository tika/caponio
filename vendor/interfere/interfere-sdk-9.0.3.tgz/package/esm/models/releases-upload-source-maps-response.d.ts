import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type ReleasesUploadSourceMapsResponse = {
    ok: boolean;
    processed: number;
    message: string;
    fileCount: number;
};
/** @internal */
export declare const ReleasesUploadSourceMapsResponse$inboundSchema: z.ZodMiniType<ReleasesUploadSourceMapsResponse, unknown>;
export declare function releasesUploadSourceMapsResponseFromJSON(jsonString: string): SafeParseResult<ReleasesUploadSourceMapsResponse, SDKValidationError>;
//# sourceMappingURL=releases-upload-source-maps-response.d.ts.map