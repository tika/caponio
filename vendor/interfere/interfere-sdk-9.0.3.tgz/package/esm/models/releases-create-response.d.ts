import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
import { OrgRef } from "./org-ref.js";
import { ReleaseBuildRef } from "./release-build-ref.js";
import { ReleaseDestinationRef } from "./release-destination-ref.js";
import { ReleaseSourceRef } from "./release-source-ref.js";
import { SurfaceRef } from "./surface-ref.js";
/**
 * Response body returned after creating a release.
 */
export type ReleasesCreateResponse = {
    org: OrgRef;
    surface: SurfaceRef;
    source: ReleaseSourceRef;
    destination: ReleaseDestinationRef;
    build: ReleaseBuildRef;
};
/** @internal */
export declare const ReleasesCreateResponse$inboundSchema: z.ZodMiniType<ReleasesCreateResponse, unknown>;
export declare function releasesCreateResponseFromJSON(jsonString: string): SafeParseResult<ReleasesCreateResponse, SDKValidationError>;
//# sourceMappingURL=releases-create-response.d.ts.map