import * as z from "zod/v4-mini";
/**
 * A single stack frame captured from an error.
 */
export type Frame = {
    fileName?: string | undefined;
    functionName?: string | undefined;
    lineNumber?: number | undefined;
    columnNumber?: number | undefined;
    source?: string | undefined;
    debugId?: string | undefined;
};
/** @internal */
export type Frame$Outbound = {
    fileName?: string | undefined;
    functionName?: string | undefined;
    lineNumber?: number | undefined;
    columnNumber?: number | undefined;
    source?: string | undefined;
    debugId?: string | undefined;
};
/** @internal */
export declare const Frame$outboundSchema: z.ZodMiniType<Frame$Outbound, Frame>;
export declare function frameToJSON(frame: Frame): string;
//# sourceMappingURL=frame.d.ts.map