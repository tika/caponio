import * as z from "zod/v4-mini";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export declare const Status: {
    readonly Ok: "ok";
};
export type Status = ClosedEnum<typeof Status>;
export type HealthOk = {
    status: Status;
};
/** @internal */
export declare const Status$inboundSchema: z.ZodMiniEnum<typeof Status>;
/** @internal */
export declare const HealthOk$inboundSchema: z.ZodMiniType<HealthOk, unknown>;
export declare function healthOkFromJSON(jsonString: string): SafeParseResult<HealthOk, SDKValidationError>;
//# sourceMappingURL=health-ok.d.ts.map