import * as z from "zod/v4-mini";
import { CompleteSourceMapFile, CompleteSourceMapFile$Outbound } from "./complete-source-map-file.js";
import { ManifestBundler } from "./manifest-bundler.js";
/**
 * Finalizes a presigned-URL upload batch. Writes the source-map manifest and updates the release's `sourceMapCount` / `sourceFileCount`. Idempotent — safe to retry.
 */
export type ReleasesCompleteSourceMapsRequest = {
    files: Array<CompleteSourceMapFile>;
    sourceFileCount?: number | undefined;
    bundler: ManifestBundler;
};
/** @internal */
export type ReleasesCompleteSourceMapsRequest$Outbound = {
    files: Array<CompleteSourceMapFile$Outbound>;
    sourceFileCount?: number | undefined;
    bundler: string;
};
/** @internal */
export declare const ReleasesCompleteSourceMapsRequest$outboundSchema: z.ZodMiniType<ReleasesCompleteSourceMapsRequest$Outbound, ReleasesCompleteSourceMapsRequest>;
export declare function releasesCompleteSourceMapsRequestToJSON(releasesCompleteSourceMapsRequest: ReleasesCompleteSourceMapsRequest): string;
//# sourceMappingURL=releases-complete-source-maps-request.d.ts.map