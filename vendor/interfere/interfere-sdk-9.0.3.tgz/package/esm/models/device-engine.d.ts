import * as z from "zod/v4-mini";
export type DeviceEngine = {
    version?: string | undefined;
    name?: string | undefined;
};
/** @internal */
export type DeviceEngine$Outbound = {
    version?: string | undefined;
    name?: string | undefined;
};
/** @internal */
export declare const DeviceEngine$outboundSchema: z.ZodMiniType<DeviceEngine$Outbound, DeviceEngine>;
export declare function deviceEngineToJSON(deviceEngine: DeviceEngine): string;
//# sourceMappingURL=device-engine.d.ts.map