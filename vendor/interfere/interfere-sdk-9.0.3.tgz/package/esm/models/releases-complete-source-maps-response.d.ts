import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type ReleasesCompleteSourceMapsResponse = {
    ok: boolean;
    fileCount: number;
};
/** @internal */
export declare const ReleasesCompleteSourceMapsResponse$inboundSchema: z.ZodMiniType<ReleasesCompleteSourceMapsResponse, unknown>;
export declare function releasesCompleteSourceMapsResponseFromJSON(jsonString: string): SafeParseResult<ReleasesCompleteSourceMapsResponse, SDKValidationError>;
//# sourceMappingURL=releases-complete-source-maps-response.d.ts.map