import * as z from "zod/v4-mini";
/**
 * How the exception was captured by the SDK.
 */
export type ErrorMechanism = {
    type: string;
    handled: boolean;
    synthetic?: boolean | undefined;
};
/** @internal */
export type ErrorMechanism$Outbound = {
    type: string;
    handled: boolean;
    synthetic?: boolean | undefined;
};
/** @internal */
export declare const ErrorMechanism$outboundSchema: z.ZodMiniType<ErrorMechanism$Outbound, ErrorMechanism>;
export declare function errorMechanismToJSON(errorMechanism: ErrorMechanism): string;
//# sourceMappingURL=error-mechanism.d.ts.map