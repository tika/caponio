import * as z from "zod/v4-mini";
/**
 * Payload for a replay-chunk envelope.
 */
export type ReplayChunkPayload = {
    ts: number;
    count: number;
    events: Array<string>;
    firstEventTs?: number | undefined;
    lastEventTs?: number | undefined;
};
/** @internal */
export type ReplayChunkPayload$Outbound = {
    ts: number;
    count: number;
    events: Array<string>;
    first_event_ts?: number | undefined;
    last_event_ts?: number | undefined;
};
/** @internal */
export declare const ReplayChunkPayload$outboundSchema: z.ZodMiniType<ReplayChunkPayload$Outbound, ReplayChunkPayload>;
export declare function replayChunkPayloadToJSON(replayChunkPayload: ReplayChunkPayload): string;
//# sourceMappingURL=replay-chunk-payload.d.ts.map