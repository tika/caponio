import * as z from "zod/v4-mini";
import { EnvelopeContext, EnvelopeContext$Outbound } from "./envelope-context.js";
import { Environment } from "./environment.js";
import { RuntimeEnum } from "./runtime-enum.js";
import { SessionSource } from "./session-source.js";
import { UiEventPayload, UiEventPayload$Outbound } from "./ui-event-payload.js";
export type UiEventEnvelope = {
    type: "ui_event";
    buildId: string;
    clientTs: number;
    context?: EnvelopeContext | undefined;
    /**
     * Deployment environment the SDK is running in.
     */
    environment: Environment | null;
    producerVersion?: string | undefined;
    releaseId: string | null;
    /**
     * JavaScript runtime the SDK is running in.
     */
    runtime: RuntimeEnum | null;
    sdkStack?: Array<string> | undefined;
    sessionId: string | null;
    /**
     * How the server resolved the sessionId for this envelope.
     */
    sessionSource?: SessionSource | undefined;
    uuid: string;
    v: number;
    /**
     * Payload for a UI event envelope.
     */
    payload: UiEventPayload;
};
/** @internal */
export type UiEventEnvelope$Outbound = {
    type: "ui_event";
    buildId: string;
    clientTs: number;
    context?: EnvelopeContext$Outbound | undefined;
    environment: string | null;
    producerVersion?: string | undefined;
    releaseId: string | null;
    runtime: string | null;
    sdkStack?: Array<string> | undefined;
    sessionId: string | null;
    sessionSource?: string | undefined;
    uuid: string;
    v: number;
    payload: UiEventPayload$Outbound;
};
/** @internal */
export declare const UiEventEnvelope$outboundSchema: z.ZodMiniType<UiEventEnvelope$Outbound, UiEventEnvelope>;
export declare function uiEventEnvelopeToJSON(uiEventEnvelope: UiEventEnvelope): string;
//# sourceMappingURL=ui-event-envelope.d.ts.map