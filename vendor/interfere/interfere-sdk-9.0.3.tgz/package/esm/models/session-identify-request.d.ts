import * as z from "zod/v4-mini";
import { IdentifySource, IdentifySource$Outbound } from "./identify-source.js";
/**
 * Request body for identifying the end user associated with a session.
 */
export type SessionIdentifyRequest = {
    name?: string | undefined;
    sessionId: string;
    deviceId?: string | null | undefined;
    fpHash?: string | null | undefined;
    visitorId?: string | null | undefined;
    avatar?: string | undefined;
    email?: string | undefined;
    identifier: string;
    /**
     * Auth provider that surfaced this identification.
     */
    source: IdentifySource;
    traits?: {
        [k: string]: any;
    } | undefined;
    country?: string | undefined;
};
/** @internal */
export type SessionIdentifyRequest$Outbound = {
    name?: string | undefined;
    sessionId: string;
    deviceId?: string | null | undefined;
    fpHash?: string | null | undefined;
    visitorId?: string | null | undefined;
    avatar?: string | undefined;
    email?: string | undefined;
    identifier: string;
    source: IdentifySource$Outbound;
    traits?: {
        [k: string]: any;
    } | undefined;
    country?: string | undefined;
};
/** @internal */
export declare const SessionIdentifyRequest$outboundSchema: z.ZodMiniType<SessionIdentifyRequest$Outbound, SessionIdentifyRequest>;
export declare function sessionIdentifyRequestToJSON(sessionIdentifyRequest: SessionIdentifyRequest): string;
//# sourceMappingURL=session-identify-request.d.ts.map