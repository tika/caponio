import * as z from "zod/v4-mini";
export type DeviceCpu = {
    architecture?: string | undefined;
};
/** @internal */
export type DeviceCpu$Outbound = {
    architecture?: string | undefined;
};
/** @internal */
export declare const DeviceCpu$outboundSchema: z.ZodMiniType<DeviceCpu$Outbound, DeviceCpu>;
export declare function deviceCpuToJSON(deviceCpu: DeviceCpu): string;
//# sourceMappingURL=device-cpu.d.ts.map