import * as z from "zod/v4-mini";
export type SignSourceMapFile = {
    path: string;
    sizeBytes: number;
    hasSourcesContent: boolean;
    hasNames: boolean;
    hasFile: boolean;
    mappingsPresent: boolean;
};
/** @internal */
export type SignSourceMapFile$Outbound = {
    path: string;
    sizeBytes: number;
    hasSourcesContent: boolean;
    hasNames: boolean;
    hasFile: boolean;
    mappingsPresent: boolean;
};
/** @internal */
export declare const SignSourceMapFile$outboundSchema: z.ZodMiniType<SignSourceMapFile$Outbound, SignSourceMapFile>;
export declare function signSourceMapFileToJSON(signSourceMapFile: SignSourceMapFile): string;
//# sourceMappingURL=sign-source-map-file.d.ts.map