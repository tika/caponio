import * as z from "zod/v4-mini";
import { InterfereHTTPError } from "./interfere-http-error.js";
export type HealthErrorData = {
    ok?: false | undefined;
    message?: string | undefined;
};
export declare class HealthError extends InterfereHTTPError {
    ok?: false | undefined;
    /** The original data that was passed to this error instance. */
    data$: HealthErrorData;
    constructor(err: HealthErrorData, httpMeta: {
        response: Response;
        request: Request;
        body: string;
    });
}
/** @internal */
export declare const HealthError$inboundSchema: z.ZodMiniType<HealthError, unknown>;
//# sourceMappingURL=health-error.d.ts.map