import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../../types/fp.js";
import * as models from "../index.js";
import { InterfereHTTPError } from "./interfere-http-error.js";
import { SDKValidationError } from "./sdk-validation-error.js";
export type ReleaseSignDuplicatePathErrorData = {
    code: "COLLECTOR_RELEASE_SIGN_DUPLICATE_PATH";
    details: models.ReleaseSignDuplicatePathDetails;
    ok?: false | undefined;
    message?: string | undefined;
};
export declare class ReleaseSignDuplicatePathError extends InterfereHTTPError {
    code: "COLLECTOR_RELEASE_SIGN_DUPLICATE_PATH";
    details: models.ReleaseSignDuplicatePathDetails;
    ok?: false | undefined;
    /** The original data that was passed to this error instance. */
    data$: ReleaseSignDuplicatePathErrorData;
    constructor(err: ReleaseSignDuplicatePathErrorData, httpMeta: {
        response: Response;
        request: Request;
        body: string;
    });
}
export type ReleaseSignFileTooLargeErrorData = {
    code: "COLLECTOR_RELEASE_SIGN_FILE_TOO_LARGE";
    details: models.ReleaseSignFileTooLargeDetails;
    ok?: false | undefined;
    message?: string | undefined;
};
export declare class ReleaseSignFileTooLargeError extends InterfereHTTPError {
    code: "COLLECTOR_RELEASE_SIGN_FILE_TOO_LARGE";
    details: models.ReleaseSignFileTooLargeDetails;
    ok?: false | undefined;
    /** The original data that was passed to this error instance. */
    data$: ReleaseSignFileTooLargeErrorData;
    constructor(err: ReleaseSignFileTooLargeErrorData, httpMeta: {
        response: Response;
        request: Request;
        body: string;
    });
}
export type ReleaseSignTooManyFilesErrorData = {
    code: "COLLECTOR_RELEASE_SIGN_TOO_MANY_FILES";
    details: models.ReleaseSignTooManyFilesDetails;
    ok?: false | undefined;
    message?: string | undefined;
};
export declare class ReleaseSignTooManyFilesError extends InterfereHTTPError {
    code: "COLLECTOR_RELEASE_SIGN_TOO_MANY_FILES";
    details: models.ReleaseSignTooManyFilesDetails;
    ok?: false | undefined;
    /** The original data that was passed to this error instance. */
    data$: ReleaseSignTooManyFilesErrorData;
    constructor(err: ReleaseSignTooManyFilesErrorData, httpMeta: {
        response: Response;
        request: Request;
        body: string;
    });
}
export type CollectorBareErrorData = {
    code: models.CollectorBareErrorCode;
    ok?: false | undefined;
    message?: string | undefined;
};
export declare class CollectorBareError extends InterfereHTTPError {
    code: models.CollectorBareErrorCode;
    ok?: false | undefined;
    /** The original data that was passed to this error instance. */
    data$: CollectorBareErrorData;
    constructor(err: CollectorBareErrorData, httpMeta: {
        response: Response;
        request: Request;
        body: string;
    });
}
export type ValidationErrorData = {
    code: "VALIDATION";
    details?: models.ValidationErrorDetails | undefined;
    ok?: false | undefined;
    message?: string | undefined;
};
export declare class ValidationError extends InterfereHTTPError {
    code: "VALIDATION";
    details?: models.ValidationErrorDetails | undefined;
    ok?: false | undefined;
    /** The original data that was passed to this error instance. */
    data$: ValidationErrorData;
    constructor(err: ValidationErrorData, httpMeta: {
        response: Response;
        request: Request;
        body: string;
    });
}
export type LibraryBareErrorData = {
    code: models.LibraryBareErrorCode;
    ok?: false | undefined;
    message?: string | undefined;
};
export declare class LibraryBareError extends InterfereHTTPError {
    code: models.LibraryBareErrorCode;
    ok?: false | undefined;
    /** The original data that was passed to this error instance. */
    data$: LibraryBareErrorData;
    constructor(err: LibraryBareErrorData, httpMeta: {
        response: Response;
        request: Request;
        body: string;
    });
}
export type ErrorsProblem = (LibraryBareError & {
    code: "PARSE";
}) | (LibraryBareError & {
    code: "NOT_FOUND";
}) | (LibraryBareError & {
    code: "INTERNAL_SERVER_ERROR";
}) | (LibraryBareError & {
    code: "INVALID_FILE_TYPE";
}) | (LibraryBareError & {
    code: "INVALID_COOKIE_SIGNATURE";
}) | (LibraryBareError & {
    code: "UNKNOWN";
}) | ValidationError | (CollectorBareError & {
    code: "COLLECTOR_AUTH_MISSING";
}) | (CollectorBareError & {
    code: "COLLECTOR_AUTH_API_KEY_REQUIRED";
}) | (CollectorBareError & {
    code: "COLLECTOR_AUTH_API_KEY_INVALID";
}) | (CollectorBareError & {
    code: "COLLECTOR_AUTH_PUB_TOKEN_INVALID";
}) | (CollectorBareError & {
    code: "COLLECTOR_AUTH_PUB_TOKEN_NOT_ALLOWED";
}) | (CollectorBareError & {
    code: "COLLECTOR_AUTH_API_KEY_NOT_ALLOWED";
}) | (CollectorBareError & {
    code: "COLLECTOR_RELEASE_NOT_FOUND";
}) | (CollectorBareError & {
    code: "COLLECTOR_RELEASE_MISSING_BUILD_ID";
}) | (CollectorBareError & {
    code: "COLLECTOR_RELEASE_SIGN_EMPTY";
}) | (CollectorBareError & {
    code: "COLLECTOR_RELEASE_PREFLIGHT_UNCONFIRMED";
}) | (CollectorBareError & {
    code: "COLLECTOR_INGEST_BACKPRESSURE";
}) | (CollectorBareError & {
    code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE";
}) | (CollectorBareError & {
    code: "COLLECTOR_OTLP_PRODUCER_REJECTED";
}) | (CollectorBareError & {
    code: "COLLECTOR_OTLP_INVALID_SEMCONV";
}) | (CollectorBareError & {
    code: "COLLECTOR_OTLP_MALFORMED_PAYLOAD";
}) | (CollectorBareError & {
    code: "COLLECTOR_OTLP_UNSUPPORTED_CONTENT_TYPE";
}) | (CollectorBareError & {
    code: "COLLECTOR_REPLAY_UPLOAD_REJECTED";
}) | (CollectorBareError & {
    code: "COLLECTOR_SDK_TOO_OLD";
}) | ReleaseSignTooManyFilesError | ReleaseSignFileTooLargeError | ReleaseSignDuplicatePathError;
/** @internal */
export declare const ReleaseSignDuplicatePathError$inboundSchema: z.ZodMiniType<ReleaseSignDuplicatePathError, unknown>;
/** @internal */
export declare const ReleaseSignFileTooLargeError$inboundSchema: z.ZodMiniType<ReleaseSignFileTooLargeError, unknown>;
/** @internal */
export declare const ReleaseSignTooManyFilesError$inboundSchema: z.ZodMiniType<ReleaseSignTooManyFilesError, unknown>;
/** @internal */
export declare const CollectorBareError$inboundSchema: z.ZodMiniType<CollectorBareError, unknown>;
/** @internal */
export declare const ValidationError$inboundSchema: z.ZodMiniType<ValidationError, unknown>;
/** @internal */
export declare const LibraryBareError$inboundSchema: z.ZodMiniType<LibraryBareError, unknown>;
/** @internal */
export declare const ErrorsProblem$inboundSchema: z.ZodMiniType<ErrorsProblem, unknown>;
export declare function errorsProblemFromJSON(jsonString: string): SafeParseResult<ErrorsProblem, SDKValidationError>;
//# sourceMappingURL=errors-problem.d.ts.map