import { InterfereHTTPError } from "./interfere-http-error.js";
/** The fallback error class if no more specific error class is matched */
export declare class InterfereError extends InterfereHTTPError {
    constructor(message: string, httpMeta: {
        response: Response;
        request: Request;
        body: string;
    });
}
//# sourceMappingURL=interfere-error.d.ts.map