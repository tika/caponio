import * as z from "zod/v4-mini";
/**
 * Payload for a pageview envelope.
 */
export type PageviewPayload = {
    url: string;
    title?: string | undefined;
};
/** @internal */
export type PageviewPayload$Outbound = {
    url: string;
    title?: string | undefined;
};
/** @internal */
export declare const PageviewPayload$outboundSchema: z.ZodMiniType<PageviewPayload$Outbound, PageviewPayload>;
export declare function pageviewPayloadToJSON(pageviewPayload: PageviewPayload): string;
//# sourceMappingURL=pageview-payload.d.ts.map