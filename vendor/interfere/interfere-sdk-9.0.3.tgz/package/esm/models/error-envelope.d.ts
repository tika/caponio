import * as z from "zod/v4-mini";
import { EnvelopeContext, EnvelopeContext$Outbound } from "./envelope-context.js";
import { Environment } from "./environment.js";
import { ErrorPayload, ErrorPayload$Outbound } from "./error-payload.js";
import { RuntimeEnum } from "./runtime-enum.js";
import { SessionSource } from "./session-source.js";
export type ErrorEnvelope = {
    type: "error";
    buildId: string;
    clientTs: number;
    context?: EnvelopeContext | undefined;
    /**
     * Deployment environment the SDK is running in.
     */
    environment: Environment | null;
    producerVersion?: string | undefined;
    releaseId: string | null;
    /**
     * JavaScript runtime the SDK is running in.
     */
    runtime: RuntimeEnum | null;
    sdkStack?: Array<string> | undefined;
    sessionId: string | null;
    /**
     * How the server resolved the sessionId for this envelope.
     */
    sessionSource?: SessionSource | undefined;
    uuid: string;
    v: number;
    /**
     * Payload for an error envelope.
     */
    payload: ErrorPayload;
};
/** @internal */
export type ErrorEnvelope$Outbound = {
    type: "error";
    buildId: string;
    clientTs: number;
    context?: EnvelopeContext$Outbound | undefined;
    environment: string | null;
    producerVersion?: string | undefined;
    releaseId: string | null;
    runtime: string | null;
    sdkStack?: Array<string> | undefined;
    sessionId: string | null;
    sessionSource?: string | undefined;
    uuid: string;
    v: number;
    payload: ErrorPayload$Outbound;
};
/** @internal */
export declare const ErrorEnvelope$outboundSchema: z.ZodMiniType<ErrorEnvelope$Outbound, ErrorEnvelope>;
export declare function errorEnvelopeToJSON(errorEnvelope: ErrorEnvelope): string;
//# sourceMappingURL=error-envelope.d.ts.map