import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
import { SignSourceMapUpload } from "./sign-source-map-upload.js";
export type ReleasesSignSourceMapsResponse = {
    uploads: Array<SignSourceMapUpload>;
    expiresAt: number;
};
/** @internal */
export declare const ReleasesSignSourceMapsResponse$inboundSchema: z.ZodMiniType<ReleasesSignSourceMapsResponse, unknown>;
export declare function releasesSignSourceMapsResponseFromJSON(jsonString: string): SafeParseResult<ReleasesSignSourceMapsResponse, SDKValidationError>;
//# sourceMappingURL=releases-sign-source-maps-response.d.ts.map