import * as z from "zod/v4-mini";
import { ClosedEnum } from "../types/enums.js";
export declare const ManifestBundler: {
    readonly Webpack: "webpack";
    readonly Turbopack: "turbopack";
};
export type ManifestBundler = ClosedEnum<typeof ManifestBundler>;
/** @internal */
export declare const ManifestBundler$outboundSchema: z.ZodMiniEnum<typeof ManifestBundler>;
//# sourceMappingURL=manifest-bundler.d.ts.map