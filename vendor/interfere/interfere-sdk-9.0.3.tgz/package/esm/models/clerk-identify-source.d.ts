import * as z from "zod/v4-mini";
import { ClosedEnum } from "../types/enums.js";
export declare const ClerkIdentifySourceName: {
    readonly Clerk: "Clerk";
};
export type ClerkIdentifySourceName = ClosedEnum<typeof ClerkIdentifySourceName>;
export type ClerkIdentifySource = {
    name: ClerkIdentifySourceName;
    type: "clerk";
};
/** @internal */
export declare const ClerkIdentifySourceName$outboundSchema: z.ZodMiniEnum<typeof ClerkIdentifySourceName>;
/** @internal */
export type ClerkIdentifySource$Outbound = {
    name: string;
    type: "clerk";
};
/** @internal */
export declare const ClerkIdentifySource$outboundSchema: z.ZodMiniType<ClerkIdentifySource$Outbound, ClerkIdentifySource>;
export declare function clerkIdentifySourceToJSON(clerkIdentifySource: ClerkIdentifySource): string;
//# sourceMappingURL=clerk-identify-source.d.ts.map