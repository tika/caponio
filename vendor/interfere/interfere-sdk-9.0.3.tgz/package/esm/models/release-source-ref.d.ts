import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type ReleaseSourceRef = {
    id: string;
};
/** @internal */
export declare const ReleaseSourceRef$inboundSchema: z.ZodMiniType<ReleaseSourceRef, unknown>;
export declare function releaseSourceRefFromJSON(jsonString: string): SafeParseResult<ReleaseSourceRef, SDKValidationError>;
//# sourceMappingURL=release-source-ref.d.ts.map