import * as z from "zod/v4-mini";
import { DeviceBrowser, DeviceBrowser$Outbound } from "./device-browser.js";
import { DeviceCpu, DeviceCpu$Outbound } from "./device-cpu.js";
import { DeviceEngine, DeviceEngine$Outbound } from "./device-engine.js";
import { DeviceInfo, DeviceInfo$Outbound } from "./device-info.js";
import { DeviceOs, DeviceOs$Outbound } from "./device-os.js";
import { Display, Display$Outbound } from "./display.js";
/**
 * Browser locale and display metadata.
 */
export type BrowserMetadata = {
    language?: string | undefined;
    timezone?: string | undefined;
    display: Display;
};
/**
 * Device/browser metadata extracted from the user agent.
 */
export type DeviceMetadata = {
    browser: DeviceBrowser;
    cpu: DeviceCpu;
    device: DeviceInfo;
    engine: DeviceEngine;
    os: DeviceOs;
    ua: string;
};
/**
 * Request context for the browser runtime.
 */
export type BrowserContext = {
    runtime: "browser";
    browser: BrowserMetadata | null;
    device: DeviceMetadata | null;
};
/** @internal */
export type BrowserMetadata$Outbound = {
    language?: string | undefined;
    timezone?: string | undefined;
    display: Display$Outbound;
};
/** @internal */
export declare const BrowserMetadata$outboundSchema: z.ZodMiniType<BrowserMetadata$Outbound, BrowserMetadata>;
export declare function browserMetadataToJSON(browserMetadata: BrowserMetadata): string;
/** @internal */
export type DeviceMetadata$Outbound = {
    browser: DeviceBrowser$Outbound;
    cpu: DeviceCpu$Outbound;
    device: DeviceInfo$Outbound;
    engine: DeviceEngine$Outbound;
    os: DeviceOs$Outbound;
    ua: string;
};
/** @internal */
export declare const DeviceMetadata$outboundSchema: z.ZodMiniType<DeviceMetadata$Outbound, DeviceMetadata>;
export declare function deviceMetadataToJSON(deviceMetadata: DeviceMetadata): string;
/** @internal */
export type BrowserContext$Outbound = {
    runtime: "browser";
    browser: BrowserMetadata$Outbound | null;
    device: DeviceMetadata$Outbound | null;
};
/** @internal */
export declare const BrowserContext$outboundSchema: z.ZodMiniType<BrowserContext$Outbound, BrowserContext>;
export declare function browserContextToJSON(browserContext: BrowserContext): string;
//# sourceMappingURL=browser-context.d.ts.map