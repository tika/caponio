import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type SignSourceMapUpload = {
    path: string;
    objectKey: string;
    presignedUrl: string;
};
/** @internal */
export declare const SignSourceMapUpload$inboundSchema: z.ZodMiniType<SignSourceMapUpload, unknown>;
export declare function signSourceMapUploadFromJSON(jsonString: string): SafeParseResult<SignSourceMapUpload, SDKValidationError>;
//# sourceMappingURL=sign-source-map-upload.d.ts.map