import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type ReleaseSignTooManyFilesDetails = {
    fileCount: number;
    limit: number;
};
/** @internal */
export declare const ReleaseSignTooManyFilesDetails$inboundSchema: z.ZodMiniType<ReleaseSignTooManyFilesDetails, unknown>;
export declare function releaseSignTooManyFilesDetailsFromJSON(jsonString: string): SafeParseResult<ReleaseSignTooManyFilesDetails, SDKValidationError>;
//# sourceMappingURL=release-sign-too-many-files-details.d.ts.map