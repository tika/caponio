import * as z from "zod/v4-mini";
import { ClosedEnum } from "../types/enums.js";
export declare const GithubReleaseSourceProvider: {
    readonly Github: "github";
};
export type GithubReleaseSourceProvider = ClosedEnum<typeof GithubReleaseSourceProvider>;
/**
 * Release source metadata coming from GitHub.
 */
export type GithubReleaseSource = {
    provider: GithubReleaseSourceProvider;
    commitMessage: string;
    branch: string;
    commitSha: string | null;
};
/** @internal */
export declare const GithubReleaseSourceProvider$outboundSchema: z.ZodMiniEnum<typeof GithubReleaseSourceProvider>;
/** @internal */
export type GithubReleaseSource$Outbound = {
    provider: string;
    commitMessage: string;
    branch: string;
    commitSha: string | null;
};
/** @internal */
export declare const GithubReleaseSource$outboundSchema: z.ZodMiniType<GithubReleaseSource$Outbound, GithubReleaseSource>;
export declare function githubReleaseSourceToJSON(githubReleaseSource: GithubReleaseSource): string;
//# sourceMappingURL=github-release-source.d.ts.map