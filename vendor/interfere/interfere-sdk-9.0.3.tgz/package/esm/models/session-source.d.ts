import * as z from "zod/v4-mini";
import { ClosedEnum } from "../types/enums.js";
/**
 * How the server resolved the sessionId for this envelope.
 */
export declare const SessionSource: {
    readonly Header: "header";
    readonly AsyncContext: "async_context";
    readonly Fallback: "fallback";
    readonly Client: "client";
};
/**
 * How the server resolved the sessionId for this envelope.
 */
export type SessionSource = ClosedEnum<typeof SessionSource>;
/** @internal */
export declare const SessionSource$outboundSchema: z.ZodMiniEnum<typeof SessionSource>;
//# sourceMappingURL=session-source.d.ts.map