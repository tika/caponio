import * as z from "zod/v4-mini";
import { MultipartFile, MultipartFile$Outbound } from "./multipart-file.js";
import { UploadSourceMapsMetadata, UploadSourceMapsMetadata$Outbound } from "./upload-source-maps-metadata.js";
export type Files = MultipartFile | Array<MultipartFile>;
/**
 * Multipart body for uploading source maps for a release.
 */
export type ReleasesUploadSourceMapsRequest = {
    files: MultipartFile | Array<MultipartFile>;
    /**
     * Metadata attached alongside uploaded source map files.
     */
    metadata: UploadSourceMapsMetadata;
};
/** @internal */
export type Files$Outbound = MultipartFile$Outbound | Array<MultipartFile$Outbound>;
/** @internal */
export declare const Files$outboundSchema: z.ZodMiniType<Files$Outbound, Files>;
export declare function filesToJSON(files: Files): string;
/** @internal */
export type ReleasesUploadSourceMapsRequest$Outbound = {
    files: MultipartFile$Outbound | Array<MultipartFile$Outbound>;
    metadata: UploadSourceMapsMetadata$Outbound;
};
/** @internal */
export declare const ReleasesUploadSourceMapsRequest$outboundSchema: z.ZodMiniType<ReleasesUploadSourceMapsRequest$Outbound, ReleasesUploadSourceMapsRequest>;
export declare function releasesUploadSourceMapsRequestToJSON(releasesUploadSourceMapsRequest: ReleasesUploadSourceMapsRequest): string;
//# sourceMappingURL=releases-upload-source-maps-request.d.ts.map