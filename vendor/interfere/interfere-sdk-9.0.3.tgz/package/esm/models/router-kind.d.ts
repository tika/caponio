import * as z from "zod/v4-mini";
import { ClosedEnum } from "../types/enums.js";
export declare const RouterKind: {
    readonly PagesRouter: "Pages Router";
    readonly AppRouter: "App Router";
};
export type RouterKind = ClosedEnum<typeof RouterKind>;
/** @internal */
export declare const RouterKind$outboundSchema: z.ZodMiniEnum<typeof RouterKind>;
//# sourceMappingURL=router-kind.d.ts.map