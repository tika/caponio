import * as z from "zod/v4-mini";
import { OpenEnum } from "../types/enums.js";
export declare const CollectorBareErrorCode: {
    readonly CollectorAuthMissing: "COLLECTOR_AUTH_MISSING";
    readonly CollectorAuthApiKeyRequired: "COLLECTOR_AUTH_API_KEY_REQUIRED";
    readonly CollectorAuthApiKeyInvalid: "COLLECTOR_AUTH_API_KEY_INVALID";
    readonly CollectorAuthPubTokenInvalid: "COLLECTOR_AUTH_PUB_TOKEN_INVALID";
    readonly CollectorAuthPubTokenNotAllowed: "COLLECTOR_AUTH_PUB_TOKEN_NOT_ALLOWED";
    readonly CollectorAuthApiKeyNotAllowed: "COLLECTOR_AUTH_API_KEY_NOT_ALLOWED";
    readonly CollectorReleaseNotFound: "COLLECTOR_RELEASE_NOT_FOUND";
    readonly CollectorReleaseMissingBuildId: "COLLECTOR_RELEASE_MISSING_BUILD_ID";
    readonly CollectorReleaseSignEmpty: "COLLECTOR_RELEASE_SIGN_EMPTY";
    readonly CollectorReleasePreflightUnconfirmed: "COLLECTOR_RELEASE_PREFLIGHT_UNCONFIRMED";
    readonly CollectorIngestBackpressure: "COLLECTOR_INGEST_BACKPRESSURE";
    readonly CollectorIngestInfraUnavailable: "COLLECTOR_INGEST_INFRA_UNAVAILABLE";
    readonly CollectorOtlpProducerRejected: "COLLECTOR_OTLP_PRODUCER_REJECTED";
    readonly CollectorOtlpInvalidSemconv: "COLLECTOR_OTLP_INVALID_SEMCONV";
    readonly CollectorOtlpMalformedPayload: "COLLECTOR_OTLP_MALFORMED_PAYLOAD";
    readonly CollectorOtlpUnsupportedContentType: "COLLECTOR_OTLP_UNSUPPORTED_CONTENT_TYPE";
    readonly CollectorReplayUploadRejected: "COLLECTOR_REPLAY_UPLOAD_REJECTED";
    readonly CollectorSDKTooOld: "COLLECTOR_SDK_TOO_OLD";
};
export type CollectorBareErrorCode = OpenEnum<typeof CollectorBareErrorCode>;
export declare const LibraryBareErrorCode: {
    readonly Parse: "PARSE";
    readonly NotFound: "NOT_FOUND";
    readonly InternalServerError: "INTERNAL_SERVER_ERROR";
    readonly InvalidFileType: "INVALID_FILE_TYPE";
    readonly InvalidCookieSignature: "INVALID_COOKIE_SIGNATURE";
    readonly Unknown: "UNKNOWN";
};
export type LibraryBareErrorCode = OpenEnum<typeof LibraryBareErrorCode>;
/** @internal */
export declare const CollectorBareErrorCode$inboundSchema: z.ZodMiniType<CollectorBareErrorCode, unknown>;
/** @internal */
export declare const LibraryBareErrorCode$inboundSchema: z.ZodMiniType<LibraryBareErrorCode, unknown>;
//# sourceMappingURL=errors-problem.d.ts.map