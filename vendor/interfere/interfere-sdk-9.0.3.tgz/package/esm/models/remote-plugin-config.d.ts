import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type RemotePluginConfig = {
    errors: boolean;
    device: boolean;
    pageEvents: boolean;
    rageClick: boolean;
    replay: boolean;
    logs: boolean;
};
/** @internal */
export declare const RemotePluginConfig$inboundSchema: z.ZodMiniType<RemotePluginConfig, unknown>;
export declare function remotePluginConfigFromJSON(jsonString: string): SafeParseResult<RemotePluginConfig, SDKValidationError>;
//# sourceMappingURL=remote-plugin-config.d.ts.map