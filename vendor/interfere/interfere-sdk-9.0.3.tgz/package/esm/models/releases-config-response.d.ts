import * as z from "zod/v4-mini";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export declare const SourceProvider: {
    readonly Github: "github";
};
export type SourceProvider = ClosedEnum<typeof SourceProvider>;
export declare const DestinationProvider: {
    readonly Vercel: "vercel";
};
export type DestinationProvider = ClosedEnum<typeof DestinationProvider>;
export type Plugins = {
    errors?: boolean | undefined;
    device?: boolean | undefined;
    pageEvents?: boolean | undefined;
    rageClick?: boolean | undefined;
    replay?: boolean | undefined;
    logs?: boolean | undefined;
};
export type SDKConfig = {
    plugins?: Plugins | undefined;
};
export type Surface = {
    id: string;
    slug: string;
    allowDirectIngestion: boolean;
    environmentFiltering: boolean;
    sourceProvider: SourceProvider | null;
    destinationProvider: DestinationProvider | null;
    sdkConfig: SDKConfig | null;
};
export type Org = {
    id: string;
    slug: string;
};
export type ReleasesConfigResponse = {
    surface: Surface;
    org: Org;
};
/** @internal */
export declare const SourceProvider$inboundSchema: z.ZodMiniEnum<typeof SourceProvider>;
/** @internal */
export declare const DestinationProvider$inboundSchema: z.ZodMiniEnum<typeof DestinationProvider>;
/** @internal */
export declare const Plugins$inboundSchema: z.ZodMiniType<Plugins, unknown>;
export declare function pluginsFromJSON(jsonString: string): SafeParseResult<Plugins, SDKValidationError>;
/** @internal */
export declare const SDKConfig$inboundSchema: z.ZodMiniType<SDKConfig, unknown>;
export declare function sdkConfigFromJSON(jsonString: string): SafeParseResult<SDKConfig, SDKValidationError>;
/** @internal */
export declare const Surface$inboundSchema: z.ZodMiniType<Surface, unknown>;
export declare function surfaceFromJSON(jsonString: string): SafeParseResult<Surface, SDKValidationError>;
/** @internal */
export declare const Org$inboundSchema: z.ZodMiniType<Org, unknown>;
export declare function orgFromJSON(jsonString: string): SafeParseResult<Org, SDKValidationError>;
/** @internal */
export declare const ReleasesConfigResponse$inboundSchema: z.ZodMiniType<ReleasesConfigResponse, unknown>;
export declare function releasesConfigResponseFromJSON(jsonString: string): SafeParseResult<ReleasesConfigResponse, SDKValidationError>;
//# sourceMappingURL=releases-config-response.d.ts.map