import * as z from "zod/v4-mini";
import { RenderSource } from "./render-source.js";
import { RenderType } from "./render-type.js";
import { RevalidateReason } from "./revalidate-reason.js";
import { RouteType } from "./route-type.js";
import { RouterKind } from "./router-kind.js";
/**
 * Request context for the Next.js runtime.
 */
export type NextjsContext = {
    errorDigest?: string | undefined;
    renderSource?: RenderSource | undefined;
    renderType?: RenderType | undefined;
    requestMethod?: string | undefined;
    requestPath?: string | undefined;
    revalidateReason?: RevalidateReason | undefined;
    routePath?: string | undefined;
    routeType?: RouteType | undefined;
    routerKind?: RouterKind | undefined;
    runtime: "nextjs";
};
/** @internal */
export type NextjsContext$Outbound = {
    errorDigest?: string | undefined;
    renderSource?: string | undefined;
    renderType?: string | undefined;
    requestMethod?: string | undefined;
    requestPath?: string | undefined;
    revalidateReason?: string | undefined;
    routePath?: string | undefined;
    routeType?: string | undefined;
    routerKind?: string | undefined;
    runtime: "nextjs";
};
/** @internal */
export declare const NextjsContext$outboundSchema: z.ZodMiniType<NextjsContext$Outbound, NextjsContext>;
export declare function nextjsContextToJSON(nextjsContext: NextjsContext): string;
//# sourceMappingURL=nextjs-context.d.ts.map