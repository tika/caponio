import * as z from "zod/v4-mini";
import { EnvelopeContext, EnvelopeContext$Outbound } from "./envelope-context.js";
import { Environment } from "./environment.js";
import { RageClickPayload, RageClickPayload$Outbound } from "./rage-click-payload.js";
import { RuntimeEnum } from "./runtime-enum.js";
import { SessionSource } from "./session-source.js";
export type RageClickEnvelope = {
    type: "rage_click";
    buildId: string;
    clientTs: number;
    context?: EnvelopeContext | undefined;
    /**
     * Deployment environment the SDK is running in.
     */
    environment: Environment | null;
    producerVersion?: string | undefined;
    releaseId: string | null;
    /**
     * JavaScript runtime the SDK is running in.
     */
    runtime: RuntimeEnum | null;
    sdkStack?: Array<string> | undefined;
    sessionId: string | null;
    /**
     * How the server resolved the sessionId for this envelope.
     */
    sessionSource?: SessionSource | undefined;
    uuid: string;
    v: number;
    /**
     * Payload for a rage-click envelope.
     */
    payload: RageClickPayload;
};
/** @internal */
export type RageClickEnvelope$Outbound = {
    type: "rage_click";
    buildId: string;
    clientTs: number;
    context?: EnvelopeContext$Outbound | undefined;
    environment: string | null;
    producerVersion?: string | undefined;
    releaseId: string | null;
    runtime: string | null;
    sdkStack?: Array<string> | undefined;
    sessionId: string | null;
    sessionSource?: string | undefined;
    uuid: string;
    v: number;
    payload: RageClickPayload$Outbound;
};
/** @internal */
export declare const RageClickEnvelope$outboundSchema: z.ZodMiniType<RageClickEnvelope$Outbound, RageClickEnvelope>;
export declare function rageClickEnvelopeToJSON(rageClickEnvelope: RageClickEnvelope): string;
//# sourceMappingURL=rage-click-envelope.d.ts.map