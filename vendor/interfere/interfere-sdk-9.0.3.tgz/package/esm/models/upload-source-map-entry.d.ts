import * as z from "zod/v4-mini";
export type UploadSourceMapEntry = {
    path: string;
    hash: string;
    debugId: string;
    chunkUrl: string;
};
/** @internal */
export type UploadSourceMapEntry$Outbound = {
    path: string;
    hash: string;
    debugId: string;
    chunkUrl: string;
};
/** @internal */
export declare const UploadSourceMapEntry$outboundSchema: z.ZodMiniType<UploadSourceMapEntry$Outbound, UploadSourceMapEntry>;
export declare function uploadSourceMapEntryToJSON(uploadSourceMapEntry: UploadSourceMapEntry): string;
//# sourceMappingURL=upload-source-map-entry.d.ts.map