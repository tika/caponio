import * as z from "zod/v4-mini";
import { ClosedEnum } from "../types/enums.js";
export declare const Auth0IdentifySourceName: {
    readonly Auth0: "Auth0";
};
export type Auth0IdentifySourceName = ClosedEnum<typeof Auth0IdentifySourceName>;
export type Auth0IdentifySource = {
    name: Auth0IdentifySourceName;
    type: "auth0";
};
/** @internal */
export declare const Auth0IdentifySourceName$outboundSchema: z.ZodMiniEnum<typeof Auth0IdentifySourceName>;
/** @internal */
export type Auth0IdentifySource$Outbound = {
    name: string;
    type: "auth0";
};
/** @internal */
export declare const Auth0IdentifySource$outboundSchema: z.ZodMiniType<Auth0IdentifySource$Outbound, Auth0IdentifySource>;
export declare function auth0IdentifySourceToJSON(auth0IdentifySource: Auth0IdentifySource): string;
//# sourceMappingURL=auth0-identify-source.d.ts.map