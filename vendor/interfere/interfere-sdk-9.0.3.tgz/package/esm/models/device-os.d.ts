import * as z from "zod/v4-mini";
export type DeviceOs = {
    version?: string | undefined;
    name?: string | undefined;
};
/** @internal */
export type DeviceOs$Outbound = {
    version?: string | undefined;
    name?: string | undefined;
};
/** @internal */
export declare const DeviceOs$outboundSchema: z.ZodMiniType<DeviceOs$Outbound, DeviceOs>;
export declare function deviceOsToJSON(deviceOs: DeviceOs): string;
//# sourceMappingURL=device-os.d.ts.map