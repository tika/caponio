import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type ReleasesTelemetryResponse = {
    ok: boolean;
};
/** @internal */
export declare const ReleasesTelemetryResponse$inboundSchema: z.ZodMiniType<ReleasesTelemetryResponse, unknown>;
export declare function releasesTelemetryResponseFromJSON(jsonString: string): SafeParseResult<ReleasesTelemetryResponse, SDKValidationError>;
//# sourceMappingURL=releases-telemetry-response.d.ts.map