import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type ReleaseSignDuplicatePathDetails = {
    path: string;
};
/** @internal */
export declare const ReleaseSignDuplicatePathDetails$inboundSchema: z.ZodMiniType<ReleaseSignDuplicatePathDetails, unknown>;
export declare function releaseSignDuplicatePathDetailsFromJSON(jsonString: string): SafeParseResult<ReleaseSignDuplicatePathDetails, SDKValidationError>;
//# sourceMappingURL=release-sign-duplicate-path-details.d.ts.map