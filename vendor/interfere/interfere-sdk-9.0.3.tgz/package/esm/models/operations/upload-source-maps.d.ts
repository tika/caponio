import * as z from "zod/v4-mini";
import * as models from "../index.js";
export type UploadSourceMapsRequest = {
    releaseSlug: string;
    /**
     * Multipart body for uploading source maps for a release.
     */
    body: models.ReleasesUploadSourceMapsRequest;
};
/** @internal */
export type UploadSourceMapsRequest$Outbound = {
    releaseSlug: string;
    body: models.ReleasesUploadSourceMapsRequest$Outbound;
};
/** @internal */
export declare const UploadSourceMapsRequest$outboundSchema: z.ZodMiniType<UploadSourceMapsRequest$Outbound, UploadSourceMapsRequest>;
export declare function uploadSourceMapsRequestToJSON(uploadSourceMapsRequest: UploadSourceMapsRequest): string;
//# sourceMappingURL=upload-source-maps.d.ts.map