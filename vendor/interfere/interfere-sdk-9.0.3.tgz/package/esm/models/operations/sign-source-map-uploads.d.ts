import * as z from "zod/v4-mini";
import * as models from "../index.js";
export type SignSourceMapUploadsRequest = {
    releaseSlug: string;
    /**
     * Per-file metadata the SDK uses to obtain presigned PUT URLs. The server validates per-file size and total file count, then issues short-lived URLs scoped to the release's R2 prefix. The SDK uploads to R2 directly and follows up with a `complete` call to materialize the manifest.
     */
    body: models.ReleasesSignSourceMapsRequest;
};
/** @internal */
export type SignSourceMapUploadsRequest$Outbound = {
    releaseSlug: string;
    body: models.ReleasesSignSourceMapsRequest$Outbound;
};
/** @internal */
export declare const SignSourceMapUploadsRequest$outboundSchema: z.ZodMiniType<SignSourceMapUploadsRequest$Outbound, SignSourceMapUploadsRequest>;
export declare function signSourceMapUploadsRequestToJSON(signSourceMapUploadsRequest: SignSourceMapUploadsRequest): string;
//# sourceMappingURL=sign-source-map-uploads.d.ts.map