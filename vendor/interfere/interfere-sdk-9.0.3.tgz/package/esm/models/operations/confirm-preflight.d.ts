import * as z from "zod/v4-mini";
export type ConfirmPreflightRequest = {
    releaseSlug: string;
};
/** @internal */
export type ConfirmPreflightRequest$Outbound = {
    releaseSlug: string;
};
/** @internal */
export declare const ConfirmPreflightRequest$outboundSchema: z.ZodMiniType<ConfirmPreflightRequest$Outbound, ConfirmPreflightRequest>;
export declare function confirmPreflightRequestToJSON(confirmPreflightRequest: ConfirmPreflightRequest): string;
//# sourceMappingURL=confirm-preflight.d.ts.map