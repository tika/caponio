import * as z from "zod/v4-mini";
import * as models from "../index.js";
export type ReportTelemetryRequest = {
    releaseSlug: string;
    /**
     * Timings and counters reported after a source-map upload.
     */
    body: models.ReleasesTelemetryRequest;
};
/** @internal */
export type ReportTelemetryRequest$Outbound = {
    releaseSlug: string;
    body: models.ReleasesTelemetryRequest$Outbound;
};
/** @internal */
export declare const ReportTelemetryRequest$outboundSchema: z.ZodMiniType<ReportTelemetryRequest$Outbound, ReportTelemetryRequest>;
export declare function reportTelemetryRequestToJSON(reportTelemetryRequest: ReportTelemetryRequest): string;
//# sourceMappingURL=report-telemetry.d.ts.map