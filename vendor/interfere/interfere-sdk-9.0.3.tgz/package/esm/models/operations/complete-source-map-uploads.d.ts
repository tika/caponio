import * as z from "zod/v4-mini";
import * as models from "../index.js";
export type CompleteSourceMapUploadsRequest = {
    releaseSlug: string;
    /**
     * Finalizes a presigned-URL upload batch. Writes the source-map manifest and updates the release's `sourceMapCount` / `sourceFileCount`. Idempotent — safe to retry.
     */
    body: models.ReleasesCompleteSourceMapsRequest;
};
/** @internal */
export type CompleteSourceMapUploadsRequest$Outbound = {
    releaseSlug: string;
    body: models.ReleasesCompleteSourceMapsRequest$Outbound;
};
/** @internal */
export declare const CompleteSourceMapUploadsRequest$outboundSchema: z.ZodMiniType<CompleteSourceMapUploadsRequest$Outbound, CompleteSourceMapUploadsRequest>;
export declare function completeSourceMapUploadsRequestToJSON(completeSourceMapUploadsRequest: CompleteSourceMapUploadsRequest): string;
//# sourceMappingURL=complete-source-map-uploads.d.ts.map