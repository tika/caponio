import * as z from "zod/v4-mini";
export type UploadReplayChunkRequest = {
    sessionId: string;
    body: Array<string>;
};
/** @internal */
export type UploadReplayChunkRequest$Outbound = {
    sessionId: string;
    body: Array<string>;
};
/** @internal */
export declare const UploadReplayChunkRequest$outboundSchema: z.ZodMiniType<UploadReplayChunkRequest$Outbound, UploadReplayChunkRequest>;
export declare function uploadReplayChunkRequestToJSON(uploadReplayChunkRequest: UploadReplayChunkRequest): string;
//# sourceMappingURL=upload-replay-chunk.d.ts.map