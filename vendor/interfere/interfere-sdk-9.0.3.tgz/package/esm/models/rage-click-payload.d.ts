import * as z from "zod/v4-mini";
/**
 * Payload for a rage-click envelope.
 */
export type RageClickPayload = {
    count: number;
    timeWindow: number;
    selector: string;
    text: string;
    x: number;
    y: number;
    timestamp: number;
};
/** @internal */
export type RageClickPayload$Outbound = {
    count: number;
    timeWindow: number;
    selector: string;
    text: string;
    x: number;
    y: number;
    timestamp: number;
};
/** @internal */
export declare const RageClickPayload$outboundSchema: z.ZodMiniType<RageClickPayload$Outbound, RageClickPayload>;
export declare function rageClickPayloadToJSON(rageClickPayload: RageClickPayload): string;
//# sourceMappingURL=rage-click-payload.d.ts.map