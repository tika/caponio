import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type SinkAcceptedResponse = {
    /**
     * OTLP partial-success envelope; empty object on full acceptance, may carry rejection counters per the OTLP spec.
     */
    partialSuccess: {
        [k: string]: any;
    };
};
/** @internal */
export declare const SinkAcceptedResponse$inboundSchema: z.ZodMiniType<SinkAcceptedResponse, unknown>;
export declare function sinkAcceptedResponseFromJSON(jsonString: string): SafeParseResult<SinkAcceptedResponse, SDKValidationError>;
//# sourceMappingURL=sink-accepted-response.d.ts.map