import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type ReleaseSignFileTooLargeDetails = {
    path: string;
    sizeBytes: number;
    limit: number;
};
/** @internal */
export declare const ReleaseSignFileTooLargeDetails$inboundSchema: z.ZodMiniType<ReleaseSignFileTooLargeDetails, unknown>;
export declare function releaseSignFileTooLargeDetailsFromJSON(jsonString: string): SafeParseResult<ReleaseSignFileTooLargeDetails, SDKValidationError>;
//# sourceMappingURL=release-sign-file-too-large-details.d.ts.map