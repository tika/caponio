import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type ReleaseDestinationRef = {
    id: string;
    slug: string;
    environment: string | null;
};
/** @internal */
export declare const ReleaseDestinationRef$inboundSchema: z.ZodMiniType<ReleaseDestinationRef, unknown>;
export declare function releaseDestinationRefFromJSON(jsonString: string): SafeParseResult<ReleaseDestinationRef, SDKValidationError>;
//# sourceMappingURL=release-destination-ref.d.ts.map