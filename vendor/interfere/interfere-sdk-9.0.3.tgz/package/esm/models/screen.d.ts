import * as z from "zod/v4-mini";
export type Screen = {
    height: number;
    width: number;
    orientation?: string | undefined;
};
/** @internal */
export type Screen$Outbound = {
    height: number;
    width: number;
    orientation?: string | undefined;
};
/** @internal */
export declare const Screen$outboundSchema: z.ZodMiniType<Screen$Outbound, Screen>;
export declare function screenToJSON(screen: Screen): string;
//# sourceMappingURL=screen.d.ts.map