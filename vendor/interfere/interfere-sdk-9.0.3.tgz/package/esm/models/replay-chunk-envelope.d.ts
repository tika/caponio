import * as z from "zod/v4-mini";
import { EnvelopeContext, EnvelopeContext$Outbound } from "./envelope-context.js";
import { Environment } from "./environment.js";
import { ReplayChunkPayload, ReplayChunkPayload$Outbound } from "./replay-chunk-payload.js";
import { RuntimeEnum } from "./runtime-enum.js";
import { SessionSource } from "./session-source.js";
export type ReplayChunkEnvelope = {
    type: "replay_chunk";
    buildId: string;
    clientTs: number;
    context?: EnvelopeContext | undefined;
    /**
     * Deployment environment the SDK is running in.
     */
    environment: Environment | null;
    producerVersion?: string | undefined;
    releaseId: string | null;
    /**
     * JavaScript runtime the SDK is running in.
     */
    runtime: RuntimeEnum | null;
    sdkStack?: Array<string> | undefined;
    sessionId: string | null;
    /**
     * How the server resolved the sessionId for this envelope.
     */
    sessionSource?: SessionSource | undefined;
    uuid: string;
    v: number;
    /**
     * Payload for a replay-chunk envelope.
     */
    payload: ReplayChunkPayload;
};
/** @internal */
export type ReplayChunkEnvelope$Outbound = {
    type: "replay_chunk";
    buildId: string;
    clientTs: number;
    context?: EnvelopeContext$Outbound | undefined;
    environment: string | null;
    producerVersion?: string | undefined;
    releaseId: string | null;
    runtime: string | null;
    sdkStack?: Array<string> | undefined;
    sessionId: string | null;
    sessionSource?: string | undefined;
    uuid: string;
    v: number;
    payload: ReplayChunkPayload$Outbound;
};
/** @internal */
export declare const ReplayChunkEnvelope$outboundSchema: z.ZodMiniType<ReplayChunkEnvelope$Outbound, ReplayChunkEnvelope>;
export declare function replayChunkEnvelopeToJSON(replayChunkEnvelope: ReplayChunkEnvelope): string;
//# sourceMappingURL=replay-chunk-envelope.d.ts.map