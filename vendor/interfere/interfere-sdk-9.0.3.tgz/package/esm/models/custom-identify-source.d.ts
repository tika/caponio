import * as z from "zod/v4-mini";
export type CustomIdentifySource = {
    name: string;
    type: "custom";
};
/** @internal */
export type CustomIdentifySource$Outbound = {
    name: string;
    type: "custom";
};
/** @internal */
export declare const CustomIdentifySource$outboundSchema: z.ZodMiniType<CustomIdentifySource$Outbound, CustomIdentifySource>;
export declare function customIdentifySourceToJSON(customIdentifySource: CustomIdentifySource): string;
//# sourceMappingURL=custom-identify-source.d.ts.map