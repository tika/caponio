import * as z from "zod/v4-mini";
import { ClosedEnum } from "../types/enums.js";
/**
 * Deployment environment the SDK is running in.
 */
export declare const Environment: {
    readonly Development: "development";
    readonly Preview: "preview";
    readonly Production: "production";
};
/**
 * Deployment environment the SDK is running in.
 */
export type Environment = ClosedEnum<typeof Environment>;
/** @internal */
export declare const Environment$outboundSchema: z.ZodMiniEnum<typeof Environment>;
//# sourceMappingURL=environment.d.ts.map