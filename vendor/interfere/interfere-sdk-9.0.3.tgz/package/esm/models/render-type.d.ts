import * as z from "zod/v4-mini";
import { ClosedEnum } from "../types/enums.js";
export declare const RenderType: {
    readonly Dynamic: "dynamic";
    readonly DynamicResume: "dynamic-resume";
};
export type RenderType = ClosedEnum<typeof RenderType>;
/** @internal */
export declare const RenderType$outboundSchema: z.ZodMiniEnum<typeof RenderType>;
//# sourceMappingURL=render-type.d.ts.map