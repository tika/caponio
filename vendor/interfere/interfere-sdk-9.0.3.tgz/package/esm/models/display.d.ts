import * as z from "zod/v4-mini";
import { Screen, Screen$Outbound } from "./screen.js";
export type Display = {
    screen: Screen;
};
/** @internal */
export type Display$Outbound = {
    screen: Screen$Outbound;
};
/** @internal */
export declare const Display$outboundSchema: z.ZodMiniType<Display$Outbound, Display>;
export declare function displayToJSON(display: Display): string;
//# sourceMappingURL=display.d.ts.map