import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
export type SurfaceRef = {
    id: string;
    slug: string;
};
/** @internal */
export declare const SurfaceRef$inboundSchema: z.ZodMiniType<SurfaceRef, unknown>;
export declare function surfaceRefFromJSON(jsonString: string): SafeParseResult<SurfaceRef, SDKValidationError>;
//# sourceMappingURL=surface-ref.d.ts.map