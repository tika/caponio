import * as z from "zod/v4-mini";
export type CompleteSourceMapFile = {
    path: string;
    hash: string;
    debugId: string;
    chunkUrl: string;
};
/** @internal */
export type CompleteSourceMapFile$Outbound = {
    path: string;
    hash: string;
    debugId: string;
    chunkUrl: string;
};
/** @internal */
export declare const CompleteSourceMapFile$outboundSchema: z.ZodMiniType<CompleteSourceMapFile$Outbound, CompleteSourceMapFile>;
export declare function completeSourceMapFileToJSON(completeSourceMapFile: CompleteSourceMapFile): string;
//# sourceMappingURL=complete-source-map-file.d.ts.map