import * as z from "zod/v4-mini";
import { ErrorMechanism, ErrorMechanism$Outbound } from "./error-mechanism.js";
import { Frame, Frame$Outbound } from "./frame.js";
/**
 * A single exception in a chained error.
 */
export type Exception = {
    type: string;
    value: string;
    mechanism?: ErrorMechanism | undefined;
    frames: Array<Frame>;
};
/** @internal */
export type Exception$Outbound = {
    type: string;
    value: string;
    mechanism?: ErrorMechanism$Outbound | undefined;
    frames: Array<Frame$Outbound>;
};
/** @internal */
export declare const Exception$outboundSchema: z.ZodMiniType<Exception$Outbound, Exception>;
export declare function exceptionToJSON(exception: Exception): string;
//# sourceMappingURL=exception.d.ts.map