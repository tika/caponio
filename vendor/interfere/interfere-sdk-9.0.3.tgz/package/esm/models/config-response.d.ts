import * as z from "zod/v4-mini";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdk-validation-error.js";
import { RemotePluginConfig } from "./remote-plugin-config.js";
export type ConfigResponse = {
    plugins: RemotePluginConfig;
};
/** @internal */
export declare const ConfigResponse$inboundSchema: z.ZodMiniType<ConfigResponse, unknown>;
export declare function configResponseFromJSON(jsonString: string): SafeParseResult<ConfigResponse, SDKValidationError>;
//# sourceMappingURL=config-response.d.ts.map