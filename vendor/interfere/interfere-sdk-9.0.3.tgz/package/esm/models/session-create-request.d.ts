import * as z from "zod/v4-mini";
/**
 * Request body for creating a session.
 */
export type SessionCreateRequest = {
    sessionId: string;
    deviceId?: string | null | undefined;
    fpHash?: string | null | undefined;
    visitorId?: string | null | undefined;
};
/** @internal */
export type SessionCreateRequest$Outbound = {
    sessionId: string;
    deviceId?: string | null | undefined;
    fpHash?: string | null | undefined;
    visitorId?: string | null | undefined;
};
/** @internal */
export declare const SessionCreateRequest$outboundSchema: z.ZodMiniType<SessionCreateRequest$Outbound, SessionCreateRequest>;
export declare function sessionCreateRequestToJSON(sessionCreateRequest: SessionCreateRequest): string;
//# sourceMappingURL=session-create-request.d.ts.map