import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
import * as operations from "../models/operations/index.js";
export declare class Telemetry extends ClientSDK {
    report(request: operations.ReportTelemetryRequest, options?: RequestOptions): Promise<models.ReleasesTelemetryResponse>;
}
//# sourceMappingURL=telemetry.d.ts.map