import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
import * as operations from "../models/operations/index.js";
export declare class Replay extends ClientSDK {
    uploadReplayChunk(request: operations.UploadReplayChunkRequest, options?: RequestOptions): Promise<models.ReplayUploadChunkResponse>;
}
//# sourceMappingURL=replay.d.ts.map