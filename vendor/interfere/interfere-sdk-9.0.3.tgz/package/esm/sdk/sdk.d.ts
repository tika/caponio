import { ClientSDK } from "../lib/sdks.js";
import { Config } from "./config.js";
import { Health } from "./health.js";
import { Releases } from "./releases.js";
import { Replay } from "./replay.js";
import { Sessions } from "./sessions.js";
import { SourceMaps } from "./source-maps.js";
import { Telemetry } from "./telemetry.js";
import { V2 } from "./v2.js";
export declare class Interfere extends ClientSDK {
    private _health?;
    get health(): Health;
    private _releases?;
    get releases(): Releases;
    private _sourceMaps?;
    get sourceMaps(): SourceMaps;
    private _telemetry?;
    get telemetry(): Telemetry;
    private _v2?;
    get v2(): V2;
    private _replay?;
    get replay(): Replay;
    private _config?;
    get config(): Config;
    private _sessions?;
    get sessions(): Sessions;
}
//# sourceMappingURL=sdk.d.ts.map