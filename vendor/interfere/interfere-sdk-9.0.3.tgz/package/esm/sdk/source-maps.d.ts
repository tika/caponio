import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
import * as operations from "../models/operations/index.js";
export declare class SourceMaps extends ClientSDK {
    /**
     * @deprecated method: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    upload(request: operations.UploadSourceMapsRequest, options?: RequestOptions): Promise<models.ReleasesUploadSourceMapsResponse>;
    sign(request: operations.SignSourceMapUploadsRequest, options?: RequestOptions): Promise<models.ReleasesSignSourceMapsResponse>;
    complete(request: operations.CompleteSourceMapUploadsRequest, options?: RequestOptions): Promise<models.ReleasesCompleteSourceMapsResponse>;
}
//# sourceMappingURL=source-maps.d.ts.map