import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
export declare class V2 extends ClientSDK {
    v2Sink(options?: RequestOptions): Promise<models.SinkAcceptedResponse>;
}
//# sourceMappingURL=v2.d.ts.map