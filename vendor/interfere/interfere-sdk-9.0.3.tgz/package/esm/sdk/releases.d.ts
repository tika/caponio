import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
import * as operations from "../models/operations/index.js";
export declare class Releases extends ClientSDK {
    getConfig(options?: RequestOptions): Promise<models.ReleasesConfigResponse>;
    create(request: models.ReleasesCreateRequest, options?: RequestOptions): Promise<models.ReleasesCreateResponse>;
    preflight(request: operations.ConfirmPreflightRequest, options?: RequestOptions): Promise<models.ReleasesPreflightResponse>;
}
//# sourceMappingURL=releases.d.ts.map