import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
export declare class Config extends ClientSDK {
    get(options?: RequestOptions): Promise<models.ConfigResponse>;
}
//# sourceMappingURL=config.d.ts.map