import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
export declare class Health extends ClientSDK {
    get(options?: RequestOptions): Promise<models.HealthOk>;
}
//# sourceMappingURL=health.d.ts.map