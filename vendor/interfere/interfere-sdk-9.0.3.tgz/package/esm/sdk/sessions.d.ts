import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
export declare class Sessions extends ClientSDK {
    create(request: models.SessionCreateRequest, options?: RequestOptions): Promise<models.SessionResponse>;
    identify(request: models.SessionIdentifyRequest, options?: RequestOptions): Promise<models.SessionResponse>;
}
//# sourceMappingURL=sessions.d.ts.map