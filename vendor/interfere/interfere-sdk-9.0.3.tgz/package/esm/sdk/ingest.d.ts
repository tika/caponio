import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
export declare class Ingest extends ClientSDK {
    post(request: Array<models.Envelope>, options?: RequestOptions): Promise<models.IngestResponse>;
}
//# sourceMappingURL=ingest.d.ts.map