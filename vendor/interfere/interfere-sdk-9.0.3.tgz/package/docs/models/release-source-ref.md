# ReleaseSourceRef

## Example Usage

```typescript
import { ReleaseSourceRef } from "@interfere/sdk/models";

let value: ReleaseSourceRef = {
  id: "<id>",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `id`               | *string*           | :heavy_check_mark: | N/A                |