# CustomIdentifySource

## Example Usage

```typescript
import { CustomIdentifySource } from "@interfere/sdk/models";

let value: CustomIdentifySource = {
  name: "<value>",
  type: "custom",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `name`             | *string*           | :heavy_check_mark: | N/A                |
| `type`             | *"custom"*         | :heavy_check_mark: | N/A                |