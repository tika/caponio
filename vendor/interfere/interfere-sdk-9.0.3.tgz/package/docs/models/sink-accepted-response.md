# SinkAcceptedResponse

## Example Usage

```typescript
import { SinkAcceptedResponse } from "@interfere/sdk/models";

let value: SinkAcceptedResponse = {
  partialSuccess: {
    "key": "<value>",
    "key1": "<value>",
  },
};
```

## Fields

| Field                                                                                                           | Type                                                                                                            | Required                                                                                                        | Description                                                                                                     |
| --------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------- |
| `partialSuccess`                                                                                                | Record<string, *any*>                                                                                           | :heavy_check_mark:                                                                                              | OTLP partial-success envelope; empty object on full acceptance, may carry rejection counters per the OTLP spec. |