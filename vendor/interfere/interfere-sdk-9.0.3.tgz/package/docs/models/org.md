# Org

## Example Usage

```typescript
import { Org } from "@interfere/sdk/models";

let value: Org = {
  id: "f6333943-ed63-4a55-95a5-54c3b7027801",
  slug: "<value>",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `id`               | *string*           | :heavy_check_mark: | N/A                |
| `slug`             | *string*           | :heavy_check_mark: | N/A                |