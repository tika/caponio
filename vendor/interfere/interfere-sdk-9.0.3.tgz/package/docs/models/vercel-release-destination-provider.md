# VercelReleaseDestinationProvider

## Example Usage

```typescript
import { VercelReleaseDestinationProvider } from "@interfere/sdk/models";

let value: VercelReleaseDestinationProvider = "vercel";
```

## Values

```typescript
"vercel"
```