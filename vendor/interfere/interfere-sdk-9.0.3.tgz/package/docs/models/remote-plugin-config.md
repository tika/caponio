# RemotePluginConfig

## Example Usage

```typescript
import { RemotePluginConfig } from "@interfere/sdk/models";

let value: RemotePluginConfig = {
  errors: true,
  device: true,
  pageEvents: true,
  rageClick: false,
  replay: true,
  logs: true,
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `errors`           | *boolean*          | :heavy_check_mark: | N/A                |
| `device`           | *boolean*          | :heavy_check_mark: | N/A                |
| `pageEvents`       | *boolean*          | :heavy_check_mark: | N/A                |
| `rageClick`        | *boolean*          | :heavy_check_mark: | N/A                |
| `replay`           | *boolean*          | :heavy_check_mark: | N/A                |
| `logs`             | *boolean*          | :heavy_check_mark: | N/A                |