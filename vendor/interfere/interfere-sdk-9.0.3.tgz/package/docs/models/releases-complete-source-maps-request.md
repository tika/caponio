# ReleasesCompleteSourceMapsRequest

Finalizes a presigned-URL upload batch. Writes the source-map manifest and updates the release's `sourceMapCount` / `sourceFileCount`. Idempotent — safe to retry.

## Example Usage

```typescript
import { ReleasesCompleteSourceMapsRequest } from "@interfere/sdk/models";

let value: ReleasesCompleteSourceMapsRequest = {
  files: [],
  bundler: "webpack",
};
```

## Fields

| Field                                                                   | Type                                                                    | Required                                                                | Description                                                             |
| ----------------------------------------------------------------------- | ----------------------------------------------------------------------- | ----------------------------------------------------------------------- | ----------------------------------------------------------------------- |
| `files`                                                                 | [models.CompleteSourceMapFile](../models/complete-source-map-file.md)[] | :heavy_check_mark:                                                      | N/A                                                                     |
| `sourceFileCount`                                                       | *number*                                                                | :heavy_minus_sign:                                                      | N/A                                                                     |
| `bundler`                                                               | [models.ManifestBundler](../models/manifest-bundler.md)                 | :heavy_check_mark:                                                      | N/A                                                                     |