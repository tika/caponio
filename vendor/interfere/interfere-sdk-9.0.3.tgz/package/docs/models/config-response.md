# ConfigResponse

## Example Usage

```typescript
import { ConfigResponse } from "@interfere/sdk/models";

let value: ConfigResponse = {
  plugins: {
    errors: false,
    device: true,
    pageEvents: true,
    rageClick: true,
    replay: true,
    logs: false,
  },
};
```

## Fields

| Field                                                          | Type                                                           | Required                                                       | Description                                                    |
| -------------------------------------------------------------- | -------------------------------------------------------------- | -------------------------------------------------------------- | -------------------------------------------------------------- |
| `plugins`                                                      | [models.RemotePluginConfig](../models/remote-plugin-config.md) | :heavy_check_mark:                                             | N/A                                                            |