# GithubReleaseSourceProvider

## Example Usage

```typescript
import { GithubReleaseSourceProvider } from "@interfere/sdk/models";

let value: GithubReleaseSourceProvider = "github";
```

## Values

```typescript
"github"
```