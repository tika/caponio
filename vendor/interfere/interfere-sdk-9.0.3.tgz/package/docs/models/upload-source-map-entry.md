# UploadSourceMapEntry

## Example Usage

```typescript
import { UploadSourceMapEntry } from "@interfere/sdk/models";

let value: UploadSourceMapEntry = {
  path: "/root",
  hash: "<value>",
  debugId: "<id>",
  chunkUrl: "https://adolescent-forgery.net",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `path`             | *string*           | :heavy_check_mark: | N/A                |
| `hash`             | *string*           | :heavy_check_mark: | N/A                |
| `debugId`          | *string*           | :heavy_check_mark: | N/A                |
| `chunkUrl`         | *string*           | :heavy_check_mark: | N/A                |