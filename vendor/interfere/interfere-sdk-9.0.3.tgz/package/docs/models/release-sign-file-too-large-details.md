# ReleaseSignFileTooLargeDetails

## Example Usage

```typescript
import { ReleaseSignFileTooLargeDetails } from "@interfere/sdk/models";

let value: ReleaseSignFileTooLargeDetails = {
  path: "/Library",
  sizeBytes: 899141,
  limit: 53732,
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `path`             | *string*           | :heavy_check_mark: | N/A                |
| `sizeBytes`        | *number*           | :heavy_check_mark: | N/A                |
| `limit`            | *number*           | :heavy_check_mark: | N/A                |