# IdentifySource

Auth provider that surfaced this identification.


## Supported Types

### `models.ClerkIdentifySource`

```typescript
const value: models.ClerkIdentifySource = {
  name: "Clerk",
  type: "clerk",
};
```

### `models.Auth0IdentifySource`

```typescript
const value: models.Auth0IdentifySource = {
  name: "Auth0",
  type: "auth0",
};
```

### `models.CustomIdentifySource`

```typescript
const value: models.CustomIdentifySource = {
  name: "<value>",
  type: "custom",
};
```

