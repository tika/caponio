# SignSourceMapFile

## Example Usage

```typescript
import { SignSourceMapFile } from "@interfere/sdk/models";

let value: SignSourceMapFile = {
  path: "/Network",
  sizeBytes: 927111,
  hasSourcesContent: false,
  hasNames: false,
  hasFile: true,
  mappingsPresent: true,
};
```

## Fields

| Field               | Type                | Required            | Description         |
| ------------------- | ------------------- | ------------------- | ------------------- |
| `path`              | *string*            | :heavy_check_mark:  | N/A                 |
| `sizeBytes`         | *number*            | :heavy_check_mark:  | N/A                 |
| `hasSourcesContent` | *boolean*           | :heavy_check_mark:  | N/A                 |
| `hasNames`          | *boolean*           | :heavy_check_mark:  | N/A                 |
| `hasFile`           | *boolean*           | :heavy_check_mark:  | N/A                 |
| `mappingsPresent`   | *boolean*           | :heavy_check_mark:  | N/A                 |