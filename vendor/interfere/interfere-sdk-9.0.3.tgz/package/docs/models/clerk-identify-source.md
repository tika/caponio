# ClerkIdentifySource

## Example Usage

```typescript
import { ClerkIdentifySource } from "@interfere/sdk/models";

let value: ClerkIdentifySource = {
  name: "Clerk",
  type: "clerk",
};
```

## Fields

| Field                                                                     | Type                                                                      | Required                                                                  | Description                                                               |
| ------------------------------------------------------------------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------- |
| `name`                                                                    | [models.ClerkIdentifySourceName](../models/clerk-identify-source-name.md) | :heavy_check_mark:                                                        | N/A                                                                       |
| `type`                                                                    | *"clerk"*                                                                 | :heavy_check_mark:                                                        | N/A                                                                       |