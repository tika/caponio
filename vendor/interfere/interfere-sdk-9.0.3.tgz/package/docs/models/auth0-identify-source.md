# Auth0IdentifySource

## Example Usage

```typescript
import { Auth0IdentifySource } from "@interfere/sdk/models";

let value: Auth0IdentifySource = {
  name: "Auth0",
  type: "auth0",
};
```

## Fields

| Field                                                                     | Type                                                                      | Required                                                                  | Description                                                               |
| ------------------------------------------------------------------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------- |
| `name`                                                                    | [models.Auth0IdentifySourceName](../models/auth0-identify-source-name.md) | :heavy_check_mark:                                                        | N/A                                                                       |
| `type`                                                                    | *"auth0"*                                                                 | :heavy_check_mark:                                                        | N/A                                                                       |