# OrgRef

## Example Usage

```typescript
import { OrgRef } from "@interfere/sdk/models";

let value: OrgRef = {
  id: "<id>",
  slug: "<value>",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `id`               | *string*           | :heavy_check_mark: | N/A                |
| `slug`             | *string*           | :heavy_check_mark: | N/A                |