# ReleasesCreateRequest

Request body for creating a release.

## Example Usage

```typescript
import { ReleasesCreateRequest } from "@interfere/sdk/models";

let value: ReleasesCreateRequest = {
  source: {
    provider: "github",
    commitMessage: "<value>",
    branch: "<value>",
    commitSha: "<value>",
  },
  destination: {
    provider: "vercel",
    destinationReleaseId: "<id>",
    environment: "<value>",
    deploymentId: null,
    deploymentUrl: "https://authorized-gown.name/",
    environmentName: "<value>",
    environmentTarget: "<value>",
  },
  buildId: "<id>",
};
```

## Fields

| Field                       | Type                        | Required                    | Description                 |
| --------------------------- | --------------------------- | --------------------------- | --------------------------- |
| `source`                    | *models.ReleaseSource*      | :heavy_check_mark:          | N/A                         |
| `destination`               | *models.ReleaseDestination* | :heavy_check_mark:          | N/A                         |
| `buildId`                   | *string*                    | :heavy_check_mark:          | N/A                         |
| `slug`                      | *string*                    | :heavy_minus_sign:          | N/A                         |
| `producerVersion`           | *string*                    | :heavy_minus_sign:          | N/A                         |