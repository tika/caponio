# ReleasesCompleteSourceMapsResponse

## Example Usage

```typescript
import { ReleasesCompleteSourceMapsResponse } from "@interfere/sdk/models";

let value: ReleasesCompleteSourceMapsResponse = {
  ok: false,
  fileCount: 521432,
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `ok`               | *boolean*          | :heavy_check_mark: | N/A                |
| `fileCount`        | *number*           | :heavy_check_mark: | N/A                |