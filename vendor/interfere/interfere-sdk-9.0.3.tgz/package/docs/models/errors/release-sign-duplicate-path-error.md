# ReleaseSignDuplicatePathError

## Example Usage

```typescript
import { ReleaseSignDuplicatePathError } from "@interfere/sdk/models/errors";

// No examples available for this model
```

## Fields

| Field                                                                                         | Type                                                                                          | Required                                                                                      | Description                                                                                   |
| --------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- |
| `code`                                                                                        | *"COLLECTOR_RELEASE_SIGN_DUPLICATE_PATH"*                                                     | :heavy_check_mark:                                                                            | N/A                                                                                           |
| `details`                                                                                     | [models.ReleaseSignDuplicatePathDetails](../../models/release-sign-duplicate-path-details.md) | :heavy_check_mark:                                                                            | N/A                                                                                           |
| `ok`                                                                                          | *false*                                                                                       | :heavy_minus_sign:                                                                            | N/A                                                                                           |
| `message`                                                                                     | *string*                                                                                      | :heavy_minus_sign:                                                                            | N/A                                                                                           |