# HealthError

## Example Usage

```typescript
import { HealthError } from "@interfere/sdk/models/errors";

// No examples available for this model
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `ok`               | *false*            | :heavy_minus_sign: | N/A                |
| `message`          | *string*           | :heavy_minus_sign: | N/A                |