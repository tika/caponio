# ValidationError

## Example Usage

```typescript
import { ValidationError } from "@interfere/sdk/models/errors";

// No examples available for this model
```

## Fields

| Field                                                                     | Type                                                                      | Required                                                                  | Description                                                               |
| ------------------------------------------------------------------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------- |
| `code`                                                                    | *"VALIDATION"*                                                            | :heavy_check_mark:                                                        | N/A                                                                       |
| `details`                                                                 | [models.ValidationErrorDetails](../../models/validation-error-details.md) | :heavy_minus_sign:                                                        | N/A                                                                       |
| `ok`                                                                      | *false*                                                                   | :heavy_minus_sign:                                                        | N/A                                                                       |
| `message`                                                                 | *string*                                                                  | :heavy_minus_sign:                                                        | N/A                                                                       |