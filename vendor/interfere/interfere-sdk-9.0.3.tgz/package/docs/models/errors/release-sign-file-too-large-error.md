# ReleaseSignFileTooLargeError

## Example Usage

```typescript
import { ReleaseSignFileTooLargeError } from "@interfere/sdk/models/errors";

// No examples available for this model
```

## Fields

| Field                                                                                        | Type                                                                                         | Required                                                                                     | Description                                                                                  |
| -------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| `code`                                                                                       | *"COLLECTOR_RELEASE_SIGN_FILE_TOO_LARGE"*                                                    | :heavy_check_mark:                                                                           | N/A                                                                                          |
| `details`                                                                                    | [models.ReleaseSignFileTooLargeDetails](../../models/release-sign-file-too-large-details.md) | :heavy_check_mark:                                                                           | N/A                                                                                          |
| `ok`                                                                                         | *false*                                                                                      | :heavy_minus_sign:                                                                           | N/A                                                                                          |
| `message`                                                                                    | *string*                                                                                     | :heavy_minus_sign:                                                                           | N/A                                                                                          |