# ErrorsProblem


## Supported Types

### `errors.LibraryBareError`

```typescript
const value: errors.LibraryBareError = {
  code: "UNKNOWN",
};
```

### `errors.LibraryBareError`

```typescript
const value: errors.LibraryBareError = {
  code: "UNKNOWN",
};
```

### `errors.LibraryBareError`

```typescript
const value: errors.LibraryBareError = {
  code: "UNKNOWN",
};
```

### `errors.LibraryBareError`

```typescript
const value: errors.LibraryBareError = {
  code: "UNKNOWN",
};
```

### `errors.LibraryBareError`

```typescript
const value: errors.LibraryBareError = {
  code: "UNKNOWN",
};
```

### `errors.LibraryBareError`

```typescript
const value: errors.LibraryBareError = {
  code: "UNKNOWN",
};
```

### `errors.ValidationError`

```typescript
const value: errors.ValidationError = {
  code: "VALIDATION",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.CollectorBareError`

```typescript
const value: errors.CollectorBareError = {
  code: "COLLECTOR_INGEST_INFRA_UNAVAILABLE",
};
```

### `errors.ReleaseSignTooManyFilesError`

```typescript
const value: errors.ReleaseSignTooManyFilesError = {
  code: "COLLECTOR_RELEASE_SIGN_TOO_MANY_FILES",
  details: {
    fileCount: 496787,
    limit: 414748,
  },
};
```

### `errors.ReleaseSignFileTooLargeError`

```typescript
const value: errors.ReleaseSignFileTooLargeError = {
  code: "COLLECTOR_RELEASE_SIGN_FILE_TOO_LARGE",
  details: {
    path: "/home/user",
    sizeBytes: 682648,
    limit: 527979,
  },
};
```

### `errors.ReleaseSignDuplicatePathError`

```typescript
const value: errors.ReleaseSignDuplicatePathError = {
  code: "COLLECTOR_RELEASE_SIGN_DUPLICATE_PATH",
  details: {
    path: "/etc",
  },
};
```

