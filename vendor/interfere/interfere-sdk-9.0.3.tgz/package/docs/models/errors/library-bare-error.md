# LibraryBareError

## Example Usage

```typescript
import { LibraryBareError } from "@interfere/sdk/models/errors";

// No examples available for this model
```

## Fields

| Field                                                                  | Type                                                                   | Required                                                               | Description                                                            |
| ---------------------------------------------------------------------- | ---------------------------------------------------------------------- | ---------------------------------------------------------------------- | ---------------------------------------------------------------------- |
| `code`                                                                 | [models.LibraryBareErrorCode](../../models/library-bare-error-code.md) | :heavy_check_mark:                                                     | N/A                                                                    |
| `ok`                                                                   | *false*                                                                | :heavy_minus_sign:                                                     | N/A                                                                    |
| `message`                                                              | *string*                                                               | :heavy_minus_sign:                                                     | N/A                                                                    |