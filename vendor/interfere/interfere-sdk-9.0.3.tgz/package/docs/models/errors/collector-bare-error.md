# CollectorBareError

## Example Usage

```typescript
import { CollectorBareError } from "@interfere/sdk/models/errors";

// No examples available for this model
```

## Fields

| Field                                                                      | Type                                                                       | Required                                                                   | Description                                                                |
| -------------------------------------------------------------------------- | -------------------------------------------------------------------------- | -------------------------------------------------------------------------- | -------------------------------------------------------------------------- |
| `code`                                                                     | [models.CollectorBareErrorCode](../../models/collector-bare-error-code.md) | :heavy_check_mark:                                                         | N/A                                                                        |
| `ok`                                                                       | *false*                                                                    | :heavy_minus_sign:                                                         | N/A                                                                        |
| `message`                                                                  | *string*                                                                   | :heavy_minus_sign:                                                         | N/A                                                                        |