# ReleaseSignTooManyFilesError

## Example Usage

```typescript
import { ReleaseSignTooManyFilesError } from "@interfere/sdk/models/errors";

// No examples available for this model
```

## Fields

| Field                                                                                        | Type                                                                                         | Required                                                                                     | Description                                                                                  |
| -------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| `code`                                                                                       | *"COLLECTOR_RELEASE_SIGN_TOO_MANY_FILES"*                                                    | :heavy_check_mark:                                                                           | N/A                                                                                          |
| `details`                                                                                    | [models.ReleaseSignTooManyFilesDetails](../../models/release-sign-too-many-files-details.md) | :heavy_check_mark:                                                                           | N/A                                                                                          |
| `ok`                                                                                         | *false*                                                                                      | :heavy_minus_sign:                                                                           | N/A                                                                                          |
| `message`                                                                                    | *string*                                                                                     | :heavy_minus_sign:                                                                           | N/A                                                                                          |