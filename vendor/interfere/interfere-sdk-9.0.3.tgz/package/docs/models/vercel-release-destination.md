# VercelReleaseDestination

Release destination metadata for a Vercel deployment.

## Example Usage

```typescript
import { VercelReleaseDestination } from "@interfere/sdk/models";

let value: VercelReleaseDestination = {
  provider: "vercel",
  destinationReleaseId: "<id>",
  environment: "<value>",
  deploymentId: "<id>",
  deploymentUrl: "https://front-kinase.biz",
  environmentName: null,
  environmentTarget: "<value>",
};
```

## Fields

| Field                                                                                       | Type                                                                                        | Required                                                                                    | Description                                                                                 |
| ------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------- |
| `provider`                                                                                  | [models.VercelReleaseDestinationProvider](../models/vercel-release-destination-provider.md) | :heavy_check_mark:                                                                          | N/A                                                                                         |
| `destinationReleaseId`                                                                      | *string*                                                                                    | :heavy_check_mark:                                                                          | N/A                                                                                         |
| `environment`                                                                               | *string*                                                                                    | :heavy_check_mark:                                                                          | N/A                                                                                         |
| `deploymentId`                                                                              | *string*                                                                                    | :heavy_check_mark:                                                                          | N/A                                                                                         |
| `deploymentUrl`                                                                             | *string*                                                                                    | :heavy_check_mark:                                                                          | N/A                                                                                         |
| `environmentName`                                                                           | *string*                                                                                    | :heavy_check_mark:                                                                          | N/A                                                                                         |
| `environmentTarget`                                                                         | *string*                                                                                    | :heavy_check_mark:                                                                          | N/A                                                                                         |