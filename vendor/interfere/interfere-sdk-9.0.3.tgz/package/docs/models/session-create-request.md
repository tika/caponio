# SessionCreateRequest

Request body for creating a session.

## Example Usage

```typescript
import { SessionCreateRequest } from "@interfere/sdk/models";

let value: SessionCreateRequest = {
  sessionId: "<id>",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `sessionId`        | *string*           | :heavy_check_mark: | N/A                |
| `deviceId`         | *string*           | :heavy_minus_sign: | N/A                |
| `fpHash`           | *string*           | :heavy_minus_sign: | N/A                |
| `visitorId`        | *string*           | :heavy_minus_sign: | N/A                |