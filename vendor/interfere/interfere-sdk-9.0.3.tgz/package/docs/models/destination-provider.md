# DestinationProvider

## Example Usage

```typescript
import { DestinationProvider } from "@interfere/sdk/models";

let value: DestinationProvider = "vercel";
```

## Values

```typescript
"vercel"
```