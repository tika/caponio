# ReleaseSignDuplicatePathDetails

## Example Usage

```typescript
import { ReleaseSignDuplicatePathDetails } from "@interfere/sdk/models";

let value: ReleaseSignDuplicatePathDetails = {
  path: "/opt",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `path`             | *string*           | :heavy_check_mark: | N/A                |