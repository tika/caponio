# HealthOk

## Example Usage

```typescript
import { HealthOk } from "@interfere/sdk/models";

let value: HealthOk = {
  status: "ok",
};
```

## Fields

| Field                                | Type                                 | Required                             | Description                          |
| ------------------------------------ | ------------------------------------ | ------------------------------------ | ------------------------------------ |
| `status`                             | [models.Status](../models/status.md) | :heavy_check_mark:                   | N/A                                  |