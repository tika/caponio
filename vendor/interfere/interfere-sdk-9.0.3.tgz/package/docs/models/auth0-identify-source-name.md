# Auth0IdentifySourceName

## Example Usage

```typescript
import { Auth0IdentifySourceName } from "@interfere/sdk/models";

let value: Auth0IdentifySourceName = "Auth0";
```

## Values

```typescript
"Auth0"
```