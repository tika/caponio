# MultipartFile

## Example Usage

```typescript
import { MultipartFile } from "@interfere/sdk/models";

// No examples available for this model
```

## Fields

| Field                        | Type                         | Required                     | Description                  |
| ---------------------------- | ---------------------------- | ---------------------------- | ---------------------------- |
| `fileName`                   | *string*                     | :heavy_check_mark:           | N/A                          |
| `content`                    | *ReadableStream<Uint8Array>* | :heavy_check_mark:           | N/A                          |