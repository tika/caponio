# SessionResponse

## Example Usage

```typescript
import { SessionResponse } from "@interfere/sdk/models";

let value: SessionResponse = {
  ok: true,
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `ok`               | *boolean*          | :heavy_check_mark: | N/A                |