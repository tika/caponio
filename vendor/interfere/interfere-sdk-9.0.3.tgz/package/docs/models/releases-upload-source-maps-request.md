# ReleasesUploadSourceMapsRequest

Multipart body for uploading source maps for a release.

## Example Usage

```typescript
import { ReleasesUploadSourceMapsRequest } from "@interfere/sdk/models";

// No examples available for this model
```

## Fields

| Field                                                                       | Type                                                                        | Required                                                                    | Description                                                                 |
| --------------------------------------------------------------------------- | --------------------------------------------------------------------------- | --------------------------------------------------------------------------- | --------------------------------------------------------------------------- |
| `files`                                                                     | *models.Files*                                                              | :heavy_check_mark:                                                          | N/A                                                                         |
| `metadata`                                                                  | [models.UploadSourceMapsMetadata](../models/upload-source-maps-metadata.md) | :heavy_check_mark:                                                          | Metadata attached alongside uploaded source map files.                      |