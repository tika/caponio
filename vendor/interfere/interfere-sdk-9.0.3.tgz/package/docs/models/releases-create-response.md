# ReleasesCreateResponse

Response body returned after creating a release.

## Example Usage

```typescript
import { ReleasesCreateResponse } from "@interfere/sdk/models";

let value: ReleasesCreateResponse = {
  org: {
    id: "<id>",
    slug: "<value>",
  },
  surface: {
    id: "<id>",
    slug: "<value>",
  },
  source: {
    id: "<id>",
  },
  destination: {
    id: "<id>",
    slug: "<value>",
    environment: "<value>",
  },
  build: {
    hash: "<value>",
  },
};
```

## Fields

| Field                                                                | Type                                                                 | Required                                                             | Description                                                          |
| -------------------------------------------------------------------- | -------------------------------------------------------------------- | -------------------------------------------------------------------- | -------------------------------------------------------------------- |
| `org`                                                                | [models.OrgRef](../models/org-ref.md)                                | :heavy_check_mark:                                                   | N/A                                                                  |
| `surface`                                                            | [models.SurfaceRef](../models/surface-ref.md)                        | :heavy_check_mark:                                                   | N/A                                                                  |
| `source`                                                             | [models.ReleaseSourceRef](../models/release-source-ref.md)           | :heavy_check_mark:                                                   | N/A                                                                  |
| `destination`                                                        | [models.ReleaseDestinationRef](../models/release-destination-ref.md) | :heavy_check_mark:                                                   | N/A                                                                  |
| `build`                                                              | [models.ReleaseBuildRef](../models/release-build-ref.md)             | :heavy_check_mark:                                                   | N/A                                                                  |