# Files


## Supported Types

### `models.MultipartFile[]`

```typescript
const value: models.MultipartFile[] = [];
```

### `models.MultipartFile`

```typescript
const value: models.MultipartFile = await openAsBlob("example.file");
```

