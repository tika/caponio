# ReleaseSource


## Supported Types

### `models.GithubReleaseSource`

```typescript
const value: models.GithubReleaseSource = {
  provider: "github",
  commitMessage: "<value>",
  branch: "<value>",
  commitSha: "<value>",
};
```

