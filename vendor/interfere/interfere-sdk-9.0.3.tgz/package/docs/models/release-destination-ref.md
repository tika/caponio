# ReleaseDestinationRef

## Example Usage

```typescript
import { ReleaseDestinationRef } from "@interfere/sdk/models";

let value: ReleaseDestinationRef = {
  id: "<id>",
  slug: "<value>",
  environment: "<value>",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `id`               | *string*           | :heavy_check_mark: | N/A                |
| `slug`             | *string*           | :heavy_check_mark: | N/A                |
| `environment`      | *string*           | :heavy_check_mark: | N/A                |