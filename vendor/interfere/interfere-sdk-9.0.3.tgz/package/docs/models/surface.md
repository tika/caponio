# Surface

## Example Usage

```typescript
import { Surface } from "@interfere/sdk/models";

let value: Surface = {
  id: "9a9f40a7-463e-4b04-aff7-a3fc62612403",
  slug: "<value>",
  allowDirectIngestion: true,
  environmentFiltering: true,
  sourceProvider: "github",
  destinationProvider: "vercel",
  sdkConfig: {},
};
```

## Fields

| Field                                                           | Type                                                            | Required                                                        | Description                                                     |
| --------------------------------------------------------------- | --------------------------------------------------------------- | --------------------------------------------------------------- | --------------------------------------------------------------- |
| `id`                                                            | *string*                                                        | :heavy_check_mark:                                              | N/A                                                             |
| `slug`                                                          | *string*                                                        | :heavy_check_mark:                                              | N/A                                                             |
| `allowDirectIngestion`                                          | *boolean*                                                       | :heavy_check_mark:                                              | N/A                                                             |
| `environmentFiltering`                                          | *boolean*                                                       | :heavy_check_mark:                                              | N/A                                                             |
| `sourceProvider`                                                | [models.SourceProvider](../models/source-provider.md)           | :heavy_check_mark:                                              | N/A                                                             |
| `destinationProvider`                                           | [models.DestinationProvider](../models/destination-provider.md) | :heavy_check_mark:                                              | N/A                                                             |
| `sdkConfig`                                                     | [models.SDKConfig](../models/sdk-config.md)                     | :heavy_check_mark:                                              | N/A                                                             |