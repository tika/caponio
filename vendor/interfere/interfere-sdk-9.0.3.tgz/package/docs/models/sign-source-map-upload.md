# SignSourceMapUpload

## Example Usage

```typescript
import { SignSourceMapUpload } from "@interfere/sdk/models";

let value: SignSourceMapUpload = {
  path: "/boot/defaults",
  objectKey: "<value>",
  presignedUrl: "https://ironclad-term.com/",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `path`             | *string*           | :heavy_check_mark: | N/A                |
| `objectKey`        | *string*           | :heavy_check_mark: | N/A                |
| `presignedUrl`     | *string*           | :heavy_check_mark: | N/A                |