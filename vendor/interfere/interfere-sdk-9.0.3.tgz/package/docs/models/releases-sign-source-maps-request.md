# ReleasesSignSourceMapsRequest

Per-file metadata the SDK uses to obtain presigned PUT URLs. The server validates per-file size and total file count, then issues short-lived URLs scoped to the release's R2 prefix. The SDK uploads to R2 directly and follows up with a `complete` call to materialize the manifest.

## Example Usage

```typescript
import { ReleasesSignSourceMapsRequest } from "@interfere/sdk/models";

let value: ReleasesSignSourceMapsRequest = {
  files: [],
};
```

## Fields

| Field                                                           | Type                                                            | Required                                                        | Description                                                     |
| --------------------------------------------------------------- | --------------------------------------------------------------- | --------------------------------------------------------------- | --------------------------------------------------------------- |
| `files`                                                         | [models.SignSourceMapFile](../models/sign-source-map-file.md)[] | :heavy_check_mark:                                              | N/A                                                             |