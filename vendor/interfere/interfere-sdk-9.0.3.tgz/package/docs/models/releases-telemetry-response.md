# ReleasesTelemetryResponse

## Example Usage

```typescript
import { ReleasesTelemetryResponse } from "@interfere/sdk/models";

let value: ReleasesTelemetryResponse = {
  ok: true,
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `ok`               | *boolean*          | :heavy_check_mark: | N/A                |