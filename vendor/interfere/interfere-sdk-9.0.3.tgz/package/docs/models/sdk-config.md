# SDKConfig

## Example Usage

```typescript
import { SDKConfig } from "@interfere/sdk/models";

let value: SDKConfig = {};
```

## Fields

| Field                                  | Type                                   | Required                               | Description                            |
| -------------------------------------- | -------------------------------------- | -------------------------------------- | -------------------------------------- |
| `plugins`                              | [models.Plugins](../models/plugins.md) | :heavy_minus_sign:                     | N/A                                    |