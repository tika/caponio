# SourceProvider

## Example Usage

```typescript
import { SourceProvider } from "@interfere/sdk/models";

let value: SourceProvider = "github";
```

## Values

```typescript
"github"
```