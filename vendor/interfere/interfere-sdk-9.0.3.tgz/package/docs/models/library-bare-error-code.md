# LibraryBareErrorCode

## Example Usage

```typescript
import { LibraryBareErrorCode } from "@interfere/sdk/models";

let value: LibraryBareErrorCode = "INVALID_FILE_TYPE";

// Open enum: unrecognized values are captured as Unrecognized<string>
```

## Values

```typescript
"PARSE" | "NOT_FOUND" | "INTERNAL_SERVER_ERROR" | "INVALID_FILE_TYPE" | "INVALID_COOKIE_SIGNATURE" | "UNKNOWN" | Unrecognized<string>
```