# ReleasesTelemetryRequest

Timings and counters reported after a source-map upload.

## Example Usage

```typescript
import { ReleasesTelemetryRequest } from "@interfere/sdk/models";

let value: ReleasesTelemetryRequest = {
  discover: 43.96,
  createRelease: 6949.89,
  upload: 4437.46,
  cleanup: 418.22,
  total: 330.35,
  fileCount: 7768.78,
  totalBytes: 6510.58,
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `discover`         | *number*           | :heavy_check_mark: | N/A                |
| `createRelease`    | *number*           | :heavy_check_mark: | N/A                |
| `upload`           | *number*           | :heavy_check_mark: | N/A                |
| `cleanup`          | *number*           | :heavy_check_mark: | N/A                |
| `total`            | *number*           | :heavy_check_mark: | N/A                |
| `fileCount`        | *number*           | :heavy_check_mark: | N/A                |
| `totalBytes`       | *number*           | :heavy_check_mark: | N/A                |