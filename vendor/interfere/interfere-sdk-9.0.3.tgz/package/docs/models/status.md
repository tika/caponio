# Status

## Example Usage

```typescript
import { Status } from "@interfere/sdk/models";

let value: Status = "ok";
```

## Values

```typescript
"ok"
```