# Plugins

## Example Usage

```typescript
import { Plugins } from "@interfere/sdk/models";

let value: Plugins = {};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `errors`           | *boolean*          | :heavy_minus_sign: | N/A                |
| `device`           | *boolean*          | :heavy_minus_sign: | N/A                |
| `pageEvents`       | *boolean*          | :heavy_minus_sign: | N/A                |
| `rageClick`        | *boolean*          | :heavy_minus_sign: | N/A                |
| `replay`           | *boolean*          | :heavy_minus_sign: | N/A                |
| `logs`             | *boolean*          | :heavy_minus_sign: | N/A                |