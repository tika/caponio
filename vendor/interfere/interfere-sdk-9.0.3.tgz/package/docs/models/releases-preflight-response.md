# ReleasesPreflightResponse

Acknowledgement that this release is cleared for ingest. Body is empty because the call itself is the signal.

## Example Usage

```typescript
import { ReleasesPreflightResponse } from "@interfere/sdk/models";

let value: ReleasesPreflightResponse = {
  ok: true,
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `ok`               | *boolean*          | :heavy_check_mark: | N/A                |