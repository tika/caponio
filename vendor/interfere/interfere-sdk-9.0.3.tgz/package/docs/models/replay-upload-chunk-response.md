# ReplayUploadChunkResponse

## Example Usage

```typescript
import { ReplayUploadChunkResponse } from "@interfere/sdk/models";

let value: ReplayUploadChunkResponse = {
  objectKey: "<value>",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `objectKey`        | *string*           | :heavy_check_mark: | N/A                |