# UploadReplayChunkRequest

## Example Usage

```typescript
import { UploadReplayChunkRequest } from "@interfere/sdk/models/operations";

let value: UploadReplayChunkRequest = {
  sessionId: "<id>",
  body: [
    "<value 1>",
    "<value 2>",
    "<value 3>",
  ],
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `sessionId`        | *string*           | :heavy_check_mark: | N/A                |
| `body`             | *string*[]         | :heavy_check_mark: | N/A                |