# ReportTelemetryRequest

## Example Usage

```typescript
import { ReportTelemetryRequest } from "@interfere/sdk/models/operations";

let value: ReportTelemetryRequest = {
  releaseSlug: "<value>",
  body: {
    discover: 6639.05,
    createRelease: 4343.39,
    upload: 1245.32,
    cleanup: 5139.13,
    total: 241.62,
    fileCount: 6194.53,
    totalBytes: 1711.4,
  },
};
```

## Fields

| Field                                                                         | Type                                                                          | Required                                                                      | Description                                                                   |
| ----------------------------------------------------------------------------- | ----------------------------------------------------------------------------- | ----------------------------------------------------------------------------- | ----------------------------------------------------------------------------- |
| `releaseSlug`                                                                 | *string*                                                                      | :heavy_check_mark:                                                            | N/A                                                                           |
| `body`                                                                        | [models.ReleasesTelemetryRequest](../../models/releases-telemetry-request.md) | :heavy_check_mark:                                                            | Timings and counters reported after a source-map upload.                      |