# UploadSourceMapsRequest

## Example Usage

```typescript
import { UploadSourceMapsRequest } from "@interfere/sdk/models/operations";

// No examples available for this model
```

## Fields

| Field                                                                                         | Type                                                                                          | Required                                                                                      | Description                                                                                   |
| --------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- |
| `releaseSlug`                                                                                 | *string*                                                                                      | :heavy_check_mark:                                                                            | N/A                                                                                           |
| `body`                                                                                        | [models.ReleasesUploadSourceMapsRequest](../../models/releases-upload-source-maps-request.md) | :heavy_check_mark:                                                                            | Multipart body for uploading source maps for a release.                                       |