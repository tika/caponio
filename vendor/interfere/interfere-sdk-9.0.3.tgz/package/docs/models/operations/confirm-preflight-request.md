# ConfirmPreflightRequest

## Example Usage

```typescript
import { ConfirmPreflightRequest } from "@interfere/sdk/models/operations";

let value: ConfirmPreflightRequest = {
  releaseSlug: "<value>",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `releaseSlug`      | *string*           | :heavy_check_mark: | N/A                |