# CompleteSourceMapUploadsRequest

## Example Usage

```typescript
import { CompleteSourceMapUploadsRequest } from "@interfere/sdk/models/operations";

let value: CompleteSourceMapUploadsRequest = {
  releaseSlug: "<value>",
  body: {
    files: [
      {
        path: "/root",
        hash: "<value>",
        debugId: "<id>",
        chunkUrl: "https://dismal-ferret.biz",
      },
    ],
    bundler: "turbopack",
  },
};
```

## Fields

| Field                                                                                                                                                              | Type                                                                                                                                                               | Required                                                                                                                                                           | Description                                                                                                                                                        |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `releaseSlug`                                                                                                                                                      | *string*                                                                                                                                                           | :heavy_check_mark:                                                                                                                                                 | N/A                                                                                                                                                                |
| `body`                                                                                                                                                             | [models.ReleasesCompleteSourceMapsRequest](../../models/releases-complete-source-maps-request.md)                                                                  | :heavy_check_mark:                                                                                                                                                 | Finalizes a presigned-URL upload batch. Writes the source-map manifest and updates the release's `sourceMapCount` / `sourceFileCount`. Idempotent — safe to retry. |