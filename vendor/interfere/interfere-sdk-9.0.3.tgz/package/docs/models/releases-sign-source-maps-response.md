# ReleasesSignSourceMapsResponse

## Example Usage

```typescript
import { ReleasesSignSourceMapsResponse } from "@interfere/sdk/models";

let value: ReleasesSignSourceMapsResponse = {
  uploads: [],
  expiresAt: 565902,
};
```

## Fields

| Field                                                               | Type                                                                | Required                                                            | Description                                                         |
| ------------------------------------------------------------------- | ------------------------------------------------------------------- | ------------------------------------------------------------------- | ------------------------------------------------------------------- |
| `uploads`                                                           | [models.SignSourceMapUpload](../models/sign-source-map-upload.md)[] | :heavy_check_mark:                                                  | N/A                                                                 |
| `expiresAt`                                                         | *number*                                                            | :heavy_check_mark:                                                  | N/A                                                                 |