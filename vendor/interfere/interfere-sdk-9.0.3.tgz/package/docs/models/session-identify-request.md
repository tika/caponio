# SessionIdentifyRequest

Request body for identifying the end user associated with a session.

## Example Usage

```typescript
import { SessionIdentifyRequest } from "@interfere/sdk/models";

let value: SessionIdentifyRequest = {
  sessionId: "<id>",
  identifier: "<value>",
  source: {
    name: "Clerk",
    type: "clerk",
  },
};
```

## Fields

| Field                                            | Type                                             | Required                                         | Description                                      |
| ------------------------------------------------ | ------------------------------------------------ | ------------------------------------------------ | ------------------------------------------------ |
| `name`                                           | *string*                                         | :heavy_minus_sign:                               | N/A                                              |
| `sessionId`                                      | *string*                                         | :heavy_check_mark:                               | N/A                                              |
| `deviceId`                                       | *string*                                         | :heavy_minus_sign:                               | N/A                                              |
| `fpHash`                                         | *string*                                         | :heavy_minus_sign:                               | N/A                                              |
| `visitorId`                                      | *string*                                         | :heavy_minus_sign:                               | N/A                                              |
| `avatar`                                         | *string*                                         | :heavy_minus_sign:                               | N/A                                              |
| `email`                                          | *string*                                         | :heavy_minus_sign:                               | N/A                                              |
| `identifier`                                     | *string*                                         | :heavy_check_mark:                               | N/A                                              |
| `source`                                         | *models.IdentifySource*                          | :heavy_check_mark:                               | Auth provider that surfaced this identification. |
| `traits`                                         | Record<string, *any*>                            | :heavy_minus_sign:                               | N/A                                              |
| `country`                                        | *string*                                         | :heavy_minus_sign:                               | N/A                                              |