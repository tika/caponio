# SurfaceRef

## Example Usage

```typescript
import { SurfaceRef } from "@interfere/sdk/models";

let value: SurfaceRef = {
  id: "<id>",
  slug: "<value>",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `id`               | *string*           | :heavy_check_mark: | N/A                |
| `slug`             | *string*           | :heavy_check_mark: | N/A                |