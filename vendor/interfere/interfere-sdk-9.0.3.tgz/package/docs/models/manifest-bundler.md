# ManifestBundler

## Example Usage

```typescript
import { ManifestBundler } from "@interfere/sdk/models";

let value: ManifestBundler = "webpack";
```

## Values

```typescript
"webpack" | "turbopack"
```