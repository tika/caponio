# CompleteSourceMapFile

## Example Usage

```typescript
import { CompleteSourceMapFile } from "@interfere/sdk/models";

let value: CompleteSourceMapFile = {
  path: "/usr/ports",
  hash: "<value>",
  debugId: "<id>",
  chunkUrl: "https://right-lava.org/",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `path`             | *string*           | :heavy_check_mark: | N/A                |
| `hash`             | *string*           | :heavy_check_mark: | N/A                |
| `debugId`          | *string*           | :heavy_check_mark: | N/A                |
| `chunkUrl`         | *string*           | :heavy_check_mark: | N/A                |