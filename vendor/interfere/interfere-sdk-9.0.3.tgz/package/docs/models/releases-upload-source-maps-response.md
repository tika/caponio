# ReleasesUploadSourceMapsResponse

## Example Usage

```typescript
import { ReleasesUploadSourceMapsResponse } from "@interfere/sdk/models";

let value: ReleasesUploadSourceMapsResponse = {
  ok: true,
  processed: 674512,
  message: "<value>",
  fileCount: 773990,
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `ok`               | *boolean*          | :heavy_check_mark: | N/A                |
| `processed`        | *number*           | :heavy_check_mark: | N/A                |
| `message`          | *string*           | :heavy_check_mark: | N/A                |
| `fileCount`        | *number*           | :heavy_check_mark: | N/A                |