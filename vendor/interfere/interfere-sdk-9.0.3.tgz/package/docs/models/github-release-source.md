# GithubReleaseSource

Release source metadata coming from GitHub.

## Example Usage

```typescript
import { GithubReleaseSource } from "@interfere/sdk/models";

let value: GithubReleaseSource = {
  provider: "github",
  commitMessage: "<value>",
  branch: "<value>",
  commitSha: "<value>",
};
```

## Fields

| Field                                                                             | Type                                                                              | Required                                                                          | Description                                                                       |
| --------------------------------------------------------------------------------- | --------------------------------------------------------------------------------- | --------------------------------------------------------------------------------- | --------------------------------------------------------------------------------- |
| `provider`                                                                        | [models.GithubReleaseSourceProvider](../models/github-release-source-provider.md) | :heavy_check_mark:                                                                | N/A                                                                               |
| `commitMessage`                                                                   | *string*                                                                          | :heavy_check_mark:                                                                | N/A                                                                               |
| `branch`                                                                          | *string*                                                                          | :heavy_check_mark:                                                                | N/A                                                                               |
| `commitSha`                                                                       | *string*                                                                          | :heavy_check_mark:                                                                | N/A                                                                               |