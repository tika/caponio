# ReleaseBuildRef

## Example Usage

```typescript
import { ReleaseBuildRef } from "@interfere/sdk/models";

let value: ReleaseBuildRef = {
  hash: "<value>",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `hash`             | *string*           | :heavy_check_mark: | N/A                |