# ValidationErrorDetails

## Example Usage

```typescript
import { ValidationErrorDetails } from "@interfere/sdk/models";

let value: ValidationErrorDetails = {
  errors: [
    "<value 1>",
  ],
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `errors`           | *any*[]            | :heavy_check_mark: | N/A                |