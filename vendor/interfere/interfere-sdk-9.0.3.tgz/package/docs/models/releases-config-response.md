# ReleasesConfigResponse

## Example Usage

```typescript
import { ReleasesConfigResponse } from "@interfere/sdk/models";

let value: ReleasesConfigResponse = {
  surface: {
    id: "60dfeaf6-e6ee-4aa3-8885-2485191a75a4",
    slug: "<value>",
    allowDirectIngestion: true,
    environmentFiltering: true,
    sourceProvider: "github",
    destinationProvider: null,
    sdkConfig: {},
  },
  org: {
    id: "f4d45a7b-9c64-4a7b-b706-f8baf72c8533",
    slug: "<value>",
  },
};
```

## Fields

| Field                                  | Type                                   | Required                               | Description                            |
| -------------------------------------- | -------------------------------------- | -------------------------------------- | -------------------------------------- |
| `surface`                              | [models.Surface](../models/surface.md) | :heavy_check_mark:                     | N/A                                    |
| `org`                                  | [models.Org](../models/org.md)         | :heavy_check_mark:                     | N/A                                    |