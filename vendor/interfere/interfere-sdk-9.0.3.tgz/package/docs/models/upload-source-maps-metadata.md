# UploadSourceMapsMetadata

Metadata attached alongside uploaded source map files.

## Example Usage

```typescript
import { UploadSourceMapsMetadata } from "@interfere/sdk/models";

let value: UploadSourceMapsMetadata = {
  entries: [],
  bundler: "webpack",
};
```

## Fields

| Field                                                                 | Type                                                                  | Required                                                              | Description                                                           |
| --------------------------------------------------------------------- | --------------------------------------------------------------------- | --------------------------------------------------------------------- | --------------------------------------------------------------------- |
| `entries`                                                             | [models.UploadSourceMapEntry](../models/upload-source-map-entry.md)[] | :heavy_check_mark:                                                    | N/A                                                                   |
| `sourceFileCount`                                                     | *number*                                                              | :heavy_minus_sign:                                                    | N/A                                                                   |
| `bundler`                                                             | [models.ManifestBundler](../models/manifest-bundler.md)               | :heavy_check_mark:                                                    | N/A                                                                   |