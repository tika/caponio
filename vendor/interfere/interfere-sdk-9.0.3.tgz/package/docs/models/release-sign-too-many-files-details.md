# ReleaseSignTooManyFilesDetails

## Example Usage

```typescript
import { ReleaseSignTooManyFilesDetails } from "@interfere/sdk/models";

let value: ReleaseSignTooManyFilesDetails = {
  fileCount: 889995,
  limit: 805665,
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `fileCount`        | *number*           | :heavy_check_mark: | N/A                |
| `limit`            | *number*           | :heavy_check_mark: | N/A                |