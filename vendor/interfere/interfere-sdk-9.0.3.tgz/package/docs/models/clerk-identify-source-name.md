# ClerkIdentifySourceName

## Example Usage

```typescript
import { ClerkIdentifySourceName } from "@interfere/sdk/models";

let value: ClerkIdentifySourceName = "Clerk";
```

## Values

```typescript
"Clerk"
```