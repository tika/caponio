# ReleaseDestination


## Supported Types

### `models.VercelReleaseDestination`

```typescript
const value: models.VercelReleaseDestination = {
  provider: "vercel",
  destinationReleaseId: "<id>",
  environment: "<value>",
  deploymentId: "<id>",
  deploymentUrl: "https://front-kinase.biz",
  environmentName: null,
  environmentTarget: "<value>",
};
```

