# Replay

## Overview

### Available Operations

* [uploadReplayChunk](#uploadreplaychunk)

## uploadReplayChunk

### Example Usage

<!-- UsageSnippet language="typescript" operationID="uploadReplayChunk" method="post" path="/v2/replay/upload/{sessionId}" -->
```typescript
import { Interfere } from "@interfere/sdk";

const interfere = new Interfere();

async function run() {
  const result = await interfere.replay.uploadReplayChunk({
    sessionId: "<id>",
    body: [
      "<value 1>",
    ],
  });

  console.log(result);
}

run();
```

### Standalone function

The standalone function version of this method:

```typescript
import { InterfereCore } from "@interfere/sdk/core.js";
import { replayUploadReplayChunk } from "@interfere/sdk/funcs/replay-upload-replay-chunk.js";

// Use `InterfereCore` for best tree-shaking performance.
// You can create one instance of it to use across an application.
const interfere = new InterfereCore();

async function run() {
  const res = await replayUploadReplayChunk(interfere, {
    sessionId: "<id>",
    body: [
      "<value 1>",
    ],
  });
  if (res.ok) {
    const { value: result } = res;
    console.log(result);
  } else {
    console.log("replayUploadReplayChunk failed:", res.error);
  }
}

run();
```

### Parameters

| Parameter                                                                                                                                                                      | Type                                                                                                                                                                           | Required                                                                                                                                                                       | Description                                                                                                                                                                    |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `request`                                                                                                                                                                      | [operations.UploadReplayChunkRequest](../../models/operations/upload-replay-chunk-request.md)                                                                                  | :heavy_check_mark:                                                                                                                                                             | The request object to use for the request.                                                                                                                                     |
| `options`                                                                                                                                                                      | RequestOptions                                                                                                                                                                 | :heavy_minus_sign:                                                                                                                                                             | Used to set various options for making HTTP requests.                                                                                                                          |
| `options.fetchOptions`                                                                                                                                                         | [RequestInit](https://developer.mozilla.org/en-US/docs/Web/API/Request/Request#options)                                                                                        | :heavy_minus_sign:                                                                                                                                                             | Options that are passed to the underlying HTTP request. This can be used to inject extra headers for examples. All `Request` options, except `method` and `body`, are allowed. |
| `options.retries`                                                                                                                                                              | [RetryConfig](../../lib/utils/retryconfig.md)                                                                                                                                  | :heavy_minus_sign:                                                                                                                                                             | Enables retrying HTTP requests under certain failure conditions.                                                                                                               |

### Response

**Promise\<[models.ReplayUploadChunkResponse](../../models/replay-upload-chunk-response.md)\>**

### Errors

| Error Type                           | Status Code                          | Content Type                         |
| ------------------------------------ | ------------------------------------ | ------------------------------------ |
| errors.LibraryBareError              | 401, 403, 422                        | application/json                     |
| errors.LibraryBareError              | 401, 403, 422                        | application/json                     |
| errors.LibraryBareError              | 401, 403, 422                        | application/json                     |
| errors.LibraryBareError              | 401, 403, 422                        | application/json                     |
| errors.LibraryBareError              | 401, 403, 422                        | application/json                     |
| errors.LibraryBareError              | 401, 403, 422                        | application/json                     |
| errors.ValidationError               | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.ReleaseSignTooManyFilesError  | 401, 403, 422                        | application/json                     |
| errors.ReleaseSignFileTooLargeError  | 401, 403, 422                        | application/json                     |
| errors.ReleaseSignDuplicatePathError | 401, 403, 422                        | application/json                     |
| errors.InterfereError                | 4XX, 5XX                             | \*/\*                                |