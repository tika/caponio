# V2

## Overview

### Available Operations

* [v2Sink](#v2sink)

## v2Sink

### Example Usage

<!-- UsageSnippet language="typescript" operationID="v2_sink" method="post" path="/v2/sink" -->
```typescript
import { Interfere } from "@interfere/sdk";

const interfere = new Interfere();

async function run() {
  const result = await interfere.v2.v2Sink();

  console.log(result);
}

run();
```

### Standalone function

The standalone function version of this method:

```typescript
import { InterfereCore } from "@interfere/sdk/core.js";
import { v2V2Sink } from "@interfere/sdk/funcs/v2-v2-sink.js";

// Use `InterfereCore` for best tree-shaking performance.
// You can create one instance of it to use across an application.
const interfere = new InterfereCore();

async function run() {
  const res = await v2V2Sink(interfere);
  if (res.ok) {
    const { value: result } = res;
    console.log(result);
  } else {
    console.log("v2V2Sink failed:", res.error);
  }
}

run();
```

### Parameters

| Parameter                                                                                                                                                                      | Type                                                                                                                                                                           | Required                                                                                                                                                                       | Description                                                                                                                                                                    |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `options`                                                                                                                                                                      | RequestOptions                                                                                                                                                                 | :heavy_minus_sign:                                                                                                                                                             | Used to set various options for making HTTP requests.                                                                                                                          |
| `options.fetchOptions`                                                                                                                                                         | [RequestInit](https://developer.mozilla.org/en-US/docs/Web/API/Request/Request#options)                                                                                        | :heavy_minus_sign:                                                                                                                                                             | Options that are passed to the underlying HTTP request. This can be used to inject extra headers for examples. All `Request` options, except `method` and `body`, are allowed. |
| `options.retries`                                                                                                                                                              | [RetryConfig](../../lib/utils/retryconfig.md)                                                                                                                                  | :heavy_minus_sign:                                                                                                                                                             | Enables retrying HTTP requests under certain failure conditions.                                                                                                               |

### Response

**Promise\<[models.SinkAcceptedResponse](../../models/sink-accepted-response.md)\>**

### Errors

| Error Type                           | Status Code                          | Content Type                         |
| ------------------------------------ | ------------------------------------ | ------------------------------------ |
| errors.LibraryBareError              | 400, 415, 422                        | application/json                     |
| errors.LibraryBareError              | 400, 415, 422                        | application/json                     |
| errors.LibraryBareError              | 400, 415, 422                        | application/json                     |
| errors.LibraryBareError              | 400, 415, 422                        | application/json                     |
| errors.LibraryBareError              | 400, 415, 422                        | application/json                     |
| errors.LibraryBareError              | 400, 415, 422                        | application/json                     |
| errors.ValidationError               | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.CollectorBareError            | 400, 415, 422                        | application/json                     |
| errors.ReleaseSignTooManyFilesError  | 400, 415, 422                        | application/json                     |
| errors.ReleaseSignFileTooLargeError  | 400, 415, 422                        | application/json                     |
| errors.ReleaseSignDuplicatePathError | 400, 415, 422                        | application/json                     |
| errors.LibraryBareError              | 503                                  | application/json                     |
| errors.LibraryBareError              | 503                                  | application/json                     |
| errors.LibraryBareError              | 503                                  | application/json                     |
| errors.LibraryBareError              | 503                                  | application/json                     |
| errors.LibraryBareError              | 503                                  | application/json                     |
| errors.LibraryBareError              | 503                                  | application/json                     |
| errors.ValidationError               | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.CollectorBareError            | 503                                  | application/json                     |
| errors.ReleaseSignTooManyFilesError  | 503                                  | application/json                     |
| errors.ReleaseSignFileTooLargeError  | 503                                  | application/json                     |
| errors.ReleaseSignDuplicatePathError | 503                                  | application/json                     |
| errors.InterfereError                | 4XX, 5XX                             | \*/\*                                |