# Sessions

## Overview

Session management

### Available Operations

* [create](#create)
* [identify](#identify)

## create

### Example Usage

<!-- UsageSnippet language="typescript" operationID="createSession" method="post" path="/v2/session/" -->
```typescript
import { Interfere } from "@interfere/sdk";

const interfere = new Interfere();

async function run() {
  const result = await interfere.sessions.create({
    sessionId: "<id>",
  });

  console.log(result);
}

run();
```

### Standalone function

The standalone function version of this method:

```typescript
import { InterfereCore } from "@interfere/sdk/core.js";
import { sessionsCreate } from "@interfere/sdk/funcs/sessions-create.js";

// Use `InterfereCore` for best tree-shaking performance.
// You can create one instance of it to use across an application.
const interfere = new InterfereCore();

async function run() {
  const res = await sessionsCreate(interfere, {
    sessionId: "<id>",
  });
  if (res.ok) {
    const { value: result } = res;
    console.log(result);
  } else {
    console.log("sessionsCreate failed:", res.error);
  }
}

run();
```

### Parameters

| Parameter                                                                                                                                                                      | Type                                                                                                                                                                           | Required                                                                                                                                                                       | Description                                                                                                                                                                    |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `request`                                                                                                                                                                      | [models.SessionCreateRequest](../../models/session-create-request.md)                                                                                                          | :heavy_check_mark:                                                                                                                                                             | The request object to use for the request.                                                                                                                                     |
| `options`                                                                                                                                                                      | RequestOptions                                                                                                                                                                 | :heavy_minus_sign:                                                                                                                                                             | Used to set various options for making HTTP requests.                                                                                                                          |
| `options.fetchOptions`                                                                                                                                                         | [RequestInit](https://developer.mozilla.org/en-US/docs/Web/API/Request/Request#options)                                                                                        | :heavy_minus_sign:                                                                                                                                                             | Options that are passed to the underlying HTTP request. This can be used to inject extra headers for examples. All `Request` options, except `method` and `body`, are allowed. |
| `options.retries`                                                                                                                                                              | [RetryConfig](../../lib/utils/retryconfig.md)                                                                                                                                  | :heavy_minus_sign:                                                                                                                                                             | Enables retrying HTTP requests under certain failure conditions.                                                                                                               |

### Response

**Promise\<[models.SessionResponse](../../models/session-response.md)\>**

### Errors

| Error Type                           | Status Code                          | Content Type                         |
| ------------------------------------ | ------------------------------------ | ------------------------------------ |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.ValidationError               | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.ReleaseSignTooManyFilesError  | 401                                  | application/json                     |
| errors.ReleaseSignFileTooLargeError  | 401                                  | application/json                     |
| errors.ReleaseSignDuplicatePathError | 401                                  | application/json                     |
| errors.InterfereError                | 4XX, 5XX                             | \*/\*                                |

## identify

### Example Usage

<!-- UsageSnippet language="typescript" operationID="identifySession" method="post" path="/v2/session/identify" -->
```typescript
import { Interfere } from "@interfere/sdk";

const interfere = new Interfere();

async function run() {
  const result = await interfere.sessions.identify({
    sessionId: "<id>",
    identifier: "<value>",
    source: {
      name: "Clerk",
      type: "clerk",
    },
  });

  console.log(result);
}

run();
```

### Standalone function

The standalone function version of this method:

```typescript
import { InterfereCore } from "@interfere/sdk/core.js";
import { sessionsIdentify } from "@interfere/sdk/funcs/sessions-identify.js";

// Use `InterfereCore` for best tree-shaking performance.
// You can create one instance of it to use across an application.
const interfere = new InterfereCore();

async function run() {
  const res = await sessionsIdentify(interfere, {
    sessionId: "<id>",
    identifier: "<value>",
    source: {
      name: "Clerk",
      type: "clerk",
    },
  });
  if (res.ok) {
    const { value: result } = res;
    console.log(result);
  } else {
    console.log("sessionsIdentify failed:", res.error);
  }
}

run();
```

### Parameters

| Parameter                                                                                                                                                                      | Type                                                                                                                                                                           | Required                                                                                                                                                                       | Description                                                                                                                                                                    |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `request`                                                                                                                                                                      | [models.SessionIdentifyRequest](../../models/session-identify-request.md)                                                                                                      | :heavy_check_mark:                                                                                                                                                             | The request object to use for the request.                                                                                                                                     |
| `options`                                                                                                                                                                      | RequestOptions                                                                                                                                                                 | :heavy_minus_sign:                                                                                                                                                             | Used to set various options for making HTTP requests.                                                                                                                          |
| `options.fetchOptions`                                                                                                                                                         | [RequestInit](https://developer.mozilla.org/en-US/docs/Web/API/Request/Request#options)                                                                                        | :heavy_minus_sign:                                                                                                                                                             | Options that are passed to the underlying HTTP request. This can be used to inject extra headers for examples. All `Request` options, except `method` and `body`, are allowed. |
| `options.retries`                                                                                                                                                              | [RetryConfig](../../lib/utils/retryconfig.md)                                                                                                                                  | :heavy_minus_sign:                                                                                                                                                             | Enables retrying HTTP requests under certain failure conditions.                                                                                                               |

### Response

**Promise\<[models.SessionResponse](../../models/session-response.md)\>**

### Errors

| Error Type                           | Status Code                          | Content Type                         |
| ------------------------------------ | ------------------------------------ | ------------------------------------ |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.ValidationError               | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.ReleaseSignTooManyFilesError  | 401                                  | application/json                     |
| errors.ReleaseSignFileTooLargeError  | 401                                  | application/json                     |
| errors.ReleaseSignDuplicatePathError | 401                                  | application/json                     |
| errors.InterfereError                | 4XX, 5XX                             | \*/\*                                |