# Config

## Overview

SDK configuration

### Available Operations

* [get](#get)

## get

### Example Usage

<!-- UsageSnippet language="typescript" operationID="getConfig" method="get" path="/v2/config/" -->
```typescript
import { Interfere } from "@interfere/sdk";

const interfere = new Interfere();

async function run() {
  const result = await interfere.config.get();

  console.log(result);
}

run();
```

### Standalone function

The standalone function version of this method:

```typescript
import { InterfereCore } from "@interfere/sdk/core.js";
import { configGet } from "@interfere/sdk/funcs/config-get.js";

// Use `InterfereCore` for best tree-shaking performance.
// You can create one instance of it to use across an application.
const interfere = new InterfereCore();

async function run() {
  const res = await configGet(interfere);
  if (res.ok) {
    const { value: result } = res;
    console.log(result);
  } else {
    console.log("configGet failed:", res.error);
  }
}

run();
```

### Parameters

| Parameter                                                                                                                                                                      | Type                                                                                                                                                                           | Required                                                                                                                                                                       | Description                                                                                                                                                                    |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `options`                                                                                                                                                                      | RequestOptions                                                                                                                                                                 | :heavy_minus_sign:                                                                                                                                                             | Used to set various options for making HTTP requests.                                                                                                                          |
| `options.fetchOptions`                                                                                                                                                         | [RequestInit](https://developer.mozilla.org/en-US/docs/Web/API/Request/Request#options)                                                                                        | :heavy_minus_sign:                                                                                                                                                             | Options that are passed to the underlying HTTP request. This can be used to inject extra headers for examples. All `Request` options, except `method` and `body`, are allowed. |
| `options.retries`                                                                                                                                                              | [RetryConfig](../../lib/utils/retryconfig.md)                                                                                                                                  | :heavy_minus_sign:                                                                                                                                                             | Enables retrying HTTP requests under certain failure conditions.                                                                                                               |

### Response

**Promise\<[models.ConfigResponse](../../models/config-response.md)\>**

### Errors

| Error Type                           | Status Code                          | Content Type                         |
| ------------------------------------ | ------------------------------------ | ------------------------------------ |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.LibraryBareError              | 401                                  | application/json                     |
| errors.ValidationError               | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.CollectorBareError            | 401                                  | application/json                     |
| errors.ReleaseSignTooManyFilesError  | 401                                  | application/json                     |
| errors.ReleaseSignFileTooLargeError  | 401                                  | application/json                     |
| errors.ReleaseSignDuplicatePathError | 401                                  | application/json                     |
| errors.InterfereError                | 4XX, 5XX                             | \*/\*                                |