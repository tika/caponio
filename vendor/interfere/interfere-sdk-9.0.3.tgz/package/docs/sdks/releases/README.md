# Releases

## Overview

Release management

### Available Operations

* [getConfig](#getconfig)
* [create](#create)
* [preflight](#preflight)

## getConfig

### Example Usage

<!-- UsageSnippet language="typescript" operationID="getReleasesConfig" method="get" path="/v1/releases/config" -->
```typescript
import { Interfere } from "@interfere/sdk";

const interfere = new Interfere();

async function run() {
  const result = await interfere.releases.getConfig();

  console.log(result);
}

run();
```

### Standalone function

The standalone function version of this method:

```typescript
import { InterfereCore } from "@interfere/sdk/core.js";
import { releasesGetConfig } from "@interfere/sdk/funcs/releases-get-config.js";

// Use `InterfereCore` for best tree-shaking performance.
// You can create one instance of it to use across an application.
const interfere = new InterfereCore();

async function run() {
  const res = await releasesGetConfig(interfere);
  if (res.ok) {
    const { value: result } = res;
    console.log(result);
  } else {
    console.log("releasesGetConfig failed:", res.error);
  }
}

run();
```

### Parameters

| Parameter                                                                                                                                                                      | Type                                                                                                                                                                           | Required                                                                                                                                                                       | Description                                                                                                                                                                    |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `options`                                                                                                                                                                      | RequestOptions                                                                                                                                                                 | :heavy_minus_sign:                                                                                                                                                             | Used to set various options for making HTTP requests.                                                                                                                          |
| `options.fetchOptions`                                                                                                                                                         | [RequestInit](https://developer.mozilla.org/en-US/docs/Web/API/Request/Request#options)                                                                                        | :heavy_minus_sign:                                                                                                                                                             | Options that are passed to the underlying HTTP request. This can be used to inject extra headers for examples. All `Request` options, except `method` and `body`, are allowed. |
| `options.retries`                                                                                                                                                              | [RetryConfig](../../lib/utils/retryconfig.md)                                                                                                                                  | :heavy_minus_sign:                                                                                                                                                             | Enables retrying HTTP requests under certain failure conditions.                                                                                                               |

### Response

**Promise\<[models.ReleasesConfigResponse](../../models/releases-config-response.md)\>**

### Errors

| Error Type                           | Status Code                          | Content Type                         |
| ------------------------------------ | ------------------------------------ | ------------------------------------ |
| errors.LibraryBareError              | 401, 403                             | application/json                     |
| errors.LibraryBareError              | 401, 403                             | application/json                     |
| errors.LibraryBareError              | 401, 403                             | application/json                     |
| errors.LibraryBareError              | 401, 403                             | application/json                     |
| errors.LibraryBareError              | 401, 403                             | application/json                     |
| errors.LibraryBareError              | 401, 403                             | application/json                     |
| errors.ValidationError               | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.CollectorBareError            | 401, 403                             | application/json                     |
| errors.ReleaseSignTooManyFilesError  | 401, 403                             | application/json                     |
| errors.ReleaseSignFileTooLargeError  | 401, 403                             | application/json                     |
| errors.ReleaseSignDuplicatePathError | 401, 403                             | application/json                     |
| errors.InterfereError                | 4XX, 5XX                             | \*/\*                                |

## create

### Example Usage

<!-- UsageSnippet language="typescript" operationID="createRelease" method="post" path="/v1/releases/" -->
```typescript
import { Interfere } from "@interfere/sdk";

const interfere = new Interfere();

async function run() {
  const result = await interfere.releases.create({
    source: {
      provider: "github",
      commitMessage: "<value>",
      branch: "<value>",
      commitSha: "<value>",
    },
    destination: {
      provider: "vercel",
      destinationReleaseId: "<id>",
      environment: "<value>",
      deploymentId: "<id>",
      deploymentUrl: "https://narrow-sauerkraut.name",
      environmentName: "<value>",
      environmentTarget: "<value>",
    },
    buildId: "<id>",
  });

  console.log(result);
}

run();
```

### Standalone function

The standalone function version of this method:

```typescript
import { InterfereCore } from "@interfere/sdk/core.js";
import { releasesCreate } from "@interfere/sdk/funcs/releases-create.js";

// Use `InterfereCore` for best tree-shaking performance.
// You can create one instance of it to use across an application.
const interfere = new InterfereCore();

async function run() {
  const res = await releasesCreate(interfere, {
    source: {
      provider: "github",
      commitMessage: "<value>",
      branch: "<value>",
      commitSha: "<value>",
    },
    destination: {
      provider: "vercel",
      destinationReleaseId: "<id>",
      environment: "<value>",
      deploymentId: "<id>",
      deploymentUrl: "https://narrow-sauerkraut.name",
      environmentName: "<value>",
      environmentTarget: "<value>",
    },
    buildId: "<id>",
  });
  if (res.ok) {
    const { value: result } = res;
    console.log(result);
  } else {
    console.log("releasesCreate failed:", res.error);
  }
}

run();
```

### Parameters

| Parameter                                                                                                                                                                      | Type                                                                                                                                                                           | Required                                                                                                                                                                       | Description                                                                                                                                                                    |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `request`                                                                                                                                                                      | [models.ReleasesCreateRequest](../../models/releases-create-request.md)                                                                                                        | :heavy_check_mark:                                                                                                                                                             | The request object to use for the request.                                                                                                                                     |
| `options`                                                                                                                                                                      | RequestOptions                                                                                                                                                                 | :heavy_minus_sign:                                                                                                                                                             | Used to set various options for making HTTP requests.                                                                                                                          |
| `options.fetchOptions`                                                                                                                                                         | [RequestInit](https://developer.mozilla.org/en-US/docs/Web/API/Request/Request#options)                                                                                        | :heavy_minus_sign:                                                                                                                                                             | Options that are passed to the underlying HTTP request. This can be used to inject extra headers for examples. All `Request` options, except `method` and `body`, are allowed. |
| `options.retries`                                                                                                                                                              | [RetryConfig](../../lib/utils/retryconfig.md)                                                                                                                                  | :heavy_minus_sign:                                                                                                                                                             | Enables retrying HTTP requests under certain failure conditions.                                                                                                               |

### Response

**Promise\<[models.ReleasesCreateResponse](../../models/releases-create-response.md)\>**

### Errors

| Error Type                           | Status Code                          | Content Type                         |
| ------------------------------------ | ------------------------------------ | ------------------------------------ |
| errors.LibraryBareError              | 401, 403, 422                        | application/json                     |
| errors.LibraryBareError              | 401, 403, 422                        | application/json                     |
| errors.LibraryBareError              | 401, 403, 422                        | application/json                     |
| errors.LibraryBareError              | 401, 403, 422                        | application/json                     |
| errors.LibraryBareError              | 401, 403, 422                        | application/json                     |
| errors.LibraryBareError              | 401, 403, 422                        | application/json                     |
| errors.ValidationError               | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 422                        | application/json                     |
| errors.ReleaseSignTooManyFilesError  | 401, 403, 422                        | application/json                     |
| errors.ReleaseSignFileTooLargeError  | 401, 403, 422                        | application/json                     |
| errors.ReleaseSignDuplicatePathError | 401, 403, 422                        | application/json                     |
| errors.InterfereError                | 4XX, 5XX                             | \*/\*                                |

## preflight

### Example Usage

<!-- UsageSnippet language="typescript" operationID="confirmPreflight" method="post" path="/v1/releases/{releaseSlug}/preflight" -->
```typescript
import { Interfere } from "@interfere/sdk";

const interfere = new Interfere();

async function run() {
  const result = await interfere.releases.preflight({
    releaseSlug: "<value>",
  });

  console.log(result);
}

run();
```

### Standalone function

The standalone function version of this method:

```typescript
import { InterfereCore } from "@interfere/sdk/core.js";
import { releasesPreflight } from "@interfere/sdk/funcs/releases-preflight.js";

// Use `InterfereCore` for best tree-shaking performance.
// You can create one instance of it to use across an application.
const interfere = new InterfereCore();

async function run() {
  const res = await releasesPreflight(interfere, {
    releaseSlug: "<value>",
  });
  if (res.ok) {
    const { value: result } = res;
    console.log(result);
  } else {
    console.log("releasesPreflight failed:", res.error);
  }
}

run();
```

### Parameters

| Parameter                                                                                                                                                                      | Type                                                                                                                                                                           | Required                                                                                                                                                                       | Description                                                                                                                                                                    |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `request`                                                                                                                                                                      | [operations.ConfirmPreflightRequest](../../models/operations/confirm-preflight-request.md)                                                                                     | :heavy_check_mark:                                                                                                                                                             | The request object to use for the request.                                                                                                                                     |
| `options`                                                                                                                                                                      | RequestOptions                                                                                                                                                                 | :heavy_minus_sign:                                                                                                                                                             | Used to set various options for making HTTP requests.                                                                                                                          |
| `options.fetchOptions`                                                                                                                                                         | [RequestInit](https://developer.mozilla.org/en-US/docs/Web/API/Request/Request#options)                                                                                        | :heavy_minus_sign:                                                                                                                                                             | Options that are passed to the underlying HTTP request. This can be used to inject extra headers for examples. All `Request` options, except `method` and `body`, are allowed. |
| `options.retries`                                                                                                                                                              | [RetryConfig](../../lib/utils/retryconfig.md)                                                                                                                                  | :heavy_minus_sign:                                                                                                                                                             | Enables retrying HTTP requests under certain failure conditions.                                                                                                               |

### Response

**Promise\<[models.ReleasesPreflightResponse](../../models/releases-preflight-response.md)\>**

### Errors

| Error Type                           | Status Code                          | Content Type                         |
| ------------------------------------ | ------------------------------------ | ------------------------------------ |
| errors.LibraryBareError              | 401, 403, 404                        | application/json                     |
| errors.LibraryBareError              | 401, 403, 404                        | application/json                     |
| errors.LibraryBareError              | 401, 403, 404                        | application/json                     |
| errors.LibraryBareError              | 401, 403, 404                        | application/json                     |
| errors.LibraryBareError              | 401, 403, 404                        | application/json                     |
| errors.LibraryBareError              | 401, 403, 404                        | application/json                     |
| errors.ValidationError               | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.CollectorBareError            | 401, 403, 404                        | application/json                     |
| errors.ReleaseSignTooManyFilesError  | 401, 403, 404                        | application/json                     |
| errors.ReleaseSignFileTooLargeError  | 401, 403, 404                        | application/json                     |
| errors.ReleaseSignDuplicatePathError | 401, 403, 404                        | application/json                     |
| errors.InterfereError                | 4XX, 5XX                             | \*/\*                                |