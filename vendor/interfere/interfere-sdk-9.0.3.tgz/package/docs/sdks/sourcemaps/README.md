# SourceMaps

## Overview

Source map uploads

### Available Operations

* [~~upload~~](#upload) - :warning: **Deprecated**
* [sign](#sign)
* [complete](#complete)

## ~~upload~~

> :warning: **DEPRECATED**: This will be removed in a future release, please migrate away from it as soon as possible.

### Example Usage

<!-- UsageSnippet language="typescript" operationID="uploadSourceMaps" method="post" path="/v1/releases/{releaseSlug}/source-maps" -->
```typescript
import { Interfere } from "@interfere/sdk";

const interfere = new Interfere();

async function run() {
  const result = await interfere.sourceMaps.upload({
    releaseSlug: "<value>",
    body: {
      files: [],
      metadata: {
        entries: [],
        bundler: "webpack",
      },
    },
  });

  console.log(result);
}

run();
```

### Standalone function

The standalone function version of this method:

```typescript
import { InterfereCore } from "@interfere/sdk/core.js";
import { sourceMapsUpload } from "@interfere/sdk/funcs/source-maps-upload.js";

// Use `InterfereCore` for best tree-shaking performance.
// You can create one instance of it to use across an application.
const interfere = new InterfereCore();

async function run() {
  const res = await sourceMapsUpload(interfere, {
    releaseSlug: "<value>",
    body: {
      files: [],
      metadata: {
        entries: [],
        bundler: "webpack",
      },
    },
  });
  if (res.ok) {
    const { value: result } = res;
    console.log(result);
  } else {
    console.log("sourceMapsUpload failed:", res.error);
  }
}

run();
```

### Parameters

| Parameter                                                                                                                                                                      | Type                                                                                                                                                                           | Required                                                                                                                                                                       | Description                                                                                                                                                                    |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `request`                                                                                                                                                                      | [operations.UploadSourceMapsRequest](../../models/operations/upload-source-maps-request.md)                                                                                    | :heavy_check_mark:                                                                                                                                                             | The request object to use for the request.                                                                                                                                     |
| `options`                                                                                                                                                                      | RequestOptions                                                                                                                                                                 | :heavy_minus_sign:                                                                                                                                                             | Used to set various options for making HTTP requests.                                                                                                                          |
| `options.fetchOptions`                                                                                                                                                         | [RequestInit](https://developer.mozilla.org/en-US/docs/Web/API/Request/Request#options)                                                                                        | :heavy_minus_sign:                                                                                                                                                             | Options that are passed to the underlying HTTP request. This can be used to inject extra headers for examples. All `Request` options, except `method` and `body`, are allowed. |
| `options.retries`                                                                                                                                                              | [RetryConfig](../../lib/utils/retryconfig.md)                                                                                                                                  | :heavy_minus_sign:                                                                                                                                                             | Enables retrying HTTP requests under certain failure conditions.                                                                                                               |

### Response

**Promise\<[models.ReleasesUploadSourceMapsResponse](../../models/releases-upload-source-maps-response.md)\>**

### Errors

| Error Type                           | Status Code                          | Content Type                         |
| ------------------------------------ | ------------------------------------ | ------------------------------------ |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.ValidationError               | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.ReleaseSignTooManyFilesError  | 401, 403, 404, 422                   | application/json                     |
| errors.ReleaseSignFileTooLargeError  | 401, 403, 404, 422                   | application/json                     |
| errors.ReleaseSignDuplicatePathError | 401, 403, 404, 422                   | application/json                     |
| errors.InterfereError                | 4XX, 5XX                             | \*/\*                                |

## sign

### Example Usage

<!-- UsageSnippet language="typescript" operationID="signSourceMapUploads" method="post" path="/v1/releases/{releaseSlug}/source-maps/sign" -->
```typescript
import { Interfere } from "@interfere/sdk";

const interfere = new Interfere();

async function run() {
  const result = await interfere.sourceMaps.sign({
    releaseSlug: "<value>",
    body: {
      files: [
        {
          path: "/sbin",
          sizeBytes: 776569,
          hasSourcesContent: false,
          hasNames: true,
          hasFile: false,
          mappingsPresent: false,
        },
      ],
    },
  });

  console.log(result);
}

run();
```

### Standalone function

The standalone function version of this method:

```typescript
import { InterfereCore } from "@interfere/sdk/core.js";
import { sourceMapsSign } from "@interfere/sdk/funcs/source-maps-sign.js";

// Use `InterfereCore` for best tree-shaking performance.
// You can create one instance of it to use across an application.
const interfere = new InterfereCore();

async function run() {
  const res = await sourceMapsSign(interfere, {
    releaseSlug: "<value>",
    body: {
      files: [
        {
          path: "/sbin",
          sizeBytes: 776569,
          hasSourcesContent: false,
          hasNames: true,
          hasFile: false,
          mappingsPresent: false,
        },
      ],
    },
  });
  if (res.ok) {
    const { value: result } = res;
    console.log(result);
  } else {
    console.log("sourceMapsSign failed:", res.error);
  }
}

run();
```

### Parameters

| Parameter                                                                                                                                                                      | Type                                                                                                                                                                           | Required                                                                                                                                                                       | Description                                                                                                                                                                    |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `request`                                                                                                                                                                      | [operations.SignSourceMapUploadsRequest](../../models/operations/sign-source-map-uploads-request.md)                                                                           | :heavy_check_mark:                                                                                                                                                             | The request object to use for the request.                                                                                                                                     |
| `options`                                                                                                                                                                      | RequestOptions                                                                                                                                                                 | :heavy_minus_sign:                                                                                                                                                             | Used to set various options for making HTTP requests.                                                                                                                          |
| `options.fetchOptions`                                                                                                                                                         | [RequestInit](https://developer.mozilla.org/en-US/docs/Web/API/Request/Request#options)                                                                                        | :heavy_minus_sign:                                                                                                                                                             | Options that are passed to the underlying HTTP request. This can be used to inject extra headers for examples. All `Request` options, except `method` and `body`, are allowed. |
| `options.retries`                                                                                                                                                              | [RetryConfig](../../lib/utils/retryconfig.md)                                                                                                                                  | :heavy_minus_sign:                                                                                                                                                             | Enables retrying HTTP requests under certain failure conditions.                                                                                                               |

### Response

**Promise\<[models.ReleasesSignSourceMapsResponse](../../models/releases-sign-source-maps-response.md)\>**

### Errors

| Error Type                           | Status Code                          | Content Type                         |
| ------------------------------------ | ------------------------------------ | ------------------------------------ |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.ValidationError               | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.ReleaseSignTooManyFilesError  | 401, 403, 404, 422                   | application/json                     |
| errors.ReleaseSignFileTooLargeError  | 401, 403, 404, 422                   | application/json                     |
| errors.ReleaseSignDuplicatePathError | 401, 403, 404, 422                   | application/json                     |
| errors.InterfereError                | 4XX, 5XX                             | \*/\*                                |

## complete

### Example Usage

<!-- UsageSnippet language="typescript" operationID="completeSourceMapUploads" method="post" path="/v1/releases/{releaseSlug}/source-maps/complete" -->
```typescript
import { Interfere } from "@interfere/sdk";

const interfere = new Interfere();

async function run() {
  const result = await interfere.sourceMaps.complete({
    releaseSlug: "<value>",
    body: {
      files: [],
      bundler: "webpack",
    },
  });

  console.log(result);
}

run();
```

### Standalone function

The standalone function version of this method:

```typescript
import { InterfereCore } from "@interfere/sdk/core.js";
import { sourceMapsComplete } from "@interfere/sdk/funcs/source-maps-complete.js";

// Use `InterfereCore` for best tree-shaking performance.
// You can create one instance of it to use across an application.
const interfere = new InterfereCore();

async function run() {
  const res = await sourceMapsComplete(interfere, {
    releaseSlug: "<value>",
    body: {
      files: [],
      bundler: "webpack",
    },
  });
  if (res.ok) {
    const { value: result } = res;
    console.log(result);
  } else {
    console.log("sourceMapsComplete failed:", res.error);
  }
}

run();
```

### Parameters

| Parameter                                                                                                                                                                      | Type                                                                                                                                                                           | Required                                                                                                                                                                       | Description                                                                                                                                                                    |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `request`                                                                                                                                                                      | [operations.CompleteSourceMapUploadsRequest](../../models/operations/complete-source-map-uploads-request.md)                                                                   | :heavy_check_mark:                                                                                                                                                             | The request object to use for the request.                                                                                                                                     |
| `options`                                                                                                                                                                      | RequestOptions                                                                                                                                                                 | :heavy_minus_sign:                                                                                                                                                             | Used to set various options for making HTTP requests.                                                                                                                          |
| `options.fetchOptions`                                                                                                                                                         | [RequestInit](https://developer.mozilla.org/en-US/docs/Web/API/Request/Request#options)                                                                                        | :heavy_minus_sign:                                                                                                                                                             | Options that are passed to the underlying HTTP request. This can be used to inject extra headers for examples. All `Request` options, except `method` and `body`, are allowed. |
| `options.retries`                                                                                                                                                              | [RetryConfig](../../lib/utils/retryconfig.md)                                                                                                                                  | :heavy_minus_sign:                                                                                                                                                             | Enables retrying HTTP requests under certain failure conditions.                                                                                                               |

### Response

**Promise\<[models.ReleasesCompleteSourceMapsResponse](../../models/releases-complete-source-maps-response.md)\>**

### Errors

| Error Type                           | Status Code                          | Content Type                         |
| ------------------------------------ | ------------------------------------ | ------------------------------------ |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.LibraryBareError              | 401, 403, 404, 422                   | application/json                     |
| errors.ValidationError               | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.CollectorBareError            | 401, 403, 404, 422                   | application/json                     |
| errors.ReleaseSignTooManyFilesError  | 401, 403, 404, 422                   | application/json                     |
| errors.ReleaseSignFileTooLargeError  | 401, 403, 404, 422                   | application/json                     |
| errors.ReleaseSignDuplicatePathError | 401, 403, 404, 422                   | application/json                     |
| errors.InterfereError                | 4XX, 5XX                             | \*/\*                                |