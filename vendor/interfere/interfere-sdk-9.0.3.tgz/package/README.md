# Interfere SDK

[![License: MIT](https://img.shields.io/badge/LICENSE_//_MIT-3b5bdb?style=for-the-badge&labelColor=eff6ff)](https://opensource.org/licenses/MIT)


<br /><br />
> [!IMPORTANT]
> This SDK is not yet ready for external use, and only covers a very small subset of our API. We have plans to flesh out a fully built out public SDK in Q3 2026.

<!-- Start Summary [summary] -->
## Summary

Interfere Collector API: Public ingestion API for Interfere SDKs
<!-- End Summary [summary] -->

<!-- Start Table of Contents [toc] -->
## Table of Contents
<!-- $toc-max-depth=2 -->
* [Interfere SDK](#interfere-sdk)
  * [SDK Installation](#sdk-installation)
  * [Requirements](#requirements)
  * [SDK Example Usage](#sdk-example-usage)
  * [Available Resources and Operations](#available-resources-and-operations)
  * [Standalone functions](#standalone-functions)
  * [Retries](#retries)
  * [Error Handling](#error-handling)
  * [Server Selection](#server-selection)
  * [Custom HTTP Client](#custom-http-client)
  * [Debugging](#debugging)
* [Development](#development)
  * [Maturity](#maturity)

<!-- End Table of Contents [toc] -->

<!-- Start SDK Installation [installation] -->
## SDK Installation

> [!TIP]
> To finish publishing your SDK to npm and others you must [run your first generation action](https://www.speakeasy.com/docs/github-setup#step-by-step-guide).


The SDK can be installed with either [npm](https://www.npmjs.com/), [pnpm](https://pnpm.io/), [bun](https://bun.sh/) or [yarn](https://classic.yarnpkg.com/en/) package managers.

### NPM

```bash
npm add <UNSET>
```

### PNPM

```bash
pnpm add <UNSET>
```

### Bun

```bash
bun add <UNSET>
```

### Yarn

```bash
yarn add <UNSET>
```

> [!NOTE]
> This package is published as an ES Module (ESM) only. For applications using
> CommonJS, use `await import()` to import and use this package.
<!-- End SDK Installation [installation] -->

<!-- Start Requirements [requirements] -->
## Requirements

For supported JavaScript runtimes, please consult [RUNTIMES.md](RUNTIMES.md).
<!-- End Requirements [requirements] -->

<!-- Start SDK Example Usage [usage] -->
## SDK Example Usage

### Example

```typescript
import { Interfere } from "@interfere/sdk";

const interfere = new Interfere();

async function run() {
  const result = await interfere.health.get();

  console.log(result);
}

run();

```
<!-- End SDK Example Usage [usage] -->

<!-- Start Available Resources and Operations [operations] -->
## Available Resources and Operations

<details open>
<summary>Available methods</summary>

### [Config](docs/sdks/config/README.md)

* [get](docs/sdks/config/README.md#get)

### [Health](docs/sdks/health/README.md)

* [get](docs/sdks/health/README.md#get)

### [Releases](docs/sdks/releases/README.md)

* [getConfig](docs/sdks/releases/README.md#getconfig)
* [create](docs/sdks/releases/README.md#create)
* [preflight](docs/sdks/releases/README.md#preflight)

### [Replay](docs/sdks/replay/README.md)

* [uploadReplayChunk](docs/sdks/replay/README.md#uploadreplaychunk)

### [Sessions](docs/sdks/sessions/README.md)

* [create](docs/sdks/sessions/README.md#create)
* [identify](docs/sdks/sessions/README.md#identify)

### [SourceMaps](docs/sdks/sourcemaps/README.md)

* [~~upload~~](docs/sdks/sourcemaps/README.md#upload) - :warning: **Deprecated**
* [sign](docs/sdks/sourcemaps/README.md#sign)
* [complete](docs/sdks/sourcemaps/README.md#complete)

### [Telemetry](docs/sdks/telemetry/README.md)

* [report](docs/sdks/telemetry/README.md#report)

### [V2](docs/sdks/v2/README.md)

* [v2Sink](docs/sdks/v2/README.md#v2sink)

</details>
<!-- End Available Resources and Operations [operations] -->

<!-- Start Standalone functions [standalone-funcs] -->
## Standalone functions

All the methods listed above are available as standalone functions. These
functions are ideal for use in applications running in the browser, serverless
runtimes or other environments where application bundle size is a primary
concern. When using a bundler to build your application, all unused
functionality will be either excluded from the final bundle or tree-shaken away.

To read more about standalone functions, check [FUNCTIONS.md](./FUNCTIONS.md).

<details>

<summary>Available standalone functions</summary>

- [`configGet`](docs/sdks/config/README.md#get)
- [`healthGet`](docs/sdks/health/README.md#get)
- [`releasesCreate`](docs/sdks/releases/README.md#create)
- [`releasesGetConfig`](docs/sdks/releases/README.md#getconfig)
- [`releasesPreflight`](docs/sdks/releases/README.md#preflight)
- [`replayUploadReplayChunk`](docs/sdks/replay/README.md#uploadreplaychunk)
- [`sessionsCreate`](docs/sdks/sessions/README.md#create)
- [`sessionsIdentify`](docs/sdks/sessions/README.md#identify)
- [`sourceMapsComplete`](docs/sdks/sourcemaps/README.md#complete)
- [`sourceMapsSign`](docs/sdks/sourcemaps/README.md#sign)
- [`telemetryReport`](docs/sdks/telemetry/README.md#report)
- [`v2V2Sink`](docs/sdks/v2/README.md#v2sink)
- ~~[`sourceMapsUpload`](docs/sdks/sourcemaps/README.md#upload)~~ - :warning: **Deprecated**

</details>
<!-- End Standalone functions [standalone-funcs] -->

<!-- Start Retries [retries] -->
## Retries

Some of the endpoints in this SDK support retries.  If you use the SDK without any configuration, it will fall back to the default retry strategy provided by the API.  However, the default retry strategy can be overridden on a per-operation basis, or across the entire SDK.

To change the default retry strategy for a single API call, simply provide a retryConfig object to the call:
```typescript
import { Interfere } from "@interfere/sdk";

const interfere = new Interfere();

async function run() {
  const result = await interfere.health.get({
    retries: {
      strategy: "backoff",
      backoff: {
        initialInterval: 1,
        maxInterval: 50,
        exponent: 1.1,
        maxElapsedTime: 100,
      },
      retryConnectionErrors: false,
    },
  });

  console.log(result);
}

run();

```

If you'd like to override the default retry strategy for all operations that support retries, you can provide a retryConfig at SDK initialization:
```typescript
import { Interfere } from "@interfere/sdk";

const interfere = new Interfere({
  retryConfig: {
    strategy: "backoff",
    backoff: {
      initialInterval: 1,
      maxInterval: 50,
      exponent: 1.1,
      maxElapsedTime: 100,
    },
    retryConnectionErrors: false,
  },
});

async function run() {
  const result = await interfere.health.get();

  console.log(result);
}

run();

```
<!-- End Retries [retries] -->

<!-- Start Error Handling [errors] -->
## Error Handling

[`InterfereHTTPError`](./src/models/errors/interfere-http-error.ts) is the base class for all HTTP error responses. It has the following properties:

| Property            | Type       | Description                                                                             |
| ------------------- | ---------- | --------------------------------------------------------------------------------------- |
| `error.message`     | `string`   | Error message                                                                           |
| `error.statusCode`  | `number`   | HTTP response status code eg `404`                                                      |
| `error.headers`     | `Headers`  | HTTP response headers                                                                   |
| `error.body`        | `string`   | HTTP body. Can be empty string if no body is returned.                                  |
| `error.rawResponse` | `Response` | Raw HTTP response                                                                       |
| `error.data$`       |            | Optional. Some errors may contain structured data. [See Error Classes](#error-classes). |

### Example
```typescript
import { Interfere } from "@interfere/sdk";
import * as errors from "@interfere/sdk/models/errors";

const interfere = new Interfere();

async function run() {
  try {
    const result = await interfere.health.get();

    console.log(result);
  } catch (error) {
    // The base class for HTTP error responses
    if (error instanceof errors.InterfereHTTPError) {
      console.log(error.message);
      console.log(error.statusCode);
      console.log(error.body);
      console.log(error.headers);

      // Depending on the method different errors may be thrown
      if (error instanceof errors.HealthError) {
        console.log(error.data$.ok); // boolean
        console.log(error.data$.message); // string
      }
    }
  }
}

run();

```

### Error Classes
**Primary errors:**
* [`InterfereHTTPError`](./src/models/errors/interfere-http-error.ts): The base class for HTTP error responses.
  * [`LibraryBareError`](./src/models/errors/library-bare-error.ts): *
  * [`ValidationError`](./src/models/errors/validation-error.ts): *
  * [`CollectorBareError`](./src/models/errors/collector-bare-error.ts): *
  * [`ReleaseSignTooManyFilesError`](./src/models/errors/release-sign-too-many-files-error.ts): *
  * [`ReleaseSignFileTooLargeError`](./src/models/errors/release-sign-file-too-large-error.ts): *
  * [`ReleaseSignDuplicatePathError`](./src/models/errors/release-sign-duplicate-path-error.ts): *

<details><summary>Less common errors (7)</summary>

<br />

**Network errors:**
* [`ConnectionError`](./src/models/errors/http-client-errors.ts): HTTP client was unable to make a request to a server.
* [`RequestTimeoutError`](./src/models/errors/http-client-errors.ts): HTTP request timed out due to an AbortSignal signal.
* [`RequestAbortedError`](./src/models/errors/http-client-errors.ts): HTTP request was aborted by the client.
* [`InvalidRequestError`](./src/models/errors/http-client-errors.ts): Any input used to create a request is invalid.
* [`UnexpectedClientError`](./src/models/errors/http-client-errors.ts): Unrecognised or unexpected error.


**Inherit from [`InterfereHTTPError`](./src/models/errors/interfere-http-error.ts)**:
* [`HealthError`](./src/models/errors/health-error.ts): Response for status 500. Status code `500`. Applicable to 1 of 13 methods.*
* [`ResponseValidationError`](./src/models/errors/response-validation-error.ts): Type mismatch between the data returned from the server and the structure expected by the SDK. See `error.rawValue` for the raw value and `error.pretty()` for a nicely formatted multi-line string.

</details>

\* Check [the method documentation](#available-resources-and-operations) to see if the error is applicable.
<!-- End Error Handling [errors] -->

<!-- Start Server Selection [server] -->
## Server Selection

### Override Server URL Per-Client

The default server can be overridden globally by passing a URL to the `serverURL: string` optional parameter when initializing the SDK client instance. For example:
```typescript
import { Interfere } from "@interfere/sdk";

const interfere = new Interfere({
  serverURL: "https://in.interfere.com",
});

async function run() {
  const result = await interfere.health.get();

  console.log(result);
}

run();

```
<!-- End Server Selection [server] -->

<!-- Start Custom HTTP Client [http-client] -->
## Custom HTTP Client

The TypeScript SDK makes API calls using an `HTTPClient` that wraps the native
[Fetch API](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API). This
client is a thin wrapper around `fetch` and provides the ability to attach hooks
around the request lifecycle that can be used to modify the request or handle
errors and response.

The `HTTPClient` constructor takes an optional `fetcher` argument that can be
used to integrate a third-party HTTP client or when writing tests to mock out
the HTTP client and feed in fixtures.

The following example shows how to:
- route requests through a proxy server using [undici](https://www.npmjs.com/package/undici)'s ProxyAgent
- use the `"beforeRequest"` hook to add a custom header and a timeout to requests
- use the `"requestError"` hook to log errors

```typescript
import { Interfere } from "@interfere/sdk";
import { ProxyAgent } from "undici";
import { HTTPClient } from "@interfere/sdk/lib/http";

const dispatcher = new ProxyAgent("http://proxy.example.com:8080");

const httpClient = new HTTPClient({
  // 'fetcher' takes a function that has the same signature as native 'fetch'.
  fetcher: (input, init) =>
    // 'dispatcher' is specific to undici and not part of the standard Fetch API.
    fetch(input, { ...init, dispatcher } as RequestInit),
});

httpClient.addHook("beforeRequest", (request) => {
  const nextRequest = new Request(request, {
    signal: request.signal || AbortSignal.timeout(5000)
  });

  nextRequest.headers.set("x-custom-header", "custom value");

  return nextRequest;
});

httpClient.addHook("requestError", (error, request) => {
  console.group("Request Error");
  console.log("Reason:", `${error}`);
  console.log("Endpoint:", `${request.method} ${request.url}`);
  console.groupEnd();
});

const sdk = new Interfere({ httpClient: httpClient });
```
<!-- End Custom HTTP Client [http-client] -->

<!-- Start Debugging [debug] -->
## Debugging

You can setup your SDK to emit debug logs for SDK requests and responses.

You can pass a logger that matches `console`'s interface as an SDK option.

> [!WARNING]
> Beware that debug logging will reveal secrets, like API tokens in headers, in log messages printed to a console or files. It's recommended to use this feature only during local development and not in production.

```typescript
import { Interfere } from "@interfere/sdk";

const sdk = new Interfere({ debugLogger: console });
```

You can also enable a default debug logger by setting an environment variable `INTERFERE_DEBUG` to true.
<!-- End Debugging [debug] -->

<!-- Placeholder for Future Speakeasy SDK Sections -->

# Development

## Maturity

This SDK is in beta, and there may be breaking changes between versions without a major version update. Therefore, we recommend pinning usage
to a specific package version. This way, you can install the same version each time without breaking changes unless you are intentionally
looking for the latest version.