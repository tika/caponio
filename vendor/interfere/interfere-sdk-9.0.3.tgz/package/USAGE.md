<!-- Start SDK Example Usage [usage] -->
```typescript
import { Interfere } from "@interfere/sdk";

const interfere = new Interfere();

async function run() {
  const result = await interfere.health.get();

  console.log(result);
}

run();

```
<!-- End SDK Example Usage [usage] -->