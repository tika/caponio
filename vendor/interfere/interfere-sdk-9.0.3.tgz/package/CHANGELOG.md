# @interfere/sdk

## 9.0.3

### Patch Changes

- [#1796](https://github.com/interfere-inc/interfere/pull/1796) [`7b3ccf6`](https://github.com/interfere-inc/interfere/commit/7b3ccf636f3121de4205c0e8b2ddcaea5e3bd6a9) Thanks [@skve](https://github.com/skve)! - Fixes an issue with source map uploading failing on larger projects

## 9.0.2

### Patch Changes

- [#1704](https://github.com/interfere-inc/interfere/pull/1704) [`3279b68`](https://github.com/interfere-inc/interfere/commit/3279b6880d32a0be71773c92e54cd6de79262614) Thanks [@skve](https://github.com/skve)! - Now confirms release completion explicitly and non-complete releases are excluded from evidence

## 8.1.6

### Patch Changes

- [#1665](https://github.com/interfere-inc/interfere/pull/1665) [`01e037e`](https://github.com/interfere-inc/interfere/commit/01e037e5dc3f6a013124dab44863d87a9be93029) Thanks [@skve](https://github.com/skve)! - Fix: fail releases with a warning if source map uploading fails

## 8.1.2

### Patch Changes

- [`669f5e4`](https://github.com/interfere-inc/interfere/commit/669f5e40c24cf47b4335b8e51df09efe40112d29) Thanks [@skve](https://github.com/skve)! - Added telemetry for per-sdk breakdowns

## 8.1.0

### Minor Changes

- [`e3b34e8`](https://github.com/interfere-inc/interfere/commit/e3b34e8bb42717aa5058286cb5683c0d8b068497) Thanks [@skve](https://github.com/skve)! - Added automatic country code detection & arbitrary trait support

## 8.0.0

### Major Changes

- [`de35bcb`](https://github.com/interfere-inc/interfere/commit/de35bcbba7416339d95b4b98407e052046d6cce4) Thanks [@skve](https://github.com/skve)! - fixed race condition in session tracking

## 6.0.0

### Major Changes

- [`4de11e1`](https://github.com/interfere-inc/interfere/commit/4de11e17a8a774139f47f06992b554370bae7150) Thanks [@skve](https://github.com/skve)! - Added remote config to plugin enablement

## 5.0.0

### Major Changes

- [`2ef1592`](https://github.com/interfere-inc/interfere/commit/2ef1592e1b45422faf73bfd731509d6458fcfa07) Thanks [@skve](https://github.com/skve)! - User & Session Tracking support

## 4.0.0

### Major Changes

- fix bundle

## 1.0.3

### Patch Changes

- [`8102e08`](https://github.com/interfere-inc/interfere/commit/8102e0858d1e97953a62f76f0774511955c05422) Thanks [@skve](https://github.com/skve)! - Fixed catalog dependency resolution

## 1.0.2

### Patch Changes

- fix types

## 1.0.1

### Patch Changes

- [`032905b`](https://github.com/interfere-inc/interfere/commit/032905b19f2d916d4709251cf632957f127ca917) Thanks [@skve](https://github.com/skve)! - Fixed package exports

## 1.0.0

### Major Changes

- [`17fe701`](https://github.com/interfere-inc/interfere/commit/17fe701227f2a55644eb77b254888a5a0657036d) Thanks [@skve](https://github.com/skve)! - feat: release v1

### Minor Changes

- [`949b3e2`](https://github.com/interfere-inc/interfere/commit/949b3e27002091477e4fdbd37e6c77d6de4ff780) Thanks [@skve](https://github.com/skve)! - Fixed dependency graph

### Patch Changes

- [`99b741d`](https://github.com/interfere-inc/interfere/commit/99b741d9cbc336d5194a4c36acd7c8afdad6d7ba) Thanks [@skve](https://github.com/skve)! - bump

- [`bc3cdb3`](https://github.com/interfere-inc/interfere/commit/bc3cdb362c595217c1ffe70e462c1e994a3043b1) Thanks [@skve](https://github.com/skve)! - bump

- [`6e791b6`](https://github.com/interfere-inc/interfere/commit/6e791b6e05151da43259bdb026b126949e2f6470) Thanks [@skve](https://github.com/skve)! - bump

- [`6e791b6`](https://github.com/interfere-inc/interfere/commit/6e791b6e05151da43259bdb026b126949e2f6470) Thanks [@skve](https://github.com/skve)! - fix

- [`2847cd7`](https://github.com/interfere-inc/interfere/commit/2847cd75cd9a067e6b265864f1ed01c01ffe8a22) Thanks [@skve](https://github.com/skve)! - Improvements, Native Next.js 16 support, and huge performance improvements.

## 1.0.0-alpha.6

### Major Changes

- [`17fe701`](https://github.com/interfere-inc/interfere/commit/17fe701227f2a55644eb77b254888a5a0657036d) Thanks [@skve](https://github.com/skve)! - feat: release v1

## 0.2.0-alpha.5

### Patch Changes

- bump

## 0.2.0-alpha.4

### Patch Changes

- bump

## 0.2.0-alpha.3

### Patch Changes

- fix

## 0.2.0-alpha.2

### Patch Changes

- bump

## 0.2.0-alpha.1

### Patch Changes

- Fix silent initialization issues

## 0.1.0-alpha.32

### Minor Changes

- [`949b3e2`](https://github.com/interfere-inc/interfere/commit/949b3e27002091477e4fdbd37e6c77d6de4ff780) Thanks [@skve](https://github.com/skve)! - Fixed dependency graph

## 0.0.1-alpha.31

### Patch Changes

- [`2847cd7`](https://github.com/interfere-inc/interfere/commit/2847cd75cd9a067e6b265864f1ed01c01ffe8a22) Thanks [@skve](https://github.com/skve)! - Improvements, Native Next.js 16 support, and huge performance improvements.
