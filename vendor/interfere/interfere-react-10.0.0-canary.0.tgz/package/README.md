<p align="center">
  <a href="https://interfere.com">
    <picture>
      <source media="(prefers-color-scheme: dark)" srcset="https://qyzkf4cgb8ydxtq1.public.blob.vercel-storage.com/v2/header/logo-dark.png">
      <img src="https://qyzkf4cgb8ydxtq1.public.blob.vercel-storage.com/v2/header/logo-light.png" height="64" alt="Interfere">
    </picture>
  </a>
  <h1 align="center">@interfere/react</h1>
</p>

<p align="center">
  <a href="https://www.npmjs.com/package/@interfere/react"><img src="https://img.shields.io/npm/v/@interfere/react.svg" alt="npm version" /></a>
  <a href="https://github.com/interfere-inc/interfere/blob/main/LICENSE"><img src="https://img.shields.io/npm/l/@interfere/react.svg" alt="License" /></a>
  <a href="https://www.npmjs.com/package/@interfere/react"><img src="https://img.shields.io/npm/dm/@interfere/react.svg" alt="npm downloads" /></a>
</p>

<p align="center">
  Client-side React SDK for <a href="https://interfere.com">Interfere</a> — error tracking, session replay, and analytics.
</p>

<p align="center">
  <a href="https://support.interfere.com/docs">Documentation</a>
  ·
  <a href="https://support.interfere.com/roadmap">Feature Requests</a>
  ·
  <a href="https://support.interfere.com/requests">Report a Bug</a>
  ·
  <a href="mailto:support@interfere.com">Get Help</a>
</p>

---

## Framework Guides

| Framework | Package | Guide |
| --- | --- | --- |
| Next.js | [`@interfere/next`](https://www.npmjs.com/package/@interfere/next) | [docs/next.md](docs/next.md) |
| Vite | [`@interfere/vite`](https://www.npmjs.com/package/@interfere/vite) + `@interfere/react` | [docs/vite.md](docs/vite.md) |

## Installation

```bash
npm install @interfere/react
```

### Prerequisites

- React `>=19`

## Quick Start

```tsx
import { InterfereProvider } from "@interfere/react/provider";

function App() {
  return (
    <InterfereProvider>
      <YourApp />
    </InterfereProvider>
  );
}
```

## Features

- **Error tracking** — automatic capture of uncaught errors and unhandled rejections
- **Session replay** — full visual playback of user sessions
- **Page analytics** — SPA-aware pageviews and UI interaction events
- **Rage click detection** — surface frustrated user behavior
- **User identity** — attach user context to sessions
- **Offline resilient** — events are persisted and delivered in the background

## Hooks

```tsx
import { useInterfere } from "@interfere/react/provider";

function MyComponent() {
  const { identity, session } = useInterfere();

  identity.set({
    identifier: "usr_123",
    email: "jane@example.com",
    name: "Jane",
    source: { type: "clerk", name: "Clerk" },
  });

  const sessionId = session.getId();
}
```

## Documentation

Visit [interfere.com/docs](https://support.interfere.com/docs) for the full documentation.

## License

MIT
