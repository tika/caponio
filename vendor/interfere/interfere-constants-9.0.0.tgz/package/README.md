<p align="center">
  <a href="https://interfere.com">
    <picture>
      <source media="(prefers-color-scheme: dark)" srcset="https://qyzkf4cgb8ydxtq1.public.blob.vercel-storage.com/v2/header/logo-dark.png">
      <img src="https://qyzkf4cgb8ydxtq1.public.blob.vercel-storage.com/v2/header/logo-light.png" height="64" alt="Interfere">
    </picture>
  </a>
  <h1 align="center">@interfere/constants</h1>
</p>

<p align="center">
  <a href="https://www.npmjs.com/package/@interfere/constants"><img src="https://img.shields.io/npm/v/@interfere/constants.svg" alt="npm version" /></a>
  <a href="https://github.com/interfere-inc/interfere/blob/main/LICENSE"><img src="https://img.shields.io/npm/l/@interfere/constants.svg" alt="License" /></a>
</p>

<p align="center">
  Shared constants for <a href="https://interfere.com">Interfere</a> SDKs — API URLs, paths, and HTTP utilities.
</p>

---

## Installation

```bash
npm install @interfere/constants
```

## License

MIT
