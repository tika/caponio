<p align="center">
  <a href="https://interfere.com">
    <picture>
      <source media="(prefers-color-scheme: dark)" srcset="https://qyzkf4cgb8ydxtq1.public.blob.vercel-storage.com/v2/header/logo-dark.png">
      <img src="https://qyzkf4cgb8ydxtq1.public.blob.vercel-storage.com/v2/header/logo-light.png" height="64" alt="Interfere">
    </picture>
  </a>
  <h1 align="center">@interfere/vite</h1>
</p>

<p align="center">
  <a href="https://www.npmjs.com/package/@interfere/vite"><img src="https://img.shields.io/npm/v/@interfere/vite.svg" alt="npm version" /></a>
  <a href="https://github.com/interfere-inc/interfere/blob/main/LICENSE"><img src="https://img.shields.io/npm/l/@interfere/vite.svg" alt="License" /></a>
  <a href="https://www.npmjs.com/package/@interfere/vite"><img src="https://img.shields.io/npm/dm/@interfere/vite.svg" alt="npm downloads" /></a>
</p>

<p align="center">
  Vite build plugin and client initialization for <a href="https://interfere.com">Interfere</a> — error tracking, session replay, and analytics for modern product teams.
</p>

<p align="center">
  <a href="https://support.interfere.com/docs">Documentation</a>
  ·
  <a href="https://support.interfere.com/roadmap">Feature Requests</a>
  ·
  <a href="https://support.interfere.com/requests">Report a Bug</a>
  ·
  <a href="mailto:support@interfere.com">Get Help</a>
</p>

---

## Getting Started

### Prerequisites

- Vite `>=5`
- React `>=19`
- [`@interfere/react`](https://www.npmjs.com/package/@interfere/react) for the React provider and hooks

### Installation

```bash
npm install @interfere/vite @interfere/react
```

### Quick Start

**1. Add the Vite plugin**

```ts
// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { interfere } from "@interfere/vite/plugin";

export default defineConfig({
  plugins: [react(), interfere()],
});
```

The plugin automatically injects your build ID and release ID into the page at build time. By default the build ID is resolved from `git rev-parse HEAD`; you can override it via plugin options or the `VITE_INTERFERE_BUILD_ID` environment variable.

**2. Initialize the client**

```ts
// src/main.tsx
import "@interfere/vite/client";
```

That single side-effect import boots the kernel with sensible defaults — equivalent to calling `init()` with no options. Place it above your React imports so the SDK is ready to capture errors from first render.

If you need to pass options (custom consent, plugin overrides, a tracing config, etc.), use the imperative `init()` instead:

```ts
import { init } from "@interfere/vite/init";

init({ consent: { analytics: true, replay: false } });
```

`init()` is idempotent — a side-effect import followed by an explicit call returns the same kernel.

**3. Add the React provider**

```tsx
// src/App.tsx
import { InterfereProvider } from "@interfere/vite/provider";

function App() {
  return (
    <InterfereProvider>
      <YourApp />
    </InterfereProvider>
  );
}
```

The provider resolves the kernel from the singleton bound by `init()` — no need to thread it through props.

### Environment Variables

| Variable | Required | Description |
| --- | --- | --- |
| `VITE_INTERFERE_PUBLIC_KEY` | Yes | Your project public key. Injected into the page at build time. |
| `INTERFERE_API_KEY` | Yes for source-map upload | Build-time auth for the source-map pipeline. **Not** `VITE_`-prefixed so it never lands in your client bundle. |
| `INTERFERE_API_URL` | No | Override the collector base URL. |
| `INTERFERE_SOURCE_ID` | No | Override the commit SHA used to derive the release slug. CI env vars (`VERCEL_GIT_COMMIT_SHA`, `GITHUB_SHA`, …) are read automatically. |
| `VITE_INTERFERE_COMMIT_SHA` | No | Per-build SHA override read from Vite-resolved env. |

## Plugin Options

```ts
interfere({
  commitSha: "deadbeef…",
  sourcemaps: {
    assets: [".output/client/**/*.map", ".output/server/**/*.map"],
    ignore: ["**/legacy/**"],
  },
});
```

| Option | Default | Description |
| --- | --- | --- |
| `commitSha` | `INTERFERE_SOURCE_ID` → `VERCEL_GIT_COMMIT_SHA` → `GITHUB_SHA` → `git rev-parse HEAD` | Override the commit SHA used to derive the release slug. |
| `sourcemaps.assets` | `["<resolved outDir>/**/*.map"]` | Project-relative POSIX globs matching `.map` files to upload. Widen this to cover multi-build setups — TanStack Start, Nuxt-via-Vite-nitro, anything with output trees outside Vite's `outDir`. |
| `sourcemaps.ignore` | `[]` (plus a hard-coded `**/node_modules/**` + `**/.git/**` exclusion) | Globs filtered out of the include sweep. |

## Multi-build setups (TanStack Start, Nuxt, Nitro)

**TanStack Start is auto-detected.** When the plugin sees a `tanstack-start*` plugin in your Vite config, it widens source-map discovery to `.output/client` and `.output/server` automatically — no extra config needed:

```ts
// vite.config.ts — TanStack Start (auto-widen)
import { defineConfig } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import { interfere } from "@interfere/vite/plugin";

export default defineConfig({
  plugins: [tanstackStart(), interfere()],
});
```

For other multi-build setups (Nuxt-via-Vite-nitro, custom layouts), point `sourcemaps.assets` at every emitted tree explicitly:

```ts
interfere({
  sourcemaps: {
    assets: [
      ".output/client/**/*.map",
      ".output/server/**/*.map",
    ],
  },
});
```

Each glob's static prefix (`.output/client`, `.output/server`) becomes its own base when computing chunk URLs, so identically-named chunks across the client and server trees don't collide on the manifest's filename-fallback index.

Server-frame symbolication is debug-id-first on the Interfere collector — chunks get a `//# debugId=` marker stamped during discovery, and the runtime ships that id alongside the stack, so the upload doesn't need to know each chunk's deployed URL.

## Source Maps

When `INTERFERE_API_KEY` is set, the plugin uploads source maps after every production build:

1. Forces `build.sourcemap: "hidden"` (unless you've explicitly set `sourcemap` to a truthy value, in which case your setting is preserved).
2. Walks the configured globs (`sourcemaps.assets`, default `<outDir>/**/*.map`), pairs each `.map` with its sibling `.js`, and injects matching `//# debugId=` markers when none are present.
3. Creates a release on the Interfere collector and uploads each `.map` directly to R2 via presigned URLs (no proxy bottleneck).
4. Deletes the discovered `.map` files when the plugin forced them on, so they never ship to the browser. If you set `sourcemap: true` yourself, files stay on disk.

The build will **fail loudly** when `INTERFERE_API_KEY` is set but:

- `VITE_INTERFERE_PUBLIC_KEY` is missing — the client SDK has no credential to authenticate.
- No commit SHA can be resolved from env vars or git.
- Your surface has no `sourceProvider` / `destinationProvider` configured at https://interfere.com.

Transient upload failures (network, R2 5xx, etc.) emit a warning and let the build complete — events still ingest, they just aren't paired with the release for evidence.

## Identity Management

Link sessions to your authenticated users with `identity.set()`:

```tsx
import { useInterfere } from "@interfere/vite/provider";

function useInterfereIdentity() {
  const { identity } = useInterfere();

  // Clerk, Auth0, etc.
  const { user } = useAuthProvider();

  useEffect(() => {
    if (user) {
      identity.set({
        identifier: user.id,
        name: user.name,
        email: user.email,
        source: { type: "clerk", name: "Clerk" },
      });
    } else {
      identity.clear();
    }
  }, [user]);

  return null;
}
```

### Parameters

| Field | Required | Description |
| --- | --- | --- |
| `identifier` | Yes | Unique user ID (your internal ID, not email) |
| `source` | Yes | Auth source: `{ type: "clerk", name: "Clerk" }`, `{ type: "auth0", name: "Auth0" }`, or `{ type: "custom", name: "Your Provider" }` |
| `name` | No | Display name |
| `email` | No | Email address |
| `avatar` | No | Avatar URL |
| `traits` | No | Arbitrary key-value metadata (`Record<string, unknown>`) |

### API

| Method | Description |
| --- | --- |
| `identity.set(params)` | Link the current session to a user. Deduplicated per session — only the first call sends a request. |
| `identity.get()` | Returns the current `IdentifyParams`, or `null` if no identity has been set. |

Identity is automatically cleared when the SDK is closed or the session rotates.

## Consent Management

By default, all SDK features are active. To gate features behind user consent, pass a `consent` prop to the provider:

```tsx
import { InterfereProvider } from "@interfere/vite/provider";

function App() {
  return (
    <InterfereProvider consent={{ analytics: true, replay: false }}>
      <YourApp />
    </InterfereProvider>
  );
}
```

### Consent categories

| Category | Plugins | Gated? |
| --- | --- | --- |
| `necessary` | Error tracking | Always on |
| `analytics` | Page events, rage clicks, fingerprint | Yes |
| `replay` | Session replay | Yes |

Omitting the `consent` prop disables gating entirely (all features load). Passing it enables gating — only `necessary` plugins plus explicitly consented categories will activate.

### Imperative API

Use `consent.set()` and `consent.get()` from the `useInterfere` hook:

```tsx
const { consent } = useInterfere();

consent.set({ analytics: true, replay: true }); // selective
consent.set();                                   // grant all
consent.get();                                   // current state, or null if no gating
```

### Initial consent via init

To set consent before React renders (avoiding any window where non-consented plugins might load), pass it to `init()`:

```ts
import { init } from "@interfere/vite/init";

init({ consent: { analytics: false, replay: false } });
```

The provider's `consent` prop will then keep it in sync as the user updates their preferences.

## What's Included

- **Source map upload** — discovers, debug-id stamps, and uploads source maps to Interfere on every production build
- **Build metadata injection** — automatically tags each build with a Git SHA-derived release slug
- **Error tracking** — automatic capture of uncaught errors and unhandled rejections
- **Session replay** — full visual playback of user sessions
- **Page analytics** — SPA-aware pageviews and UI interaction events
- **Rage click detection** — surface frustrated user behavior
- **Consent gating** — fine-grained control over which features activate

## License

MIT
