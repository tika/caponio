<p align="center">
  <a href="https://interfere.com">
    <picture>
      <source media="(prefers-color-scheme: dark)" srcset="https://qyzkf4cgb8ydxtq1.public.blob.vercel-storage.com/v2/header/logo-dark.png">
      <img src="https://qyzkf4cgb8ydxtq1.public.blob.vercel-storage.com/v2/header/logo-light.png" height="64" alt="Interfere">
    </picture>
  </a>
  <h1 align="center">@interfere/vite</h1>
</p>

<p align="center">
  <a href="https://www.npmjs.com/package/@interfere/vite"><img src="https://img.shields.io/npm/v/@interfere/vite.svg" alt="npm version" /></a>
  <a href="https://github.com/interfere-inc/interfere/blob/main/LICENSE"><img src="https://img.shields.io/npm/l/@interfere/vite.svg" alt="License" /></a>
  <a href="https://www.npmjs.com/package/@interfere/vite"><img src="https://img.shields.io/npm/dm/@interfere/vite.svg" alt="npm downloads" /></a>
</p>

<p align="center">
  Vite SDK for <a href="https://interfere.com">Interfere</a> — error tracking, session replay, and analytics for React apps shipped with Vite or TanStack Start.
</p>

<p align="center">
  <a href="https://support.interfere.com/docs">Documentation</a>
  ·
  <a href="https://support.interfere.com/roadmap">Feature Requests</a>
  ·
  <a href="https://support.interfere.com/requests">Report a Bug</a>
  ·
  <a href="mailto:support@interfere.com">Get Help</a>
</p>

---

## Getting Started

### Prerequisites

- Vite `>=5`
- React `>=19`

### Installation

```bash
npm install @interfere/vite
```

### Quick Start (vanilla Vite SPA)

**1. Add the Vite plugin**

```ts
// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { interfere } from "@interfere/vite/plugin";

export default defineConfig({
  plugins: [react(), interfere()],
});
```

**2. Initialize the SDK**

```ts
// src/main.tsx
import { init } from "@interfere/vite/init";

import { createRoot } from "react-dom/client";
import { App } from "./app";

init();

createRoot(document.getElementById("root")!).render(<App />);
```

**3. Add the provider**

```tsx
// src/app.tsx
import { InterfereProvider } from "@interfere/vite/provider";

export function App() {
  return (
    <InterfereProvider>
      <YourApp />
    </InterfereProvider>
  );
}
```

That's it. The provider auto-resolves the kernel created by `init()`; you don't have to wire `useSyncExternalStore` yourself.

### Quick Start (TanStack Start + Nitro)

TanStack Start runs through Nitro, so the SDK mirrors the Next.js shape: browser events go to a same-origin proxy route, and the server forwards with `INTERFERE_API_KEY`.

Use the same browser imports — call `init()` from the file that boots your router, and put `<InterfereProvider>` in `__root.tsx`:

```ts
// src/router.tsx
import { init } from "@interfere/vite/init";
import { createRouter } from "@tanstack/react-router";
import { routeTree } from "./routeTree.gen";

if (typeof window !== "undefined") {
  init();
}

export const getRouter = () =>
  createRouter({ routeTree, scrollRestoration: true });
```

```tsx
// src/routes/__root.tsx
import { InterfereProvider } from "@interfere/vite/provider";
import { Outlet } from "@tanstack/react-router";

function RootComponent() {
  return (
    <InterfereProvider>
      <Outlet />
    </InterfereProvider>
  );
}
```

The browser guard matters for TanStack Start because prerender can evaluate the router import graph on the server, while the Interfere kernel uses browser-only APIs.

Then mount the proxy handler and server instrumentation in a catch-all route:

```tsx
// src/routes/api/interfere/$.tsx
import { handle } from "@interfere/vite/handler";
import { register } from "@interfere/vite/server";

import { createFileRoute } from "@tanstack/react-router";

if (typeof window === "undefined") {
  register().catch((error: unknown) => {
    console.warn("[interfere] register() threw during boot", error);
  });
}

export const Route = createFileRoute("/api/interfere/$")({
  server: {
    handlers: {
      GET: ({ request }) => handle(request),
      POST: ({ request }) => handle(request),
      OPTIONS: ({ request }) => handle(request),
    },
  },
});
```

## First-Time Setup

The SDK splits its credentials by concern: a **public key** travels with the browser bundle (it's not a secret), and an **API key** stays server-side (CI / Infisical / `.env.local`).

1. **Install** `@interfere/vite` and add the plugin (above).
2. **Public key** — copy from the dashboard's "Surfaces → your surface → Pub Tokens" page into `.env.local` as `VITE_INTERFERE_PUBLIC_KEY=...`. Public by design; safe to commit to a public repo.
3. **API key** — create one in the dashboard's "Surfaces → your surface → API Keys → New" and put the value in `.env.local` as `INTERFERE_API_KEY=...`. This key is what the build pipeline uses to upload source maps and confirm the release. **Server-side; never commit.**
4. **First build** — run `bun run build`. The plugin's `closeBundle` hook runs the real release pipeline against the collector: creates the release, uploads source maps to R2, preflight-confirms it. After this the commit's slug is accepted at ingest.
5. **Dev cycle** — `bun run dev` then exercises the bundle in your browser. Events flow with the commit's preflight-confirmed slug (the build did the work). New commit? Re-run `bun run build` so the new commit's slug is preflighted.

For **Vercel preview / production**, set `INTERFERE_API_KEY` in Infisical at your sandbox's path (or directly as a Vercel env var). Each preview build runs the same `bun run build` flow in CI; no local-vs-preview divergence.

## Environment Variables

| Variable | Required | Description |
| --- | --- | --- |
| `VITE_INTERFERE_PUBLIC_KEY` | Yes for vanilla Vite direct mode | Browser-side ingest token. Stamped into the page by the plugin at build time. Ignored in TanStack Start / proxy mode. |
| `INTERFERE_API_KEY` | Yes for source-map upload and proxy mode | Server-side credential. Used by the plugin at build time and by the TanStack Start proxy handler at runtime. Without it, source maps are not uploaded and the collector rejects events as `COLLECTOR_RELEASE_PREFLIGHT_UNCONFIRMED`. |
| `INTERFERE_API_URL` | No | Override the collector URL the build pipeline targets. Defaults to `https://in.interfere.com`. |
| `VITE_INTERFERE_API_URL` | No | Override the collector URL the browser kernel targets in direct mode. Proxy mode uses `INTERFERE_API_URL` server-side. |
| `VITE_INTERFERE_COMMIT_SHA` | No | Override the auto-detected commit SHA used to derive the release slug. Defaults to `git rev-parse HEAD`. |
| `VITE_INTERFERE_FORCE_ENABLE` | No | `"1"` / `"true"` flips the SDK into force-enable mode so `vite dev` (which sets `NODE_ENV=development`) emits events. Production collectors silently 202-drop force-enabled batches; safe to ship by mistake but useless. Use only in dev. |

## Plugin Options

```ts
interfere({
  commitSha: "abcd0000abcd0000abcd0000abcd0000abcd0000",
});
```

| Option | Default | Description |
| --- | --- | --- |
| `commitSha` | `VITE_INTERFERE_COMMIT_SHA` → `git rev-parse HEAD` | Commit SHA used to derive the deterministic release slug. |
| `mode` | `"auto"` | `"auto"` detects TanStack Start / Nitro and uses proxy mode; vanilla Vite uses direct mode. Override with `"direct"` or `"proxy"` when needed. |
| `sourceMaps` | auto | `false` disables build-time source-map upload. By default upload runs when `INTERFERE_API_KEY` and a commit SHA are available. |

## Identity Management

Link sessions to your authenticated users with `identity.set()`:

```tsx
import { useInterfere } from "@interfere/vite/provider";

function useInterfereIdentity() {
  const { identity } = useInterfere();
  const { user } = useAuthProvider();

  useEffect(() => {
    if (user) {
      identity.set({
        identifier: user.id,
        name: user.name,
        email: user.email,
        source: { type: "clerk", name: "Clerk" },
      });
    } else {
      identity.clear();
    }
  }, [user]);

  return null;
}
```

### Parameters

| Field | Required | Description |
| --- | --- | --- |
| `identifier` | Yes | Unique user ID (your internal ID, not email) |
| `source` | Yes | Auth source: `{ type: "clerk", name: "Clerk" }`, `{ type: "auth0", name: "Auth0" }`, or `{ type: "custom", name: "Your Provider" }` |
| `name` | No | Display name |
| `email` | No | Email address |
| `avatar` | No | Avatar URL |
| `traits` | No | Arbitrary key-value metadata (`Record<string, unknown>`) |

### API

| Method | Description |
| --- | --- |
| `identity.set(params)` | Link the current session to a user. Deduplicated per session — only the first call sends a request. |
| `identity.get()` | Returns the current `IdentifyParams`, or `null` if no identity has been set. |

Identity is automatically cleared when the SDK is closed or the session rotates.

## Consent Management

By default, all SDK features are active. To gate features behind user consent, pass a `consent` prop to the provider:

```tsx
import { InterfereProvider } from "@interfere/vite/provider";

function App() {
  return (
    <InterfereProvider consent={{ analytics: true, replay: false }}>
      <YourApp />
    </InterfereProvider>
  );
}
```

### Consent categories

| Category | Plugins | Gated? |
| --- | --- | --- |
| `necessary` | Error tracking | Always on |
| `analytics` | Page events, rage clicks, fingerprint | Yes |
| `replay` | Session replay | Yes |

Omitting the `consent` prop disables gating entirely (all features load). Passing it enables gating — only `necessary` plugins plus explicitly consented categories will activate.

### Imperative API

Use `consent.set()` and `consent.get()` from the `useInterfere` hook:

```tsx
const { consent } = useInterfere();

consent.set({ analytics: true, replay: true }); // selective
consent.set();                                   // grant all
consent.get();                                   // current state, or null if no gating
```

### Initial consent via init

To set consent before React renders (avoiding any window where non-consented plugins might load), pass it to `init()` directly instead of using `auto`:

```ts
import { init } from "@interfere/vite/init";

init({ consent: { analytics: false, replay: false } });
```

The provider's `consent` prop will then keep it in sync as the user updates their preferences.

## What's Included

- **Build metadata injection** — automatic Git SHA-derived release slug
- **Error tracking** — automatic capture of uncaught errors and unhandled rejections
- **Session replay** — full visual playback of user sessions
- **Page analytics** — SPA-aware pageviews and UI interaction events
- **Rage click detection** — surface frustrated user behavior
- **Consent gating** — fine-grained control over which features activate

## License

MIT
